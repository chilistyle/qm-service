--
-- PostgreSQL database dump
--

\restrict oHUgQcW0faYeHPJPnvn6UbyxMt295c9WQnXuauNJRyhJ7ZjEU7BiBMx6PNXlc4y

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64),
    details_json text
);


ALTER TABLE public.admin_event_entity OWNER TO "user";

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO "user";

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO "user";

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO "user";

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.authenticator_config (
    id character varying(36) CONSTRAINT authenticator_id_not_null NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO "user";

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) CONSTRAINT authenticator_config_authenticator_id_not_null NOT NULL,
    value text,
    name character varying(255) CONSTRAINT authenticator_config_name_not_null NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO "user";

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO "user";

--
-- Name: client; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO "user";

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO "user";

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO "user";

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO "user";

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) CONSTRAINT app_node_registrations_application_id_not_null NOT NULL,
    value integer,
    name character varying(255) CONSTRAINT app_node_registrations_name_not_null NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO "user";

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.client_scope (
    id character varying(36) CONSTRAINT client_template_id_not_null NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO "user";

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) CONSTRAINT client_template_attributes_template_id_not_null NOT NULL,
    value character varying(2048),
    name character varying(255) CONSTRAINT client_template_attributes_name_not_null NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO "user";

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO "user";

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) CONSTRAINT template_scope_mapping_template_id_not_null NOT NULL,
    role_id character varying(36) CONSTRAINT template_scope_mapping_role_id_not_null NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO "user";

--
-- Name: component; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO "user";

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.component_config OWNER TO "user";

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO "user";

--
-- Name: credential; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.credential OWNER TO "user";

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO "user";

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO "user";

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO "user";

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255),
    details_json_long_value text
);


ALTER TABLE public.event_entity OWNER TO "user";

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024),
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


ALTER TABLE public.fed_user_attribute OWNER TO "user";

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO "user";

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO "user";

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO "user";

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO "user";

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO "user";

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO "user";

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO "user";

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO "user";

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO "user";

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO "user";

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL,
    organization_id character varying(255),
    hide_on_login boolean DEFAULT false
);


ALTER TABLE public.identity_provider OWNER TO "user";

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO "user";

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO "user";

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO "user";

--
-- Name: jgroups_ping; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.jgroups_ping (
    address character varying(200) NOT NULL,
    name character varying(200),
    cluster_name character varying(200) NOT NULL,
    ip character varying(200) NOT NULL,
    coord boolean
);


ALTER TABLE public.jgroups_ping OWNER TO "user";

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36),
    type integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.keycloak_group OWNER TO "user";

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false CONSTRAINT keycloak_role_application_role_not_null NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO "user";

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO "user";

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL,
    version integer DEFAULT 0
);


ALTER TABLE public.offline_client_session OWNER TO "user";

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL,
    broker_session_id character varying(1024),
    version integer DEFAULT 0
);


ALTER TABLE public.offline_user_session OWNER TO "user";

--
-- Name: org; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.org (
    id character varying(255) NOT NULL,
    enabled boolean NOT NULL,
    realm_id character varying(255) NOT NULL,
    group_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(4000),
    alias character varying(255) NOT NULL,
    redirect_url character varying(2048)
);


ALTER TABLE public.org OWNER TO "user";

--
-- Name: org_domain; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.org_domain (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    verified boolean NOT NULL,
    org_id character varying(255) NOT NULL
);


ALTER TABLE public.org_domain OWNER TO "user";

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO "user";

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO "user";

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO "user";

--
-- Name: realm; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO "user";

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO "user";

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO "user";

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO "user";

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO "user";

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO "user";

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO "user";

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO "user";

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO "user";

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO "user";

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO "user";

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO "user";

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO "user";

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO "user";

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO "user";

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resource_server (
    id character varying(36) CONSTRAINT resource_server_client_id_not_null NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO "user";

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO "user";

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) CONSTRAINT resource_server_policy_resource_server_client_id_not_null NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO "user";

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) CONSTRAINT resource_server_resource_resource_server_client_id_not_null NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO "user";

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) CONSTRAINT resource_server_scope_resource_server_client_id_not_null NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO "user";

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO "user";

--
-- Name: revoked_token; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.revoked_token (
    id character varying(255) NOT NULL,
    expire bigint NOT NULL
);


ALTER TABLE public.revoked_token OWNER TO "user";

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO "user";

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO "user";

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO "user";

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


ALTER TABLE public.user_attribute OWNER TO "user";

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO "user";

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO "user";

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO "user";

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO "user";

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO "user";

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) CONSTRAINT user_federation_mapper_confi_user_federation_mapper_id_not_null NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO "user";

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO "user";

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    membership_type character varying(255) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO "user";

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO "user";

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO "user";

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: user
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO "user";

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type, details_json) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
979b9dbb-5be5-4347-a259-6a6fba8d715d	e5499399-ad89-4bd1-8992-41be9abed651
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
6d792485-e0cd-4677-a9fa-11260eeedc11	\N	auth-cookie	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f836c8fe-a815-4e33-90f5-1e6db53ca463	2	10	f	\N	\N
d1830825-832a-4b1a-82c5-2bfa4b6a3162	\N	auth-spnego	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f836c8fe-a815-4e33-90f5-1e6db53ca463	3	20	f	\N	\N
a5a3df25-b3fd-458f-8ebe-a64f618fda5d	\N	identity-provider-redirector	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f836c8fe-a815-4e33-90f5-1e6db53ca463	2	25	f	\N	\N
0cbb3c79-35e5-4d3b-9db8-9afa015e995f	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f836c8fe-a815-4e33-90f5-1e6db53ca463	2	30	t	9d6dde5e-40f7-46c0-8181-5e31e1a8eac5	\N
d82aa943-f00e-40d5-b598-3c9ca03f2738	\N	auth-username-password-form	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	9d6dde5e-40f7-46c0-8181-5e31e1a8eac5	0	10	f	\N	\N
42e90e8d-3ea3-4636-a783-2126a4e54a2b	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	9d6dde5e-40f7-46c0-8181-5e31e1a8eac5	1	20	t	35fde332-b729-4f06-9b22-93814424a215	\N
6724fc21-ff51-434f-972c-828e0f8ad959	\N	conditional-user-configured	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	35fde332-b729-4f06-9b22-93814424a215	0	10	f	\N	\N
536ff270-07a3-4d15-97f3-0e2587025ff4	\N	auth-otp-form	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	35fde332-b729-4f06-9b22-93814424a215	0	20	f	\N	\N
0d3cb0fb-8235-4658-b737-bee7769a044d	\N	direct-grant-validate-username	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bb2269b-d3b8-423d-8d84-d351e1f945a6	0	10	f	\N	\N
6c8dcfc7-f648-4a49-938d-449a1f0b59a4	\N	direct-grant-validate-password	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bb2269b-d3b8-423d-8d84-d351e1f945a6	0	20	f	\N	\N
4af84c22-dea2-41ab-90ac-5a76dfc61242	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bb2269b-d3b8-423d-8d84-d351e1f945a6	1	30	t	064331ae-3b88-476d-b04a-fb485d40a7aa	\N
6e732735-4a20-4580-a4ed-d5ed7c54b0df	\N	conditional-user-configured	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	064331ae-3b88-476d-b04a-fb485d40a7aa	0	10	f	\N	\N
e8c94199-4947-4ffc-b7df-6c3d961e74eb	\N	direct-grant-validate-otp	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	064331ae-3b88-476d-b04a-fb485d40a7aa	0	20	f	\N	\N
18fa6e8e-17e4-4a52-a7a9-83d00a55d725	\N	registration-page-form	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	e930ae3e-a199-48bb-994e-5d0b558bdc85	0	10	t	c54a24e7-b25c-49a2-92d8-bd9979349f79	\N
02df2d1d-8f66-4bcf-84f5-0785e17d0e58	\N	registration-user-creation	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	c54a24e7-b25c-49a2-92d8-bd9979349f79	0	20	f	\N	\N
5361c831-cb0b-47d3-ac76-5e9d9adf6806	\N	registration-password-action	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	c54a24e7-b25c-49a2-92d8-bd9979349f79	0	50	f	\N	\N
d7a72be3-d994-4515-a31b-23dae305b231	\N	registration-recaptcha-action	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	c54a24e7-b25c-49a2-92d8-bd9979349f79	3	60	f	\N	\N
e16d6b5c-80bd-4583-8d7c-23fb8a936adf	\N	registration-terms-and-conditions	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	c54a24e7-b25c-49a2-92d8-bd9979349f79	3	70	f	\N	\N
173dc7b7-0f55-4fc3-ba5c-76477a5659db	\N	reset-credentials-choose-user	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	40a1b042-55f3-46dc-bff8-2e6b25a7ee75	0	10	f	\N	\N
f4524273-4ada-47d1-ba58-e957f9370ea8	\N	reset-credential-email	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	40a1b042-55f3-46dc-bff8-2e6b25a7ee75	0	20	f	\N	\N
6ea0b0a3-85a8-48e2-aa8a-b10b78648a43	\N	reset-password	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	40a1b042-55f3-46dc-bff8-2e6b25a7ee75	0	30	f	\N	\N
5c6f697a-ef7c-437b-947c-4493da182ca8	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	40a1b042-55f3-46dc-bff8-2e6b25a7ee75	1	40	t	f91c1994-4886-4789-b24f-a835cbb008c7	\N
fe67f948-dd77-414f-b21b-eb8cf2d31fde	\N	conditional-user-configured	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f91c1994-4886-4789-b24f-a835cbb008c7	0	10	f	\N	\N
5e9d0163-15a4-425b-b196-5ce014831e22	\N	reset-otp	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f91c1994-4886-4789-b24f-a835cbb008c7	0	20	f	\N	\N
d5508b27-a548-4a79-82bd-721df698b5a3	\N	client-secret	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	8d31abe7-9d1b-4c75-9398-e4d244e4d118	2	10	f	\N	\N
92c72185-5703-4922-bcde-c454843caa5c	\N	client-jwt	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	8d31abe7-9d1b-4c75-9398-e4d244e4d118	2	20	f	\N	\N
fc0a109b-6fac-46c5-a2e5-5f6ce0e43dfd	\N	client-secret-jwt	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	8d31abe7-9d1b-4c75-9398-e4d244e4d118	2	30	f	\N	\N
94c9b03b-f192-4fda-b628-b9892fefedd6	\N	client-x509	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	8d31abe7-9d1b-4c75-9398-e4d244e4d118	2	40	f	\N	\N
0f916527-306c-47ec-ab09-eb9073083628	\N	idp-review-profile	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	e3c7c9e2-d4cb-4042-a70a-36027a868b71	0	10	f	\N	6a463c55-03d9-4160-9031-9f256d019943
5a6fbc23-9209-4519-9758-f6d250d73355	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	e3c7c9e2-d4cb-4042-a70a-36027a868b71	0	20	t	46659d67-bf8d-4dbf-a52d-f1b2becc396e	\N
fdbf9aca-6320-4af5-a6fa-1e521318ff88	\N	idp-create-user-if-unique	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	46659d67-bf8d-4dbf-a52d-f1b2becc396e	2	10	f	\N	46b08d1b-0d39-4766-952d-9fcb06d5f846
6f3859c7-c937-406f-803b-f63ab77117ef	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	46659d67-bf8d-4dbf-a52d-f1b2becc396e	2	20	t	303fe12e-9e5e-4832-9f83-c261a61474cd	\N
582388a1-c9c7-46ba-977e-17d7f3ccc7db	\N	idp-confirm-link	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	303fe12e-9e5e-4832-9f83-c261a61474cd	0	10	f	\N	\N
74a65462-faf1-490b-ab88-b4a1124d29c2	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	303fe12e-9e5e-4832-9f83-c261a61474cd	0	20	t	1386ac7f-5217-4c55-bf69-3629844e1f0a	\N
14609190-6cf7-4f31-a57b-f8c7585fa586	\N	idp-email-verification	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	1386ac7f-5217-4c55-bf69-3629844e1f0a	2	10	f	\N	\N
446bd390-a148-4e3d-ab60-b956d2430ddd	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	1386ac7f-5217-4c55-bf69-3629844e1f0a	2	20	t	b5e4c8c6-c39c-4c24-8ce4-49a5e06ad8ee	\N
de38e93a-8828-4e63-8d41-7bf6be1d0226	\N	idp-username-password-form	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	b5e4c8c6-c39c-4c24-8ce4-49a5e06ad8ee	0	10	f	\N	\N
d234e4e6-d42e-4b45-9668-bd97dff9cb3e	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	b5e4c8c6-c39c-4c24-8ce4-49a5e06ad8ee	1	20	t	fde68446-29df-45a3-b4e5-7c9518ca954c	\N
83e07c95-1308-4749-bae0-a5bb6a6cf57e	\N	conditional-user-configured	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	fde68446-29df-45a3-b4e5-7c9518ca954c	0	10	f	\N	\N
e148a6f3-b082-43d6-883a-0f1f95d32d36	\N	auth-otp-form	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	fde68446-29df-45a3-b4e5-7c9518ca954c	0	20	f	\N	\N
8a6fd56c-892b-4ec9-a6aa-66b0e83aed64	\N	http-basic-authenticator	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	5824cdba-2dfd-4517-80b1-ca47e2ca348e	0	10	f	\N	\N
49da1e74-797e-459b-bd71-c74e4f177db1	\N	docker-http-basic-authenticator	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	3b4e89d1-ecd3-4c6a-b415-dcb3facee119	0	10	f	\N	\N
85b8a4d9-e194-4c36-a285-b5049ee4e8b7	\N	auth-cookie	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5e135d55-0f81-4d4e-be1a-b300e1645c40	2	10	f	\N	\N
94beb708-2384-489b-8646-34ad0e48335f	\N	auth-spnego	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5e135d55-0f81-4d4e-be1a-b300e1645c40	3	20	f	\N	\N
962634f5-2765-47a9-91ca-e482231c45de	\N	identity-provider-redirector	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5e135d55-0f81-4d4e-be1a-b300e1645c40	2	25	f	\N	\N
a0052cfb-a4fe-42c8-a112-787dda2da22b	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5e135d55-0f81-4d4e-be1a-b300e1645c40	2	30	t	309fa065-8503-48ba-8adc-01707285ec54	\N
1e388076-9000-474c-8433-604b1e4ecaed	\N	auth-username-password-form	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	309fa065-8503-48ba-8adc-01707285ec54	0	10	f	\N	\N
ffc19942-71ba-403c-b3ae-4523923db957	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	309fa065-8503-48ba-8adc-01707285ec54	1	20	t	964f75bd-3472-446a-871f-105b9e17c979	\N
37fad13f-aa25-49ec-95ac-6c5b1d38cb0d	\N	conditional-user-configured	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	964f75bd-3472-446a-871f-105b9e17c979	0	10	f	\N	\N
af8eec00-58c8-444a-b686-beeecf3eb04b	\N	auth-otp-form	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	964f75bd-3472-446a-871f-105b9e17c979	0	20	f	\N	\N
56946015-1983-4ccb-a116-cddaa5c17d63	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5e135d55-0f81-4d4e-be1a-b300e1645c40	2	26	t	17953127-5c0d-4a54-98bc-09c2f418f787	\N
97bd2107-4d43-4a3f-a609-08cb1e248cfc	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	17953127-5c0d-4a54-98bc-09c2f418f787	1	10	t	b8dc1099-c4d5-49b5-b4eb-0aa2253bdcbe	\N
463e6011-883f-4fc4-8cb2-e3355f71e750	\N	conditional-user-configured	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	b8dc1099-c4d5-49b5-b4eb-0aa2253bdcbe	0	10	f	\N	\N
120dbe51-ad93-4ea4-b007-042481c51359	\N	organization	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	b8dc1099-c4d5-49b5-b4eb-0aa2253bdcbe	2	20	f	\N	\N
a51cde1c-4fe2-4f7a-93b9-11e5600895e3	\N	direct-grant-validate-username	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	94868d2b-b895-49af-a3a8-9f33fe157e8a	0	10	f	\N	\N
901bd549-26d2-43c4-934f-1b7da4862e3b	\N	direct-grant-validate-password	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	94868d2b-b895-49af-a3a8-9f33fe157e8a	0	20	f	\N	\N
23ed7212-3180-405d-85f4-ee9167837b49	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	94868d2b-b895-49af-a3a8-9f33fe157e8a	1	30	t	70e9e78f-100e-4574-ba8e-94cd116b7448	\N
310fa2e9-dcd1-44af-a797-925c13d5812a	\N	conditional-user-configured	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	70e9e78f-100e-4574-ba8e-94cd116b7448	0	10	f	\N	\N
b0a2ea4e-d0fe-457a-8b26-0ccb46c3442b	\N	direct-grant-validate-otp	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	70e9e78f-100e-4574-ba8e-94cd116b7448	0	20	f	\N	\N
c52a63fe-89f0-4bbf-a25c-d2ac0d85b8fa	\N	registration-page-form	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	7ad8ad1b-695e-44a0-a1c0-831ec91fd9f5	0	10	t	c0dc2703-b275-4e4d-8c25-9711db76fb2a	\N
2fabbb58-1c9a-4657-b8a6-69782394fc13	\N	registration-user-creation	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	c0dc2703-b275-4e4d-8c25-9711db76fb2a	0	20	f	\N	\N
8f603b65-ed46-4edc-bd0e-99ce3202141c	\N	registration-password-action	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	c0dc2703-b275-4e4d-8c25-9711db76fb2a	0	50	f	\N	\N
a411992c-e922-4405-a161-f3023260e4e4	\N	registration-recaptcha-action	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	c0dc2703-b275-4e4d-8c25-9711db76fb2a	3	60	f	\N	\N
b74bb821-fce8-43f3-ad8d-af43df67a114	\N	registration-terms-and-conditions	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	c0dc2703-b275-4e4d-8c25-9711db76fb2a	3	70	f	\N	\N
042002d1-c213-41ce-bada-3d4567b6a2a2	\N	reset-credentials-choose-user	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	25a8fd7a-a18f-4edf-8515-c963c35d164e	0	10	f	\N	\N
4fe5fafd-bf57-4e6d-bc19-0ba0f61d038b	\N	reset-credential-email	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	25a8fd7a-a18f-4edf-8515-c963c35d164e	0	20	f	\N	\N
86369cdb-f91a-47a3-a9d8-cc555ab09c83	\N	reset-password	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	25a8fd7a-a18f-4edf-8515-c963c35d164e	0	30	f	\N	\N
122f8544-ae28-4d18-8fb5-b4c77a66d535	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	25a8fd7a-a18f-4edf-8515-c963c35d164e	1	40	t	6ffa54c7-67d8-4674-9a3e-dac637bfd424	\N
a02073a1-b894-43a0-836e-30921163dc63	\N	conditional-user-configured	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	6ffa54c7-67d8-4674-9a3e-dac637bfd424	0	10	f	\N	\N
c0bf1294-9a2c-4deb-ae26-ffe4a13fc68e	\N	reset-otp	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	6ffa54c7-67d8-4674-9a3e-dac637bfd424	0	20	f	\N	\N
116b3c9d-465e-451b-b4ae-81029215aed5	\N	client-secret	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	427ccf66-f2df-4500-94c0-2d72995258c9	2	10	f	\N	\N
ba5dc588-03dc-4a85-9ee7-efd5cad90bdf	\N	client-jwt	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	427ccf66-f2df-4500-94c0-2d72995258c9	2	20	f	\N	\N
81004173-9b64-40dc-b949-a2ab04a238f9	\N	client-secret-jwt	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	427ccf66-f2df-4500-94c0-2d72995258c9	2	30	f	\N	\N
775568c3-794b-462e-899c-ec6ae9f19711	\N	client-x509	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	427ccf66-f2df-4500-94c0-2d72995258c9	2	40	f	\N	\N
3bef49a5-fbd8-4be6-a832-ab54197e6f2e	\N	idp-review-profile	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	d40e0717-f4db-40dd-98b6-3c5b8819aca7	0	10	f	\N	2602f296-070c-4db0-aecb-de9b6dda3366
3528d2fc-8460-47a4-9f7c-5b470da86576	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	d40e0717-f4db-40dd-98b6-3c5b8819aca7	0	20	t	4937e211-54c0-4512-8a12-a14c9834deff	\N
15b0e2fc-68c3-49df-b2cf-1ab713e59635	\N	idp-create-user-if-unique	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	4937e211-54c0-4512-8a12-a14c9834deff	2	10	f	\N	8099006e-71c0-4792-9e9c-1bee3018bc72
43744e95-6f8d-42b4-a8ef-72b1a8be7097	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	4937e211-54c0-4512-8a12-a14c9834deff	2	20	t	60704f00-eaab-404d-a830-b15debed3533	\N
c3fbb04e-aced-4765-aef1-42c89cf203ed	\N	idp-confirm-link	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	60704f00-eaab-404d-a830-b15debed3533	0	10	f	\N	\N
b23a50f2-acf3-45cb-bf4a-a3e560cce337	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	60704f00-eaab-404d-a830-b15debed3533	0	20	t	5b39fe3d-7e7c-4663-9211-b3e8cd90082a	\N
e8c18fcc-9a20-4396-96bd-c16dbdd94917	\N	idp-email-verification	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5b39fe3d-7e7c-4663-9211-b3e8cd90082a	2	10	f	\N	\N
cb2b07b8-1586-4e4a-84ab-ce2d8709d3ab	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5b39fe3d-7e7c-4663-9211-b3e8cd90082a	2	20	t	4b911ce9-426d-42a8-9b9b-f0cb1024baee	\N
72faf68a-2958-45c3-8915-2315403704ef	\N	idp-username-password-form	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	4b911ce9-426d-42a8-9b9b-f0cb1024baee	0	10	f	\N	\N
a720e893-7b7f-4330-81be-f660fe3c4dbc	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	4b911ce9-426d-42a8-9b9b-f0cb1024baee	1	20	t	481eb6bd-4edd-4508-83e3-2e747bbbd28f	\N
4cc06789-3930-4e5e-9ad1-210005d68127	\N	conditional-user-configured	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	481eb6bd-4edd-4508-83e3-2e747bbbd28f	0	10	f	\N	\N
a02754c2-8973-4306-bb99-955d7f935f48	\N	auth-otp-form	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	481eb6bd-4edd-4508-83e3-2e747bbbd28f	0	20	f	\N	\N
c0a2a493-0435-4b36-908c-567509edfa32	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	d40e0717-f4db-40dd-98b6-3c5b8819aca7	1	50	t	7d3d1c8b-3452-4dfa-ae0e-d71045624c00	\N
98055fd4-fdd5-4e79-a337-51c085fcee5d	\N	conditional-user-configured	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	7d3d1c8b-3452-4dfa-ae0e-d71045624c00	0	10	f	\N	\N
66f3c502-1b21-4e27-8fe2-c6a5c78a8768	\N	idp-add-organization-member	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	7d3d1c8b-3452-4dfa-ae0e-d71045624c00	0	20	f	\N	\N
86af2721-87c0-40a6-b2c1-8b6aa7178b71	\N	http-basic-authenticator	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	23e3d163-5c5f-4679-8f6e-044aef4fbc32	0	10	f	\N	\N
7d0a6db0-4574-42da-b5c5-d5a894829ff3	\N	docker-http-basic-authenticator	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	b7eda90f-b1ef-4657-89e5-8d6cedf35c8c	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
f836c8fe-a815-4e33-90f5-1e6db53ca463	browser	Browser based authentication	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	t	t
9d6dde5e-40f7-46c0-8181-5e31e1a8eac5	forms	Username, password, otp and other auth forms.	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	f	t
35fde332-b729-4f06-9b22-93814424a215	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	f	t
2bb2269b-d3b8-423d-8d84-d351e1f945a6	direct grant	OpenID Connect Resource Owner Grant	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	t	t
064331ae-3b88-476d-b04a-fb485d40a7aa	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	f	t
e930ae3e-a199-48bb-994e-5d0b558bdc85	registration	Registration flow	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	t	t
c54a24e7-b25c-49a2-92d8-bd9979349f79	registration form	Registration form	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	form-flow	f	t
40a1b042-55f3-46dc-bff8-2e6b25a7ee75	reset credentials	Reset credentials for a user if they forgot their password or something	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	t	t
f91c1994-4886-4789-b24f-a835cbb008c7	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	f	t
8d31abe7-9d1b-4c75-9398-e4d244e4d118	clients	Base authentication for clients	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	client-flow	t	t
e3c7c9e2-d4cb-4042-a70a-36027a868b71	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	t	t
46659d67-bf8d-4dbf-a52d-f1b2becc396e	User creation or linking	Flow for the existing/non-existing user alternatives	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	f	t
303fe12e-9e5e-4832-9f83-c261a61474cd	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	f	t
1386ac7f-5217-4c55-bf69-3629844e1f0a	Account verification options	Method with which to verity the existing account	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	f	t
b5e4c8c6-c39c-4c24-8ce4-49a5e06ad8ee	Verify Existing Account by Re-authentication	Reauthentication of existing account	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	f	t
fde68446-29df-45a3-b4e5-7c9518ca954c	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	f	t
5824cdba-2dfd-4517-80b1-ca47e2ca348e	saml ecp	SAML ECP Profile Authentication Flow	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	t	t
3b4e89d1-ecd3-4c6a-b415-dcb3facee119	docker auth	Used by Docker clients to authenticate against the IDP	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	basic-flow	t	t
5e135d55-0f81-4d4e-be1a-b300e1645c40	browser	Browser based authentication	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	t	t
309fa065-8503-48ba-8adc-01707285ec54	forms	Username, password, otp and other auth forms.	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
964f75bd-3472-446a-871f-105b9e17c979	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
17953127-5c0d-4a54-98bc-09c2f418f787	Organization	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
b8dc1099-c4d5-49b5-b4eb-0aa2253bdcbe	Browser - Conditional Organization	Flow to determine if the organization identity-first login is to be used	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
94868d2b-b895-49af-a3a8-9f33fe157e8a	direct grant	OpenID Connect Resource Owner Grant	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	t	t
70e9e78f-100e-4574-ba8e-94cd116b7448	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
7ad8ad1b-695e-44a0-a1c0-831ec91fd9f5	registration	Registration flow	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	t	t
c0dc2703-b275-4e4d-8c25-9711db76fb2a	registration form	Registration form	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	form-flow	f	t
25a8fd7a-a18f-4edf-8515-c963c35d164e	reset credentials	Reset credentials for a user if they forgot their password or something	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	t	t
6ffa54c7-67d8-4674-9a3e-dac637bfd424	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
427ccf66-f2df-4500-94c0-2d72995258c9	clients	Base authentication for clients	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	client-flow	t	t
d40e0717-f4db-40dd-98b6-3c5b8819aca7	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	t	t
4937e211-54c0-4512-8a12-a14c9834deff	User creation or linking	Flow for the existing/non-existing user alternatives	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
60704f00-eaab-404d-a830-b15debed3533	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
5b39fe3d-7e7c-4663-9211-b3e8cd90082a	Account verification options	Method with which to verity the existing account	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
4b911ce9-426d-42a8-9b9b-f0cb1024baee	Verify Existing Account by Re-authentication	Reauthentication of existing account	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
481eb6bd-4edd-4508-83e3-2e747bbbd28f	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
7d3d1c8b-3452-4dfa-ae0e-d71045624c00	First Broker Login - Conditional Organization	Flow to determine if the authenticator that adds organization members is to be used	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	f	t
23e3d163-5c5f-4679-8f6e-044aef4fbc32	saml ecp	SAML ECP Profile Authentication Flow	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	t	t
b7eda90f-b1ef-4657-89e5-8d6cedf35c8c	docker auth	Used by Docker clients to authenticate against the IDP	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
6a463c55-03d9-4160-9031-9f256d019943	review profile config	13a45ff9-67c6-4c28-8c7e-a7268a0217e9
46b08d1b-0d39-4766-952d-9fcb06d5f846	create unique user config	13a45ff9-67c6-4c28-8c7e-a7268a0217e9
2602f296-070c-4db0-aecb-de9b6dda3366	review profile config	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9
8099006e-71c0-4792-9e9c-1bee3018bc72	create unique user config	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
46b08d1b-0d39-4766-952d-9fcb06d5f846	false	require.password.update.after.registration
6a463c55-03d9-4160-9031-9f256d019943	missing	update.profile.on.first.login
2602f296-070c-4db0-aecb-de9b6dda3366	missing	update.profile.on.first.login
8099006e-71c0-4792-9e9c-1bee3018bc72	false	require.password.update.after.registration
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
ab0b18a6-c7f9-46c6-930d-6600c036326c	t	f	master-realm	0	f	\N	\N	t	\N	f	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
2bdc8e7d-2806-4626-81da-da6449d58897	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
551feff9-1317-4fed-9053-411a8810c565	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	t	f	broker	0	f	\N	\N	t	\N	f	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
924011ef-3a2f-4fd4-a007-37fe61577d11	t	t	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
df3341ce-d4ef-49af-acfa-55791bfd15a3	t	t	admin-cli	0	t	\N	\N	f	\N	f	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	f	qm-realm-realm	0	f	\N	\N	t	\N	f	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N	0	f	f	qm-realm Realm	f	client-secret	\N	\N	\N	t	f	f	f
0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	f	realm-management	0	f	\N	\N	t	\N	f	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
55bfc23e-79c7-4a5f-96a4-503b7025f85a	t	f	account	0	t	\N	/realms/qm-realm/account/	f	\N	f	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
e39f027b-a76d-418e-80a1-190263cc2b2e	t	f	account-console	0	t	\N	/realms/qm-realm/account/	f	\N	f	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
be74d082-fd6a-4cc8-910f-a65a46e13f28	t	f	broker	0	f	\N	\N	t	\N	f	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
5b81c8b8-e05f-4298-a125-4bbf2215fb55	t	t	security-admin-console	0	t	\N	/admin/qm-realm/console/	f	\N	f	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
373f86b7-985b-418a-ac28-01d9ef037e6e	t	t	admin-cli	0	t	\N	\N	f	\N	f	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
14f121b4-4d55-46e7-abd5-161dd1da7bbe	t	t	qm-client	0	f	1yTvcNB8DPQoeGaxOgRyPsQu0j9MQuDM		f	http://localhost:3000/	f	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	openid-connect	-1	t	f		t	client-secret	http://localhost:3000/		\N	t	f	t	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
2bdc8e7d-2806-4626-81da-da6449d58897	post.logout.redirect.uris	+
551feff9-1317-4fed-9053-411a8810c565	post.logout.redirect.uris	+
551feff9-1317-4fed-9053-411a8810c565	pkce.code.challenge.method	S256
924011ef-3a2f-4fd4-a007-37fe61577d11	post.logout.redirect.uris	+
924011ef-3a2f-4fd4-a007-37fe61577d11	pkce.code.challenge.method	S256
924011ef-3a2f-4fd4-a007-37fe61577d11	client.use.lightweight.access.token.enabled	true
df3341ce-d4ef-49af-acfa-55791bfd15a3	client.use.lightweight.access.token.enabled	true
55bfc23e-79c7-4a5f-96a4-503b7025f85a	post.logout.redirect.uris	+
e39f027b-a76d-418e-80a1-190263cc2b2e	post.logout.redirect.uris	+
e39f027b-a76d-418e-80a1-190263cc2b2e	pkce.code.challenge.method	S256
5b81c8b8-e05f-4298-a125-4bbf2215fb55	post.logout.redirect.uris	+
5b81c8b8-e05f-4298-a125-4bbf2215fb55	pkce.code.challenge.method	S256
5b81c8b8-e05f-4298-a125-4bbf2215fb55	client.use.lightweight.access.token.enabled	true
373f86b7-985b-418a-ac28-01d9ef037e6e	client.use.lightweight.access.token.enabled	true
14f121b4-4d55-46e7-abd5-161dd1da7bbe	client.secret.creation.time	1775152394
14f121b4-4d55-46e7-abd5-161dd1da7bbe	oauth2.device.authorization.grant.enabled	false
14f121b4-4d55-46e7-abd5-161dd1da7bbe	oidc.ciba.grant.enabled	false
14f121b4-4d55-46e7-abd5-161dd1da7bbe	backchannel.logout.session.required	true
14f121b4-4d55-46e7-abd5-161dd1da7bbe	backchannel.logout.revoke.offline.tokens	false
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	offline_access	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	OpenID Connect built-in scope: offline_access	openid-connect
56f54f1c-8537-4574-b880-1a96cfd95b7c	role_list	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	SAML role list	saml
25289ed7-2a9d-4bb5-be28-574e102d35f8	saml_organization	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	Organization Membership	saml
fd8be0d3-37bf-416c-9491-8eed1f661408	profile	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	OpenID Connect built-in scope: profile	openid-connect
c174415c-a203-4e6e-9047-631ceec5e059	email	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	OpenID Connect built-in scope: email	openid-connect
a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	address	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	OpenID Connect built-in scope: address	openid-connect
d17d9492-a4a0-46dc-ab0a-d43f33e10b12	phone	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	OpenID Connect built-in scope: phone	openid-connect
ebedc40b-df6e-4e55-bb01-d683b157d4b9	roles	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	OpenID Connect scope for add user roles to the access token	openid-connect
1a8174ab-5f62-462e-9380-e926c127aa90	web-origins	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	OpenID Connect scope for add allowed web origins to the access token	openid-connect
a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	microprofile-jwt	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	Microprofile - JWT built-in scope	openid-connect
3393ebc4-0689-4f55-9087-a60de3a34598	acr	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
74332565-499a-419e-a69e-b9d4899ce6ac	basic	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	OpenID Connect scope for add all basic claims to the token	openid-connect
a11cfa9f-9dac-4c76-8018-a00633007f78	service_account	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	Specific scope for a client enabled for service accounts	openid-connect
120a0809-cd54-4509-8d2e-0090ce0b21e7	organization	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	Additional claims about the organization a subject belongs to	openid-connect
3aa94e5f-8e2b-42ba-a86c-508aba36bec1	offline_access	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	OpenID Connect built-in scope: offline_access	openid-connect
e849e53b-783e-44c1-a45c-bdfe533f5065	role_list	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	SAML role list	saml
8fdcd5db-455e-4b76-8328-ca669a91a3a5	saml_organization	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	Organization Membership	saml
75ebc073-14b5-42db-ae35-b22346ba9c76	profile	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	OpenID Connect built-in scope: profile	openid-connect
11a57828-c689-4449-a15c-f4b29520780f	email	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	OpenID Connect built-in scope: email	openid-connect
83c5de7b-279a-41b5-86bf-74516fa1138c	address	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	OpenID Connect built-in scope: address	openid-connect
8de2d4d9-d12b-41fa-969d-d446df01ad51	phone	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	OpenID Connect built-in scope: phone	openid-connect
e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	roles	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	OpenID Connect scope for add user roles to the access token	openid-connect
235f04cb-37b9-461d-a5de-d4b02a934aaa	web-origins	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	OpenID Connect scope for add allowed web origins to the access token	openid-connect
c4912ba0-064a-46a9-a712-d73df14769e4	microprofile-jwt	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	Microprofile - JWT built-in scope	openid-connect
0460b492-55b8-4cd2-8e73-2673bc6f8a8f	acr	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
91246858-8e79-4627-87d9-bf924c3669d6	basic	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	OpenID Connect scope for add all basic claims to the token	openid-connect
d4e95fec-9fad-462f-9ae1-bd7719fbaef9	service_account	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	Specific scope for a client enabled for service accounts	openid-connect
c0df5c54-15f4-4344-a1b4-27d390ec3342	organization	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	Additional claims about the organization a subject belongs to	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	true	display.on.consent.screen
79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	${offlineAccessScopeConsentText}	consent.screen.text
56f54f1c-8537-4574-b880-1a96cfd95b7c	true	display.on.consent.screen
56f54f1c-8537-4574-b880-1a96cfd95b7c	${samlRoleListScopeConsentText}	consent.screen.text
25289ed7-2a9d-4bb5-be28-574e102d35f8	false	display.on.consent.screen
fd8be0d3-37bf-416c-9491-8eed1f661408	true	display.on.consent.screen
fd8be0d3-37bf-416c-9491-8eed1f661408	${profileScopeConsentText}	consent.screen.text
fd8be0d3-37bf-416c-9491-8eed1f661408	true	include.in.token.scope
c174415c-a203-4e6e-9047-631ceec5e059	true	display.on.consent.screen
c174415c-a203-4e6e-9047-631ceec5e059	${emailScopeConsentText}	consent.screen.text
c174415c-a203-4e6e-9047-631ceec5e059	true	include.in.token.scope
a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	true	display.on.consent.screen
a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	${addressScopeConsentText}	consent.screen.text
a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	true	include.in.token.scope
d17d9492-a4a0-46dc-ab0a-d43f33e10b12	true	display.on.consent.screen
d17d9492-a4a0-46dc-ab0a-d43f33e10b12	${phoneScopeConsentText}	consent.screen.text
d17d9492-a4a0-46dc-ab0a-d43f33e10b12	true	include.in.token.scope
ebedc40b-df6e-4e55-bb01-d683b157d4b9	true	display.on.consent.screen
ebedc40b-df6e-4e55-bb01-d683b157d4b9	${rolesScopeConsentText}	consent.screen.text
ebedc40b-df6e-4e55-bb01-d683b157d4b9	false	include.in.token.scope
1a8174ab-5f62-462e-9380-e926c127aa90	false	display.on.consent.screen
1a8174ab-5f62-462e-9380-e926c127aa90		consent.screen.text
1a8174ab-5f62-462e-9380-e926c127aa90	false	include.in.token.scope
a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	false	display.on.consent.screen
a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	true	include.in.token.scope
3393ebc4-0689-4f55-9087-a60de3a34598	false	display.on.consent.screen
3393ebc4-0689-4f55-9087-a60de3a34598	false	include.in.token.scope
74332565-499a-419e-a69e-b9d4899ce6ac	false	display.on.consent.screen
74332565-499a-419e-a69e-b9d4899ce6ac	false	include.in.token.scope
a11cfa9f-9dac-4c76-8018-a00633007f78	false	display.on.consent.screen
a11cfa9f-9dac-4c76-8018-a00633007f78	false	include.in.token.scope
120a0809-cd54-4509-8d2e-0090ce0b21e7	true	display.on.consent.screen
120a0809-cd54-4509-8d2e-0090ce0b21e7	${organizationScopeConsentText}	consent.screen.text
120a0809-cd54-4509-8d2e-0090ce0b21e7	true	include.in.token.scope
3aa94e5f-8e2b-42ba-a86c-508aba36bec1	true	display.on.consent.screen
3aa94e5f-8e2b-42ba-a86c-508aba36bec1	${offlineAccessScopeConsentText}	consent.screen.text
e849e53b-783e-44c1-a45c-bdfe533f5065	true	display.on.consent.screen
e849e53b-783e-44c1-a45c-bdfe533f5065	${samlRoleListScopeConsentText}	consent.screen.text
8fdcd5db-455e-4b76-8328-ca669a91a3a5	false	display.on.consent.screen
75ebc073-14b5-42db-ae35-b22346ba9c76	true	display.on.consent.screen
75ebc073-14b5-42db-ae35-b22346ba9c76	${profileScopeConsentText}	consent.screen.text
75ebc073-14b5-42db-ae35-b22346ba9c76	true	include.in.token.scope
11a57828-c689-4449-a15c-f4b29520780f	true	display.on.consent.screen
11a57828-c689-4449-a15c-f4b29520780f	${emailScopeConsentText}	consent.screen.text
11a57828-c689-4449-a15c-f4b29520780f	true	include.in.token.scope
83c5de7b-279a-41b5-86bf-74516fa1138c	true	display.on.consent.screen
83c5de7b-279a-41b5-86bf-74516fa1138c	${addressScopeConsentText}	consent.screen.text
83c5de7b-279a-41b5-86bf-74516fa1138c	true	include.in.token.scope
8de2d4d9-d12b-41fa-969d-d446df01ad51	true	display.on.consent.screen
8de2d4d9-d12b-41fa-969d-d446df01ad51	${phoneScopeConsentText}	consent.screen.text
8de2d4d9-d12b-41fa-969d-d446df01ad51	true	include.in.token.scope
e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	true	display.on.consent.screen
e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	${rolesScopeConsentText}	consent.screen.text
e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	false	include.in.token.scope
235f04cb-37b9-461d-a5de-d4b02a934aaa	false	display.on.consent.screen
235f04cb-37b9-461d-a5de-d4b02a934aaa		consent.screen.text
235f04cb-37b9-461d-a5de-d4b02a934aaa	false	include.in.token.scope
c4912ba0-064a-46a9-a712-d73df14769e4	false	display.on.consent.screen
c4912ba0-064a-46a9-a712-d73df14769e4	true	include.in.token.scope
0460b492-55b8-4cd2-8e73-2673bc6f8a8f	false	display.on.consent.screen
0460b492-55b8-4cd2-8e73-2673bc6f8a8f	false	include.in.token.scope
91246858-8e79-4627-87d9-bf924c3669d6	false	display.on.consent.screen
91246858-8e79-4627-87d9-bf924c3669d6	false	include.in.token.scope
d4e95fec-9fad-462f-9ae1-bd7719fbaef9	false	display.on.consent.screen
d4e95fec-9fad-462f-9ae1-bd7719fbaef9	false	include.in.token.scope
c0df5c54-15f4-4344-a1b4-27d390ec3342	true	display.on.consent.screen
c0df5c54-15f4-4344-a1b4-27d390ec3342	${organizationScopeConsentText}	consent.screen.text
c0df5c54-15f4-4344-a1b4-27d390ec3342	true	include.in.token.scope
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
2bdc8e7d-2806-4626-81da-da6449d58897	3393ebc4-0689-4f55-9087-a60de3a34598	t
2bdc8e7d-2806-4626-81da-da6449d58897	ebedc40b-df6e-4e55-bb01-d683b157d4b9	t
2bdc8e7d-2806-4626-81da-da6449d58897	fd8be0d3-37bf-416c-9491-8eed1f661408	t
2bdc8e7d-2806-4626-81da-da6449d58897	74332565-499a-419e-a69e-b9d4899ce6ac	t
2bdc8e7d-2806-4626-81da-da6449d58897	c174415c-a203-4e6e-9047-631ceec5e059	t
2bdc8e7d-2806-4626-81da-da6449d58897	1a8174ab-5f62-462e-9380-e926c127aa90	t
2bdc8e7d-2806-4626-81da-da6449d58897	a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	f
2bdc8e7d-2806-4626-81da-da6449d58897	d17d9492-a4a0-46dc-ab0a-d43f33e10b12	f
2bdc8e7d-2806-4626-81da-da6449d58897	120a0809-cd54-4509-8d2e-0090ce0b21e7	f
2bdc8e7d-2806-4626-81da-da6449d58897	79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	f
2bdc8e7d-2806-4626-81da-da6449d58897	a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	f
551feff9-1317-4fed-9053-411a8810c565	3393ebc4-0689-4f55-9087-a60de3a34598	t
551feff9-1317-4fed-9053-411a8810c565	ebedc40b-df6e-4e55-bb01-d683b157d4b9	t
551feff9-1317-4fed-9053-411a8810c565	fd8be0d3-37bf-416c-9491-8eed1f661408	t
551feff9-1317-4fed-9053-411a8810c565	74332565-499a-419e-a69e-b9d4899ce6ac	t
551feff9-1317-4fed-9053-411a8810c565	c174415c-a203-4e6e-9047-631ceec5e059	t
551feff9-1317-4fed-9053-411a8810c565	1a8174ab-5f62-462e-9380-e926c127aa90	t
551feff9-1317-4fed-9053-411a8810c565	a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	f
551feff9-1317-4fed-9053-411a8810c565	d17d9492-a4a0-46dc-ab0a-d43f33e10b12	f
551feff9-1317-4fed-9053-411a8810c565	120a0809-cd54-4509-8d2e-0090ce0b21e7	f
551feff9-1317-4fed-9053-411a8810c565	79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	f
551feff9-1317-4fed-9053-411a8810c565	a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	f
df3341ce-d4ef-49af-acfa-55791bfd15a3	3393ebc4-0689-4f55-9087-a60de3a34598	t
df3341ce-d4ef-49af-acfa-55791bfd15a3	ebedc40b-df6e-4e55-bb01-d683b157d4b9	t
df3341ce-d4ef-49af-acfa-55791bfd15a3	fd8be0d3-37bf-416c-9491-8eed1f661408	t
df3341ce-d4ef-49af-acfa-55791bfd15a3	74332565-499a-419e-a69e-b9d4899ce6ac	t
df3341ce-d4ef-49af-acfa-55791bfd15a3	c174415c-a203-4e6e-9047-631ceec5e059	t
df3341ce-d4ef-49af-acfa-55791bfd15a3	1a8174ab-5f62-462e-9380-e926c127aa90	t
df3341ce-d4ef-49af-acfa-55791bfd15a3	a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	f
df3341ce-d4ef-49af-acfa-55791bfd15a3	d17d9492-a4a0-46dc-ab0a-d43f33e10b12	f
df3341ce-d4ef-49af-acfa-55791bfd15a3	120a0809-cd54-4509-8d2e-0090ce0b21e7	f
df3341ce-d4ef-49af-acfa-55791bfd15a3	79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	f
df3341ce-d4ef-49af-acfa-55791bfd15a3	a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	f
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	3393ebc4-0689-4f55-9087-a60de3a34598	t
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	ebedc40b-df6e-4e55-bb01-d683b157d4b9	t
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	fd8be0d3-37bf-416c-9491-8eed1f661408	t
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	74332565-499a-419e-a69e-b9d4899ce6ac	t
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	c174415c-a203-4e6e-9047-631ceec5e059	t
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	1a8174ab-5f62-462e-9380-e926c127aa90	t
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	f
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	d17d9492-a4a0-46dc-ab0a-d43f33e10b12	f
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	120a0809-cd54-4509-8d2e-0090ce0b21e7	f
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	f
65755de2-f3c7-4ae3-a3d4-cc979fbcb147	a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	f
ab0b18a6-c7f9-46c6-930d-6600c036326c	3393ebc4-0689-4f55-9087-a60de3a34598	t
ab0b18a6-c7f9-46c6-930d-6600c036326c	ebedc40b-df6e-4e55-bb01-d683b157d4b9	t
ab0b18a6-c7f9-46c6-930d-6600c036326c	fd8be0d3-37bf-416c-9491-8eed1f661408	t
ab0b18a6-c7f9-46c6-930d-6600c036326c	74332565-499a-419e-a69e-b9d4899ce6ac	t
ab0b18a6-c7f9-46c6-930d-6600c036326c	c174415c-a203-4e6e-9047-631ceec5e059	t
ab0b18a6-c7f9-46c6-930d-6600c036326c	1a8174ab-5f62-462e-9380-e926c127aa90	t
ab0b18a6-c7f9-46c6-930d-6600c036326c	a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	f
ab0b18a6-c7f9-46c6-930d-6600c036326c	d17d9492-a4a0-46dc-ab0a-d43f33e10b12	f
ab0b18a6-c7f9-46c6-930d-6600c036326c	120a0809-cd54-4509-8d2e-0090ce0b21e7	f
ab0b18a6-c7f9-46c6-930d-6600c036326c	79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	f
ab0b18a6-c7f9-46c6-930d-6600c036326c	a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	f
924011ef-3a2f-4fd4-a007-37fe61577d11	3393ebc4-0689-4f55-9087-a60de3a34598	t
924011ef-3a2f-4fd4-a007-37fe61577d11	ebedc40b-df6e-4e55-bb01-d683b157d4b9	t
924011ef-3a2f-4fd4-a007-37fe61577d11	fd8be0d3-37bf-416c-9491-8eed1f661408	t
924011ef-3a2f-4fd4-a007-37fe61577d11	74332565-499a-419e-a69e-b9d4899ce6ac	t
924011ef-3a2f-4fd4-a007-37fe61577d11	c174415c-a203-4e6e-9047-631ceec5e059	t
924011ef-3a2f-4fd4-a007-37fe61577d11	1a8174ab-5f62-462e-9380-e926c127aa90	t
924011ef-3a2f-4fd4-a007-37fe61577d11	a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	f
924011ef-3a2f-4fd4-a007-37fe61577d11	d17d9492-a4a0-46dc-ab0a-d43f33e10b12	f
924011ef-3a2f-4fd4-a007-37fe61577d11	120a0809-cd54-4509-8d2e-0090ce0b21e7	f
924011ef-3a2f-4fd4-a007-37fe61577d11	79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	f
924011ef-3a2f-4fd4-a007-37fe61577d11	a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	f
55bfc23e-79c7-4a5f-96a4-503b7025f85a	0460b492-55b8-4cd2-8e73-2673bc6f8a8f	t
55bfc23e-79c7-4a5f-96a4-503b7025f85a	11a57828-c689-4449-a15c-f4b29520780f	t
55bfc23e-79c7-4a5f-96a4-503b7025f85a	235f04cb-37b9-461d-a5de-d4b02a934aaa	t
55bfc23e-79c7-4a5f-96a4-503b7025f85a	91246858-8e79-4627-87d9-bf924c3669d6	t
55bfc23e-79c7-4a5f-96a4-503b7025f85a	75ebc073-14b5-42db-ae35-b22346ba9c76	t
55bfc23e-79c7-4a5f-96a4-503b7025f85a	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	t
55bfc23e-79c7-4a5f-96a4-503b7025f85a	83c5de7b-279a-41b5-86bf-74516fa1138c	f
55bfc23e-79c7-4a5f-96a4-503b7025f85a	8de2d4d9-d12b-41fa-969d-d446df01ad51	f
55bfc23e-79c7-4a5f-96a4-503b7025f85a	3aa94e5f-8e2b-42ba-a86c-508aba36bec1	f
55bfc23e-79c7-4a5f-96a4-503b7025f85a	c4912ba0-064a-46a9-a712-d73df14769e4	f
55bfc23e-79c7-4a5f-96a4-503b7025f85a	c0df5c54-15f4-4344-a1b4-27d390ec3342	f
e39f027b-a76d-418e-80a1-190263cc2b2e	0460b492-55b8-4cd2-8e73-2673bc6f8a8f	t
e39f027b-a76d-418e-80a1-190263cc2b2e	11a57828-c689-4449-a15c-f4b29520780f	t
e39f027b-a76d-418e-80a1-190263cc2b2e	235f04cb-37b9-461d-a5de-d4b02a934aaa	t
e39f027b-a76d-418e-80a1-190263cc2b2e	91246858-8e79-4627-87d9-bf924c3669d6	t
e39f027b-a76d-418e-80a1-190263cc2b2e	75ebc073-14b5-42db-ae35-b22346ba9c76	t
e39f027b-a76d-418e-80a1-190263cc2b2e	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	t
e39f027b-a76d-418e-80a1-190263cc2b2e	83c5de7b-279a-41b5-86bf-74516fa1138c	f
e39f027b-a76d-418e-80a1-190263cc2b2e	8de2d4d9-d12b-41fa-969d-d446df01ad51	f
e39f027b-a76d-418e-80a1-190263cc2b2e	3aa94e5f-8e2b-42ba-a86c-508aba36bec1	f
e39f027b-a76d-418e-80a1-190263cc2b2e	c4912ba0-064a-46a9-a712-d73df14769e4	f
e39f027b-a76d-418e-80a1-190263cc2b2e	c0df5c54-15f4-4344-a1b4-27d390ec3342	f
373f86b7-985b-418a-ac28-01d9ef037e6e	0460b492-55b8-4cd2-8e73-2673bc6f8a8f	t
373f86b7-985b-418a-ac28-01d9ef037e6e	11a57828-c689-4449-a15c-f4b29520780f	t
373f86b7-985b-418a-ac28-01d9ef037e6e	235f04cb-37b9-461d-a5de-d4b02a934aaa	t
373f86b7-985b-418a-ac28-01d9ef037e6e	91246858-8e79-4627-87d9-bf924c3669d6	t
373f86b7-985b-418a-ac28-01d9ef037e6e	75ebc073-14b5-42db-ae35-b22346ba9c76	t
373f86b7-985b-418a-ac28-01d9ef037e6e	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	t
373f86b7-985b-418a-ac28-01d9ef037e6e	83c5de7b-279a-41b5-86bf-74516fa1138c	f
373f86b7-985b-418a-ac28-01d9ef037e6e	8de2d4d9-d12b-41fa-969d-d446df01ad51	f
373f86b7-985b-418a-ac28-01d9ef037e6e	3aa94e5f-8e2b-42ba-a86c-508aba36bec1	f
373f86b7-985b-418a-ac28-01d9ef037e6e	c4912ba0-064a-46a9-a712-d73df14769e4	f
373f86b7-985b-418a-ac28-01d9ef037e6e	c0df5c54-15f4-4344-a1b4-27d390ec3342	f
be74d082-fd6a-4cc8-910f-a65a46e13f28	0460b492-55b8-4cd2-8e73-2673bc6f8a8f	t
be74d082-fd6a-4cc8-910f-a65a46e13f28	11a57828-c689-4449-a15c-f4b29520780f	t
be74d082-fd6a-4cc8-910f-a65a46e13f28	235f04cb-37b9-461d-a5de-d4b02a934aaa	t
be74d082-fd6a-4cc8-910f-a65a46e13f28	91246858-8e79-4627-87d9-bf924c3669d6	t
be74d082-fd6a-4cc8-910f-a65a46e13f28	75ebc073-14b5-42db-ae35-b22346ba9c76	t
be74d082-fd6a-4cc8-910f-a65a46e13f28	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	t
be74d082-fd6a-4cc8-910f-a65a46e13f28	83c5de7b-279a-41b5-86bf-74516fa1138c	f
be74d082-fd6a-4cc8-910f-a65a46e13f28	8de2d4d9-d12b-41fa-969d-d446df01ad51	f
be74d082-fd6a-4cc8-910f-a65a46e13f28	3aa94e5f-8e2b-42ba-a86c-508aba36bec1	f
be74d082-fd6a-4cc8-910f-a65a46e13f28	c4912ba0-064a-46a9-a712-d73df14769e4	f
be74d082-fd6a-4cc8-910f-a65a46e13f28	c0df5c54-15f4-4344-a1b4-27d390ec3342	f
0f18f0e2-5dd7-4eee-893d-694455cc0af4	0460b492-55b8-4cd2-8e73-2673bc6f8a8f	t
0f18f0e2-5dd7-4eee-893d-694455cc0af4	11a57828-c689-4449-a15c-f4b29520780f	t
0f18f0e2-5dd7-4eee-893d-694455cc0af4	235f04cb-37b9-461d-a5de-d4b02a934aaa	t
0f18f0e2-5dd7-4eee-893d-694455cc0af4	91246858-8e79-4627-87d9-bf924c3669d6	t
0f18f0e2-5dd7-4eee-893d-694455cc0af4	75ebc073-14b5-42db-ae35-b22346ba9c76	t
0f18f0e2-5dd7-4eee-893d-694455cc0af4	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	t
0f18f0e2-5dd7-4eee-893d-694455cc0af4	83c5de7b-279a-41b5-86bf-74516fa1138c	f
0f18f0e2-5dd7-4eee-893d-694455cc0af4	8de2d4d9-d12b-41fa-969d-d446df01ad51	f
0f18f0e2-5dd7-4eee-893d-694455cc0af4	3aa94e5f-8e2b-42ba-a86c-508aba36bec1	f
0f18f0e2-5dd7-4eee-893d-694455cc0af4	c4912ba0-064a-46a9-a712-d73df14769e4	f
0f18f0e2-5dd7-4eee-893d-694455cc0af4	c0df5c54-15f4-4344-a1b4-27d390ec3342	f
5b81c8b8-e05f-4298-a125-4bbf2215fb55	0460b492-55b8-4cd2-8e73-2673bc6f8a8f	t
5b81c8b8-e05f-4298-a125-4bbf2215fb55	11a57828-c689-4449-a15c-f4b29520780f	t
5b81c8b8-e05f-4298-a125-4bbf2215fb55	235f04cb-37b9-461d-a5de-d4b02a934aaa	t
5b81c8b8-e05f-4298-a125-4bbf2215fb55	91246858-8e79-4627-87d9-bf924c3669d6	t
5b81c8b8-e05f-4298-a125-4bbf2215fb55	75ebc073-14b5-42db-ae35-b22346ba9c76	t
5b81c8b8-e05f-4298-a125-4bbf2215fb55	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	t
5b81c8b8-e05f-4298-a125-4bbf2215fb55	83c5de7b-279a-41b5-86bf-74516fa1138c	f
5b81c8b8-e05f-4298-a125-4bbf2215fb55	8de2d4d9-d12b-41fa-969d-d446df01ad51	f
5b81c8b8-e05f-4298-a125-4bbf2215fb55	3aa94e5f-8e2b-42ba-a86c-508aba36bec1	f
5b81c8b8-e05f-4298-a125-4bbf2215fb55	c4912ba0-064a-46a9-a712-d73df14769e4	f
5b81c8b8-e05f-4298-a125-4bbf2215fb55	c0df5c54-15f4-4344-a1b4-27d390ec3342	f
14f121b4-4d55-46e7-abd5-161dd1da7bbe	0460b492-55b8-4cd2-8e73-2673bc6f8a8f	t
14f121b4-4d55-46e7-abd5-161dd1da7bbe	11a57828-c689-4449-a15c-f4b29520780f	t
14f121b4-4d55-46e7-abd5-161dd1da7bbe	235f04cb-37b9-461d-a5de-d4b02a934aaa	t
14f121b4-4d55-46e7-abd5-161dd1da7bbe	91246858-8e79-4627-87d9-bf924c3669d6	t
14f121b4-4d55-46e7-abd5-161dd1da7bbe	75ebc073-14b5-42db-ae35-b22346ba9c76	t
14f121b4-4d55-46e7-abd5-161dd1da7bbe	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	t
14f121b4-4d55-46e7-abd5-161dd1da7bbe	83c5de7b-279a-41b5-86bf-74516fa1138c	f
14f121b4-4d55-46e7-abd5-161dd1da7bbe	8de2d4d9-d12b-41fa-969d-d446df01ad51	f
14f121b4-4d55-46e7-abd5-161dd1da7bbe	3aa94e5f-8e2b-42ba-a86c-508aba36bec1	f
14f121b4-4d55-46e7-abd5-161dd1da7bbe	c4912ba0-064a-46a9-a712-d73df14769e4	f
14f121b4-4d55-46e7-abd5-161dd1da7bbe	c0df5c54-15f4-4344-a1b4-27d390ec3342	f
14f121b4-4d55-46e7-abd5-161dd1da7bbe	d4e95fec-9fad-462f-9ae1-bd7719fbaef9	t
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	b9f75f96-29f3-4e58-afdc-7f5aaa28db9c
3aa94e5f-8e2b-42ba-a86c-508aba36bec1	c48730f2-f365-4d19-bb82-a587b0e9f9e4
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
0c73e68e-e8f4-4565-8dbf-3641c2644e11	Trusted Hosts	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	anonymous
901f9698-c3cb-48a3-9053-a1959a43e4de	Consent Required	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	anonymous
d246f25d-e408-4aa8-8c01-52f6caf6f458	Full Scope Disabled	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	anonymous
8dc3e43f-b64e-46cf-ad9f-17a1cb6c9885	Max Clients Limit	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	anonymous
1b95f786-61cb-43cb-b922-2ede8cb6848c	Allowed Protocol Mapper Types	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	anonymous
55e7db13-96a4-4010-8713-d1671e90b582	Allowed Client Scopes	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	anonymous
4b6ebf4a-6b98-4497-b9dd-61a0a559abcc	Allowed Protocol Mapper Types	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	authenticated
a3f0d7de-a260-41fb-919d-0fe5eaeb0f3d	Allowed Client Scopes	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	authenticated
8f20f325-fefd-499f-9079-8029b193f259	rsa-generated	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	rsa-generated	org.keycloak.keys.KeyProvider	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N
f7b9ab6e-5b03-4907-924c-25f4720e5026	rsa-enc-generated	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	rsa-enc-generated	org.keycloak.keys.KeyProvider	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N
9e8d0434-d42a-4c34-9541-de6a0e5a9c0f	hmac-generated-hs512	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	hmac-generated	org.keycloak.keys.KeyProvider	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N
50a86430-939f-4c92-9d27-4aca190aeb62	aes-generated	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	aes-generated	org.keycloak.keys.KeyProvider	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N
0025705d-586f-4af5-8f3a-9420cd4b5450	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	declarative-user-profile	org.keycloak.userprofile.UserProfileProvider	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N
25801703-4f7a-4310-b7d3-1ae17a458c39	rsa-generated	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	rsa-generated	org.keycloak.keys.KeyProvider	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	\N
ee3f8394-0778-4648-a26b-697b58eaa81e	rsa-enc-generated	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	rsa-enc-generated	org.keycloak.keys.KeyProvider	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	\N
98e76fc7-379a-445a-8f15-2eced5b99b85	hmac-generated-hs512	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	hmac-generated	org.keycloak.keys.KeyProvider	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	\N
a25c1de8-6f35-4669-9b10-6b351f5dceb0	aes-generated	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	aes-generated	org.keycloak.keys.KeyProvider	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	\N
d811a939-16c5-45d2-848f-e159d1d27b1c	Trusted Hosts	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	anonymous
ee73a624-6ed7-4ae0-b9ca-a9b6cf12d91b	Consent Required	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	anonymous
4fd1ec0e-c185-467e-bcab-306cb4a1db6f	Full Scope Disabled	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	anonymous
8bac1fc8-4049-4ef1-8303-fbeb67c92ef9	Max Clients Limit	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	anonymous
df4d2e5f-882d-4ef2-93d0-1984c29357ac	Allowed Protocol Mapper Types	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	anonymous
bf432bcb-b6e8-4e27-87b7-f37b3603b637	Allowed Client Scopes	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	anonymous
aa014a47-c160-47bd-8e64-20bee8fa775e	Allowed Protocol Mapper Types	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	authenticated
f9d4daca-5fa9-462e-8111-629a32d9dff4	Allowed Client Scopes	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	authenticated
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
f00029c2-d7c5-4279-b3a4-1e9bdcf83d9c	0c73e68e-e8f4-4565-8dbf-3641c2644e11	client-uris-must-match	true
176c4441-ef83-440c-9942-4fa2f3eda9ea	0c73e68e-e8f4-4565-8dbf-3641c2644e11	host-sending-registration-request-must-match	true
c8ff4a27-48b6-4f5b-98d9-943469e243ec	a3f0d7de-a260-41fb-919d-0fe5eaeb0f3d	allow-default-scopes	true
098611c7-0df3-44b3-a724-f5c786a87aba	4b6ebf4a-6b98-4497-b9dd-61a0a559abcc	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
a3a405a2-3266-489d-9763-303f173623c1	4b6ebf4a-6b98-4497-b9dd-61a0a559abcc	allowed-protocol-mapper-types	saml-user-property-mapper
9eab98be-915d-4952-bd76-d06f25bdc3e8	4b6ebf4a-6b98-4497-b9dd-61a0a559abcc	allowed-protocol-mapper-types	saml-role-list-mapper
6c7634df-2737-447e-b455-abccf0456075	4b6ebf4a-6b98-4497-b9dd-61a0a559abcc	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
f06e8092-59ed-4f30-97ca-0c74f35e4f00	4b6ebf4a-6b98-4497-b9dd-61a0a559abcc	allowed-protocol-mapper-types	saml-user-attribute-mapper
865165e1-7b0e-4048-a798-692d43b5383a	4b6ebf4a-6b98-4497-b9dd-61a0a559abcc	allowed-protocol-mapper-types	oidc-full-name-mapper
7652c23c-3bbb-4054-bf23-ea64d9b77b16	4b6ebf4a-6b98-4497-b9dd-61a0a559abcc	allowed-protocol-mapper-types	oidc-address-mapper
5a0b4539-4d02-4079-b4a7-e53ddce95d7b	4b6ebf4a-6b98-4497-b9dd-61a0a559abcc	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
ca6ec77d-1e77-4d14-b291-627217bc1c7a	55e7db13-96a4-4010-8713-d1671e90b582	allow-default-scopes	true
d5d93e40-048e-4644-95a1-c645b67a48a8	8dc3e43f-b64e-46cf-ad9f-17a1cb6c9885	max-clients	200
86999708-c3d2-46eb-af42-88fef41d8502	1b95f786-61cb-43cb-b922-2ede8cb6848c	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
ac193a5f-d732-4c0d-899e-b385151be1d2	1b95f786-61cb-43cb-b922-2ede8cb6848c	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
d630f190-e561-4526-8830-9352db42403d	1b95f786-61cb-43cb-b922-2ede8cb6848c	allowed-protocol-mapper-types	saml-user-attribute-mapper
6814dc14-c402-41a5-be76-9cb459911068	1b95f786-61cb-43cb-b922-2ede8cb6848c	allowed-protocol-mapper-types	saml-role-list-mapper
acf99125-a0a0-46ce-b186-c3e5f34881ff	1b95f786-61cb-43cb-b922-2ede8cb6848c	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
3196ddc9-0f90-46b2-a865-44f883eed289	1b95f786-61cb-43cb-b922-2ede8cb6848c	allowed-protocol-mapper-types	oidc-full-name-mapper
f8c0c4f2-3c98-481c-8141-705b6338f9fc	1b95f786-61cb-43cb-b922-2ede8cb6848c	allowed-protocol-mapper-types	oidc-address-mapper
5648a392-83da-4f6c-8745-ec8acac61324	1b95f786-61cb-43cb-b922-2ede8cb6848c	allowed-protocol-mapper-types	saml-user-property-mapper
361b2125-079b-4651-ab90-dd3105d08af2	9e8d0434-d42a-4c34-9541-de6a0e5a9c0f	priority	100
ec08c17c-0f27-453f-8e31-ea3f731f8b52	9e8d0434-d42a-4c34-9541-de6a0e5a9c0f	secret	I7u5tRNveFDVMRl9xUJrssPI3GbhJYK5rUqIgAgnJol9PfXQLOfd9D0b_069fRFDhmFYHB3PjHVzUP6GvKQBe0SkXw5aTcToypE5_rfuFoNZRnnRSKolp6O0r4sxKvM0fe4fnTGJj2ED9-F50aEYoGBTTIbNMyonfJ2zXmH8PpM
1d9bfce2-91e4-435f-a1ef-52235398d60e	9e8d0434-d42a-4c34-9541-de6a0e5a9c0f	kid	a7440b48-0c3a-444a-9bde-6794efd3b10d
c4e95493-bcd6-48a2-b270-2fb13c382631	9e8d0434-d42a-4c34-9541-de6a0e5a9c0f	algorithm	HS512
4f7e0de9-248e-433b-9752-eb8750767ab7	50a86430-939f-4c92-9d27-4aca190aeb62	secret	dJuBEBXF8y8n8QHDiyuzbg
da4b54ba-856d-4317-b0ab-b0474ed845ee	50a86430-939f-4c92-9d27-4aca190aeb62	priority	100
c17fb07b-e518-43ad-a7b6-a81ca696bb0a	50a86430-939f-4c92-9d27-4aca190aeb62	kid	0f288fef-babf-4268-bcb4-4943b7909a71
08ebbe84-31a7-48d1-8e43-eed615e068cd	0025705d-586f-4af5-8f3a-9420cd4b5450	kc.user.profile.config	{"attributes":[{"name":"username","displayName":"${username}","validations":{"length":{"min":3,"max":255},"username-prohibited-characters":{},"up-username-not-idn-homograph":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"email","displayName":"${email}","validations":{"email":{},"length":{"max":255}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"firstName","displayName":"${firstName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"lastName","displayName":"${lastName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false}],"groups":[{"name":"user-metadata","displayHeader":"User metadata","displayDescription":"Attributes, which refer to user metadata"}]}
25ebb9a0-c158-4e2c-acad-6d428091acf4	f7b9ab6e-5b03-4907-924c-25f4720e5026	algorithm	RSA-OAEP
5f6a9653-5eb0-429b-a6da-91ace7fa19ff	f7b9ab6e-5b03-4907-924c-25f4720e5026	privateKey	MIIEogIBAAKCAQEAyj9mMa94f8EteEvQTAcLm+los3y5Fmom7WgAQDZzA/LsglYAWMP1szNzsfsQphKWIUK5C3qmjUZX3ujuL0727mPHNCCcFKgVeQ8NTfjC2ulsHwJITAO25Co1fleYCJod0ITYJ0PpAfx5soU2rMAyxwwKaSeb4n6ZKT4hTH0GTUxRDAUHTfiIwDrNKtm9CtbJzdq8PgIIeYBgHNaSTOS4Ueu7IWFEylUd4gbF6Cw1tZdQI7NNEqk6HPEdcUBG+NAMlXXv3FMYFW/tbQwb5PadCddiOKNOnUs7Q0W1HA5yLuCR4T1r2nvr67QpClI6u+SjDDCc5LYo+vIfxKyhIfbMWwIDAQABAoIBACqEeIXydxkYcegru/73rjOZNpchHcH+D+/x4LefGr/WRm1CCjGfBJynMOfWOZJILwKQBdnJb5EcnCVy/3u3lIbaOAsX3egjy9vW07u0E7a0wrOkJbHBSCYgT32fiYkpaSIog06B4s61lpn2kl9vylz5BYlEt+s+JRG8C4EKeZQvGsX9VK1cL71txyqzEvj5qEHhNbb3zhmbitadeX2cdSA6SH6vOUAX8n/ThWhcMf+9ZRPXIR1+dVYpqsX9VWCSSWPClLuAvcPth6fcGSmQzhSte+2EmXmtVgbfisZjxIaLsdIHeMMNkp4Q6Y4lYqO8HnJ7baX6r/w2kjpQRzXfPk0CgYEA7nJA+8hQwWR+XJzG3qwP/DOueGJxA0oDQumVJ2x3FoKQRUhHKk4YFzTUpjqxIA4u34kjEF6SbNKt2u/dGpYHlnd9sGRvzHW3arPEs8Fw58GYp6KgXdho9myp3WEKLs5NG1lHpQT9/+kkpEL/PR01HG49/tlIfR5H8CY9kJPTnS0CgYEA2SLykZvE8vdCRufyFEg54V8rY9dzTtU/Uuo+sYLFhnIs1iBPRjW4QPEI41tJJpUbjhQDsOzq8c8Pq7ewPZpbGB/FypLUse2IVnmf+2sM8CWu4cX39ZEviMajGIh5uYTS0UbRoZZ8mXh05iuBPisIVvkuzuL2RTaFhHij0zUK1KcCgYBJjYTuJgSDI3S3LMVLutfTfD29dOBXm2UWJueTmanCj9PhC0Kokh5sSieufzxUHwvmeG8QhZu1ZeerOYKCyPTePU3QM6so7sb9ayaqLGmfk+B7FXdSe4clPK/JUj3J4ml2njuzc67GWiyrXt9NAs13T6pgCraJoeWe9qzXBEKqoQKBgFCG7nDj1RHKc1D6mkO9WYHkmqHneEMHQPnOF7wbZIfs9gXfa6b9Kz0iZwpyg1mEuPhjIc9Ovf85rHUhpYHjKd9zgRYUiD8IeaSgbJ2AYQb64rWmhsQSuQ8/o6LokkQkJ08ntXz443LDQo9OGRtmOCyRMzPU5kJa6v9rAk7FACRHAoGAHn9vPB3JcnYJft73AJFjgzJPlhQAhGC3EjxwCkowO9wrzTEwUwI1PQm0UNLnxtFV7xyT4dkAiLbfE+sVwd4pZvzgG4T0ylC/H6NZTMwVHlDsFB7/h7zCjAAq/AC+F45j8Mdmj8cszOI56iicduP2GhUubDFi37wzpHfs9CHICRo=
1cb7c68f-287c-4940-bfe0-b84b51a1190f	f7b9ab6e-5b03-4907-924c-25f4720e5026	certificate	MIICmzCCAYMCBgGdT1BYvzANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwNDAyMTc0NzM4WhcNMzYwNDAyMTc0OTE4WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDKP2Yxr3h/wS14S9BMBwub6WizfLkWaibtaABANnMD8uyCVgBYw/WzM3Ox+xCmEpYhQrkLeqaNRlfe6O4vTvbuY8c0IJwUqBV5Dw1N+MLa6WwfAkhMA7bkKjV+V5gImh3QhNgnQ+kB/HmyhTaswDLHDAppJ5vifpkpPiFMfQZNTFEMBQdN+IjAOs0q2b0K1snN2rw+Agh5gGAc1pJM5LhR67shYUTKVR3iBsXoLDW1l1Ajs00SqToc8R1xQEb40AyVde/cUxgVb+1tDBvk9p0J12I4o06dSztDRbUcDnIu4JHhPWvae+vrtCkKUjq75KMMMJzktij68h/ErKEh9sxbAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAAwNFaoE/bhsJYs6tZWF3yK8EZbrBnFmu4/wrS5EcWKZEW7iqngtCNqFXvvrXI4jI4izLLJS5Y8wpztdnOuhefsOtWRUv6J4JPg0eQAo+F3i2gjcktTUugJxhH/DobRs+bqxKDYq2Hc8WARCTzV0lYCdqX5z2ObCyJwPlVPd2XKZ//g/RmHhHSa52f2mlINUIrKGZVPUlpfxe45Zjlm6vlCu0yoHqZCxJQnHqtSdoiPIaSMwrdyWuMIzzuMzRyQ5SuwV7KBkp+OQIuSjnQ0BDIJEHsJinOh689dU626qWoYTL53Xrd89+KN+hMetUyFneTTFmGPZnf952dTc3H/pPhk=
8518a8da-9245-4adb-9aa3-0155a7abd87d	f7b9ab6e-5b03-4907-924c-25f4720e5026	priority	100
aacb9bae-76dc-4894-9d59-0474fb4f38fe	f7b9ab6e-5b03-4907-924c-25f4720e5026	keyUse	ENC
9269de0e-a779-4163-adb0-5da5af712f17	8f20f325-fefd-499f-9079-8029b193f259	keyUse	SIG
1f15f202-07c8-45f1-9975-03da29efa310	8f20f325-fefd-499f-9079-8029b193f259	certificate	MIICmzCCAYMCBgGdT1BV5zANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwNDAyMTc0NzM4WhcNMzYwNDAyMTc0OTE4WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC492PIczLTgjYuy6YLylI3/c4SIIMiLoI47yCio77Vg/wkNybKlbGuGC8TPba75pm9ccWkIN5yIxVieGuZmdGt+X58/4J3k1p17zxQXEMU26IVMfRHx/Zie1FCImsNOwn1ApygDi1cnhfd3Yw0ZArARKG9oFVtcUXkf7r8PAQt3BvM+cFnV07AYeQmp3T7Tpi1QAnACXsAPxzPu/G4mmDHWYn8sEGxHjNSm5zcK0xBP2h4hBTWz+qJK0QURxFbMXmrYs2b+qXt67aQ5BoEvS2uTu0Z99xsN2E8KOwMjsSOHMb9scfDV/ZgSQcMEYgEwOSH+DnQVAfcKfaSN7Z32WnXAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAJDew10wrICPm0KBTR7TBg9uPpl1XfnTPuTumT3iDa8U1bq7QTp3+fMx2HoRiZEakrf2pSblFUKN/nRMdy4CUi50RXc+xK7ar25DOYC6DknlLgnTfm7Hyk5aNAxo/MtWBig0BtGH6GyUVAzPfLV8u+3V2oVj+3uZWl+V76bcDPzywATdLOQxNv6hYxUBV6SgJjQBQBRKSWm1ZZlBz8RynclacHO4ys52x3HFNWgeNaZraYiiZ5DbsGpsjJIWbqB+PCpetzRA5F6bF3ebqneeT718KWtP7bNv7H0lkPR8B8B/CqEkYNsYMOm1RX8fgdM91m919KXHeJW38QPBybuEj4M=
c8c96e3d-c214-4876-8916-ccb9793772f9	8f20f325-fefd-499f-9079-8029b193f259	priority	100
67627bc0-d5fd-484b-a72c-1c5a22fa7f5d	8f20f325-fefd-499f-9079-8029b193f259	privateKey	MIIEpAIBAAKCAQEAuPdjyHMy04I2LsumC8pSN/3OEiCDIi6COO8goqO+1YP8JDcmypWxrhgvEz22u+aZvXHFpCDeciMVYnhrmZnRrfl+fP+Cd5Nade88UFxDFNuiFTH0R8f2YntRQiJrDTsJ9QKcoA4tXJ4X3d2MNGQKwEShvaBVbXFF5H+6/DwELdwbzPnBZ1dOwGHkJqd0+06YtUAJwAl7AD8cz7vxuJpgx1mJ/LBBsR4zUpuc3CtMQT9oeIQU1s/qiStEFEcRWzF5q2LNm/ql7eu2kOQaBL0trk7tGffcbDdhPCjsDI7EjhzG/bHHw1f2YEkHDBGIBMDkh/g50FQH3Cn2kje2d9lp1wIDAQABAoIBAAMskrSr18Q1inpBzt97KLMZZZxQut5rHrmOGejb4p4Q6x3lKN1QxKqSc43EzHeRXNk3lhJFB04XpVQ9y7l+5BQWRvqFzdo9dhsQWf5SkkrzhAxctlRj1tcYgsYs4do8VJoPPGoi9+ki6dykaj0dGTWpdBVVYr4lSj6kHY6TIruxw+UmJtLIlvM2B0NqM1j0ADVei6DbBTLCw5l1ED5IoTQRq8p4KdWrsBmiyFDjU/Vpkt6FXdwav/2cF5VYFNZTukFhmQ/0ZvIeUv1IhYX8uEVscPaikziNWsSedDRnZztEk+V0bV6fJeW147CM6Bn1gKIuZbM8ADr7gMTCJ49/HyECgYEA/erMcyyVJjET6B8KwKJisrAowxYjcr+HcYw0SJY+75/bqbKEAWMYgk3LuAHk3+PfP49hjQ0bq1ekDkDSIdaSISyVnbhivS4tB6NRw8i8isSzBGxWoqH2CKYoC172+vD6LPF9YNvdW8ASgD/T7Lv0e/MQJBdtasJQFL0ZAcZ+IScCgYEAunvNF7UgspnEWYKjqvCCOru+cs/3KLFOwhHgegDbpVKYaA6ty6MJKHZwJBL0dX0fSfmyrc0uOEhkfJXtMEIzbM9H7KBucz3voBZ0d86vqbH/5XXwf97FeIpDeoTzSGjx5HKQLPSQPoyoqf5GzebVwO7JEwH08S3xZdY41kzif9ECgYEA1vPGUFoViVdSutZMi/bsBskKONys9Z8eUgmW2TwX21NA6c+t4F67iNPC+ergjoihnXUL6BSIr+xpfYdyXCMBYgQURIirTeuhQy4HMe7lbbRGuB/e1560YW4HyFiETLtjjliBA1YddmaLQvbFuUsEFUoXB/atMgt9L5FFcjNO41ECgYBjZGyxgBaHWrFuS9TT3RBsIXimVPWUuLwTb9fG7wIioV0dyQUUjjbpXAb1Ey08GY49rVpwi/VghiUYygf7Oq2SBwB8vB1iStaW6qD04jJ6LacIM84VOTTixD6m5ImORHD4o574dvkSfYG/6Qjv4WJ4TEzbVqWojiYlcwIkJiJqoQKBgQDXvCchGHEtRTLRHjV/w9nDUu8VHUqBX2RxbP/EuGopt2gzqYBQe3CSjeiOAfrQ8MAqW7/wkZTxJy64OExGslhCuW5u4cR1Eg+v20KNL1fyb/v021h3CS+yr8k5JzkQ84OHVTwdacNUSMRjoUYy2e332BKMIj48OTw/V0Z15ZR5xw==
1ea4dadc-695c-40b7-8ce5-f4963003fdb1	25801703-4f7a-4310-b7d3-1ae17a458c39	priority	100
ec381553-e9b9-431a-99fb-b79ce0052988	25801703-4f7a-4310-b7d3-1ae17a458c39	privateKey	MIIEowIBAAKCAQEAyC6veDkAyvMY2E4F959DZ4UPCF/opfcYdlr/EvXSaExhJi26M7XAzz+7FG95aC7MOM0QcispCWxqk0KYZAds58CxZlQMdblFQ9Wxv8vrqSgN7hH0lik+F78DTrvRnWtXU5nwfSTWpBaWyYwjI2B400X6up62lPsoGLW75oTp0hQxVSo7h/kfFwJQfKTjhNdvUQgLflMDJ8N0tUHE0BCcj14IHkVxHmZOEYNxsirHTy726URb4JFPkRQN6LyyRf2VF5PAvD30R78XROMLYo/m1ST4YJ2MYpLhQ/RqDZ5wBjaiZtE2OauCeKWodTDiJ31N1env4NK55OdyUwrYA+nElwIDAQABAoIBAESeIB6tJ3TpxFPs1sXNDV1QMll0CrrNCtETGwkkQzXmLIzaMs/j1s4Tsexs06hfFjjILgF8guoMhDGrK7JqCy4bkpOZbtXxpmj8uJueak7HAJNhCz5nr7WTD66u2cjEkSACjflPpdWEOramdyr6uB/vhmTu33YM628g6GI5oC6Wiypkn0+gdNSx9f9/SPyQK6Vo+8/qr20efucKaRzc348EB+vIjUQpv17xZS8zcCme0cvXH9KWnHSWJIe+9WLLNQX69zmPKtrJl3/YGljow6KLRa91mYX2tf57JLqOA/8isFYi1QBnkS8ONvEKoVb3uZ4xGnUV0rZWjjIj4mFJBdkCgYEA4mY9BoocPAwUgCxs0o1lGwENxabHMApKgT3WxpOf1DQfaOHkGYxnWxPXN5gO97bRaQoPmPgwqfwLVCrGpottWkRPms7tsDKdtLP6VwDmtENqjYH8SVelhPbvnw5dGD19VjNwnTlWTKmiTpS/1NHVxGDH33YcsjOMtHe1fjYoSSkCgYEA4lrxlhp8ZkTQ6uZvRfEF9vaQphGi1xa6IPsQWXkeD82rHD/bM7j1NJaijmO9rYVtB9PVg4WoJiQinBSEiXAtMPueY4my4U9xb9wkg1hsY6cosoGmEL234ALGF1LYljm0d1dhXA9OXD7BXqMhsYGnGOQl5DL7i+YaNQIyncWUl78CgYB+O10ZUVZO0Ll5gcunVjkiZmMEamozSfmiuBURoWwDSJCezRx+dj+Gk7hzAfCOg7udIoPx2ahgjuzOIA+k+qadJutvuKLklEREZflWG2WG6vP1NJ2zUxAx4/FVMRANHPPOZV4L+9U3Z3nc8KlJAzp6hS/MU7HKVl3End5vIckyiQKBgQCAvg8oO7pDhKJ66EOjuTmWRJjzC5bd1TxaI9IhwaSagnTvJVasrWcx2PduG0a32eqwiAipvKxtvSG+OmFDtnzNnl9w59HJGqE/aSuPVQyZBWs9VEY6wV1C2PEINQOhNgLx2c4zSTVdfAgJpqk0R7TdkG4IxAKUiHShb7WQTN9+CwKBgAfwWEgy1ORMSLaKDeQ9sDuCGvyCv9Kkqc5/1ePOrPBWWdzXFONNDb9PIcpK41FYhmeFAYPuH4EuKDKZtRXcxHSRKjunvXDDYTNkvQ13yR6+VC8oBxi6JV/khkA5LtV17qvd1B0jaLen+zV1nAQfJgWI6UhXbiGhJ0pBMk1T/6x6
8730c28e-f60b-4a51-804e-003d38485236	25801703-4f7a-4310-b7d3-1ae17a458c39	keyUse	SIG
66ff44ca-543a-4104-ae1b-4b85fdcc3ddb	25801703-4f7a-4310-b7d3-1ae17a458c39	certificate	MIICnzCCAYcCBgGdT1OTlTANBgkqhkiG9w0BAQsFADATMREwDwYDVQQDDAhxbS1yZWFsbTAeFw0yNjA0MDIxNzUxMTBaFw0zNjA0MDIxNzUyNTBaMBMxETAPBgNVBAMMCHFtLXJlYWxtMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyC6veDkAyvMY2E4F959DZ4UPCF/opfcYdlr/EvXSaExhJi26M7XAzz+7FG95aC7MOM0QcispCWxqk0KYZAds58CxZlQMdblFQ9Wxv8vrqSgN7hH0lik+F78DTrvRnWtXU5nwfSTWpBaWyYwjI2B400X6up62lPsoGLW75oTp0hQxVSo7h/kfFwJQfKTjhNdvUQgLflMDJ8N0tUHE0BCcj14IHkVxHmZOEYNxsirHTy726URb4JFPkRQN6LyyRf2VF5PAvD30R78XROMLYo/m1ST4YJ2MYpLhQ/RqDZ5wBjaiZtE2OauCeKWodTDiJ31N1env4NK55OdyUwrYA+nElwIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQAZQDZXEcqdoRQolcAaof9T0Cc+uVnA0Oldk97RbCOWFy1CaVQ8xtLthLdmRk/VGQr9oc56uPc9BLV4IF210XpoCHizCoqt17TRZC/JRrP5j5r4DPKwXnuTYFYArshswWjIWYDHJUjtUlcizTybTJuSnTbyx1lEKEW4yVVG6GiLu/rvutntHOqOG1aBsuxn5nSc69VoKW0QVj4CcdCIrEwfFaqfbPRmH0R9nak9bIigElNY0a7/nU+s0pnJZG3R+RKyby6OdrgY/a9z/d1zuhjsAtlua1yhVrWNDc1otZHY2lWftlE2iDNGIYqAr/OFbu6URjWZto1c7Ob8rvBJ6HvM
d9c2de0d-122a-4656-a319-bbbb679cab50	ee3f8394-0778-4648-a26b-697b58eaa81e	keyUse	ENC
2633da1e-977c-4453-89db-c32a28862100	ee3f8394-0778-4648-a26b-697b58eaa81e	certificate	MIICnzCCAYcCBgGdT1OUwzANBgkqhkiG9w0BAQsFADATMREwDwYDVQQDDAhxbS1yZWFsbTAeFw0yNjA0MDIxNzUxMTBaFw0zNjA0MDIxNzUyNTBaMBMxETAPBgNVBAMMCHFtLXJlYWxtMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApxiDtLGT5S80NzYjXMoSyGe+eI1c9s1AzHp/O7dw7POmCqO1qogp0wFedFqUrSzH8VP0pt7556Y0rUYxlIqwhIoVATRNb7uay/lmTLqYkL6kIX/+XlRfM/Yg2uGfP5fhZ3gJJifxwi7vL4+RxHPlR+rRjKMLq0rxgu65pev2ruo1EuXmczp4iWOsweSu4f0ZXBFwFhEF8drE84ltOisocXkMvuRCoTNAUMWZqx+Qz9fQsG9d6gdlj+RFZqmje5giZVJbAQQdi/SQE+ur5Ut2q9RdKp/aM22WYUZTta+whszOV9+DC6x4ieCMlQaMVI9CkBrcvQOX0VsAwFyE+m6wtQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQAenwjCmL2dbXU/eYdex/4mtnG0VH5UJnezBbH6oUdb5MrEfDWbZnmYx3t3XM0Z8RyMaoW6IOaPXq7R1IZuWRqbDi5loE3tLrbxiS1oLKEIGmY0gkqQ0SJ34UsnxQeJjbplQVflYKXjmfAcJZ6XgSPbbvRIvgYmYUvWV/aAaNfBA0RYOHI6b3rW+vnPmfmOqWdgJLr3fgfa/HNSNiKtLNVAYivN4jYKjrQztUhCjQ7JCfZN0gI4bqYDTgIIECNQ+Jucn+fRxPQOmb14szK3VxbHsfAi68TgmRBq1BRZCs4RHIncVYzUJYjUIROXLhph81lzdXVqvv1JthyKr81/0ox3
4fa09254-c844-4753-82ef-7c67f46bfff2	ee3f8394-0778-4648-a26b-697b58eaa81e	algorithm	RSA-OAEP
231a22a1-1c0a-4dba-9014-f6632aedc63b	ee3f8394-0778-4648-a26b-697b58eaa81e	privateKey	MIIEowIBAAKCAQEApxiDtLGT5S80NzYjXMoSyGe+eI1c9s1AzHp/O7dw7POmCqO1qogp0wFedFqUrSzH8VP0pt7556Y0rUYxlIqwhIoVATRNb7uay/lmTLqYkL6kIX/+XlRfM/Yg2uGfP5fhZ3gJJifxwi7vL4+RxHPlR+rRjKMLq0rxgu65pev2ruo1EuXmczp4iWOsweSu4f0ZXBFwFhEF8drE84ltOisocXkMvuRCoTNAUMWZqx+Qz9fQsG9d6gdlj+RFZqmje5giZVJbAQQdi/SQE+ur5Ut2q9RdKp/aM22WYUZTta+whszOV9+DC6x4ieCMlQaMVI9CkBrcvQOX0VsAwFyE+m6wtQIDAQABAoIBAA2ahdJ2qJM+ihI6opthyjCtnYij/Z8MK8vZ5zTd5OAtn+V62YXmKv2GPYHchAErRaXkj2Tsf0z4L46xycSNm/xWX4pnDyzbCam0hrsVb+lM1AD0MinM1aldzuPy/WuIem3ZjGkiVGDaQFfPaO8k/lQiDmhUN9V8tvfRZqTW9pDb18FIYu+0YaarS3IZpO3166xHs1gQg0XtBt0vOrGeZLFnUQQlQA3V8yJr4Wtf8fihy9zhVXcvBDuho+87dyqO4ZNpI71WHbN0zhsy39ar2y2hmZiW5eBWdmn3DNKGu/GCrbm20rMMAy+YaudQVOe/IL57DjhigLX8+NBxWpQ6VkECgYEA1DA4o07kP1C6SUWoXLz8rXBbGtVnBqKI+KuI+5cFKOnPUdE0bPUIziqf+4pfB/tLOYKbxoz3+nz9VEZBJbQzD1G0UCJTXE2rtVxTGP2nEZpY8fWJjd0KLsfa3SPX1XqG2gNe4iyimhwArPtUJ3pJNcj2r9yL5MLf25n+SDB2PdUCgYEAyZjN1J1N7giQVlf7Zt35RBx9kO15BFnJ84TolFWhuZWHZ2uTLkOwJR9bYzIUXSPri1HBJnDH9I4M1+Ub61dbqfYZWFwL5FyPW9UhAS+UYGQLD79X3X29c7fE6LYvip7xngrTeIzEC8oi1I3DLTcpjMjg0zRBPKpD1UQ0NJq2t2ECgYAySn+SDUfBzfNpHG5sFIra3K9rK7swcmN+dMGRx9h8OvZdUPVZAbaljqq+ZqxhaukIZ3FeXNkFcIxmZgRY2F3lupq/B3O0g+A3qvszCCOJ44hDSMviaMpaDhpMoYstWM4PbA8YEjYzyoFKfoMSnEQv0ELPqbkqbhm6pcQD/iB4RQKBgFeVzK833JizHcp1lSL/A4IFAsTJd49dVzE2qDlx7r6LaXWUNjCeddPbCMBTDKfeqEIyNcF2tFjaslfGEVgw7wEri51o+D2xvRL/yMQUINmz/V5NGmZ/b6TrzV/xbzxBi+XG/FNejPo2SuWf5ZEqayHgUFVSWZl6u9fXNvs30HRhAoGBAJANup+Cnab/+VfdIocEu7Ztdm58Mxj789bJV5YbLlkWDkcCkTspUogVbzNG6oB5hS92TZxP6ylkf8djua4ySRFjrb4IQQk1Pn7HcNmJbFpiz6T1HEOu9VmdzwDTB60zfoFU8Ap+32j1Ofa5A+aCq0ZJW1Dxe25L734o13VAPT2N
d1b363da-e7b3-44ae-9832-f4b683c3155e	ee3f8394-0778-4648-a26b-697b58eaa81e	priority	100
bbedd2ba-f48a-4b41-ab0d-4861b5a2a1ea	a25c1de8-6f35-4669-9b10-6b351f5dceb0	kid	180103d1-d17b-4aee-906e-3cd222c5a53a
cfc59f2e-f765-4362-ba6b-1efed11badf2	a25c1de8-6f35-4669-9b10-6b351f5dceb0	priority	100
ffd8ee20-ba68-4bb7-bbfc-d09c6231f261	a25c1de8-6f35-4669-9b10-6b351f5dceb0	secret	Jx2kggTwxcefLr2354wI4g
84b488c6-4b89-4c18-815c-a36d258c2712	98e76fc7-379a-445a-8f15-2eced5b99b85	secret	G4Wp-zwuvuXJNechUYyFSPi2J5jt4-c2lzgIaKOwz8m9ww1fWieEDh74Qt67jsgTwENfl0PT0gl2DFb7pfsTSlyHpBFo-CNuIRIXWqRXtuUKO5pLh97MYs9Uid7OvVUzqaHoZHNO5kVgqbaLVb5Go7TcfCE6fh3GSSfZbDsfqt4
f95230c1-c934-49ec-9a65-d8134ef73964	98e76fc7-379a-445a-8f15-2eced5b99b85	kid	bce89945-794b-4459-9f3c-fa809f16244f
ddc9c209-2508-46ab-aece-88d654d1aab9	98e76fc7-379a-445a-8f15-2eced5b99b85	algorithm	HS512
3c2f4a2d-ec11-42c7-b5e5-03e1754c5e78	98e76fc7-379a-445a-8f15-2eced5b99b85	priority	100
98ae3b2a-3d97-4581-87bc-b40883ee8edb	8bac1fc8-4049-4ef1-8303-fbeb67c92ef9	max-clients	200
2f2261ad-b6f5-4021-85f7-2046da4568d5	f9d4daca-5fa9-462e-8111-629a32d9dff4	allow-default-scopes	true
6d15b33e-a465-49b6-bdf2-a181ba44b5fd	aa014a47-c160-47bd-8e64-20bee8fa775e	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
7af2b8b9-f3a1-4674-ac5d-36db1087638f	aa014a47-c160-47bd-8e64-20bee8fa775e	allowed-protocol-mapper-types	saml-user-attribute-mapper
4ff1c758-e496-40a0-b54f-6eef46d08379	aa014a47-c160-47bd-8e64-20bee8fa775e	allowed-protocol-mapper-types	oidc-address-mapper
537f8ccb-0bcd-4592-95b1-c9c2cd7d9c68	aa014a47-c160-47bd-8e64-20bee8fa775e	allowed-protocol-mapper-types	oidc-full-name-mapper
c0fcc450-496a-42f8-9f69-3919ada6132f	aa014a47-c160-47bd-8e64-20bee8fa775e	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
fc2a1fd4-9f60-4844-9f5e-04850d1eaa08	aa014a47-c160-47bd-8e64-20bee8fa775e	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
989d150d-e1ce-4e1d-80ff-7bb11452ab50	aa014a47-c160-47bd-8e64-20bee8fa775e	allowed-protocol-mapper-types	saml-user-property-mapper
0aba985b-cd0e-4114-ad2e-0b2d3ea749a0	aa014a47-c160-47bd-8e64-20bee8fa775e	allowed-protocol-mapper-types	saml-role-list-mapper
3945f8a2-6d24-464b-9eb8-c74261351b7d	df4d2e5f-882d-4ef2-93d0-1984c29357ac	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
fb586500-5e69-45ab-845f-b613f909f940	df4d2e5f-882d-4ef2-93d0-1984c29357ac	allowed-protocol-mapper-types	saml-user-attribute-mapper
aaf6bad4-c171-4108-8037-8f961bbf76be	df4d2e5f-882d-4ef2-93d0-1984c29357ac	allowed-protocol-mapper-types	saml-user-property-mapper
8ce9558c-6b18-4807-8095-5fe8607716bb	df4d2e5f-882d-4ef2-93d0-1984c29357ac	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
f866b3b9-932a-4f19-b915-25b9a7599643	df4d2e5f-882d-4ef2-93d0-1984c29357ac	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
8e930cd5-801e-460c-a60a-25e2b67926a7	df4d2e5f-882d-4ef2-93d0-1984c29357ac	allowed-protocol-mapper-types	oidc-address-mapper
15e44016-5f01-4a1f-8af7-25ca03cea9fe	df4d2e5f-882d-4ef2-93d0-1984c29357ac	allowed-protocol-mapper-types	saml-role-list-mapper
4819b20a-b17f-4e15-80ae-b8c52dba358f	df4d2e5f-882d-4ef2-93d0-1984c29357ac	allowed-protocol-mapper-types	oidc-full-name-mapper
1eeda12f-92f6-44f4-80ad-3a2c56f2e0ba	d811a939-16c5-45d2-848f-e159d1d27b1c	client-uris-must-match	true
7ff66e58-bc25-45b3-aad0-5a4b195e5371	d811a939-16c5-45d2-848f-e159d1d27b1c	host-sending-registration-request-must-match	true
ccc3ec8e-cf61-4a1a-a9ba-5f5673e57b36	bf432bcb-b6e8-4e27-87b7-f37b3603b637	allow-default-scopes	true
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.composite_role (composite, child_role) FROM stdin;
5d9e55f9-a701-42dd-b811-0becaa4f200a	b42b7001-ac0a-4424-81f3-32f52e54b030
5d9e55f9-a701-42dd-b811-0becaa4f200a	b6b92206-d3af-4040-bc86-5070f56fdd35
5d9e55f9-a701-42dd-b811-0becaa4f200a	0c2f9cfd-1aee-462a-97a9-be7e386245dc
5d9e55f9-a701-42dd-b811-0becaa4f200a	bc67dbe0-c132-4576-83f3-9b1cc146be43
5d9e55f9-a701-42dd-b811-0becaa4f200a	1b29c4dc-1a1d-4df8-81b6-beed3974a40b
5d9e55f9-a701-42dd-b811-0becaa4f200a	a351a9f1-ff94-4fe8-b51b-29251e1e6162
5d9e55f9-a701-42dd-b811-0becaa4f200a	f9ae8c35-cfb0-4052-9c86-6bbfee6ebc40
5d9e55f9-a701-42dd-b811-0becaa4f200a	2bd36636-a23f-43d4-b3c8-2fe8538ee820
5d9e55f9-a701-42dd-b811-0becaa4f200a	9b6cd81b-cb3e-48b3-addb-cafd210045e8
5d9e55f9-a701-42dd-b811-0becaa4f200a	f9ff3d42-7995-4ec3-b7cf-8a0150dfe1a7
5d9e55f9-a701-42dd-b811-0becaa4f200a	182c4ab8-cab8-4af7-adfe-d4b390491d98
5d9e55f9-a701-42dd-b811-0becaa4f200a	c883a683-6aaa-4c36-9946-826c75f0aca3
5d9e55f9-a701-42dd-b811-0becaa4f200a	7d231c3a-4cc0-4f29-b615-f0e45b480643
5d9e55f9-a701-42dd-b811-0becaa4f200a	3b959772-3bfe-4729-b450-4a8a3ead3701
5d9e55f9-a701-42dd-b811-0becaa4f200a	9d73784e-f68e-4499-b2fc-a1a86a231c8a
5d9e55f9-a701-42dd-b811-0becaa4f200a	8e544550-8b54-46df-a01b-589f29c19984
5d9e55f9-a701-42dd-b811-0becaa4f200a	0db44a34-ea46-447f-ab61-45f839997b6f
5d9e55f9-a701-42dd-b811-0becaa4f200a	1deba277-c039-4681-9df0-fcfaef7b9903
1b29c4dc-1a1d-4df8-81b6-beed3974a40b	8e544550-8b54-46df-a01b-589f29c19984
7e5d7b82-8607-4196-99b5-e6202cc8cfac	d3198b1a-39aa-4dbe-ac2f-dc9fa9a85ffb
bc67dbe0-c132-4576-83f3-9b1cc146be43	1deba277-c039-4681-9df0-fcfaef7b9903
bc67dbe0-c132-4576-83f3-9b1cc146be43	9d73784e-f68e-4499-b2fc-a1a86a231c8a
7e5d7b82-8607-4196-99b5-e6202cc8cfac	93f3e94d-4e24-453c-80da-d5d73760c32e
93f3e94d-4e24-453c-80da-d5d73760c32e	1580fe23-ed33-4cdb-943c-da8686829f3f
6da983d4-5229-4f52-9984-0a67250ffed6	0256590f-92d8-4710-9c9c-1201c18f9fc0
5d9e55f9-a701-42dd-b811-0becaa4f200a	565e0a19-9171-4789-ab4f-5c1f7d94ce7e
7e5d7b82-8607-4196-99b5-e6202cc8cfac	b9f75f96-29f3-4e58-afdc-7f5aaa28db9c
7e5d7b82-8607-4196-99b5-e6202cc8cfac	0d7569f9-9ea2-41d2-be2a-149fa8fc8dbd
5d9e55f9-a701-42dd-b811-0becaa4f200a	0405bff8-ad28-4235-b16b-23aec7d2cda2
5d9e55f9-a701-42dd-b811-0becaa4f200a	0073166b-e0fc-44c4-a9f5-5e226b40d88c
5d9e55f9-a701-42dd-b811-0becaa4f200a	d4abeb26-12a0-4482-a300-fc867d4718b3
5d9e55f9-a701-42dd-b811-0becaa4f200a	e90c883c-f91b-41fb-8f12-97f1c9c0cf76
5d9e55f9-a701-42dd-b811-0becaa4f200a	01be9d01-ad0b-41a9-89e9-4ee015af7a26
5d9e55f9-a701-42dd-b811-0becaa4f200a	02e45112-fa44-4168-9696-e9123029f60e
5d9e55f9-a701-42dd-b811-0becaa4f200a	f076583b-1d29-4fa7-a85d-f0ae7b19aad6
5d9e55f9-a701-42dd-b811-0becaa4f200a	7d211a02-4971-468d-8902-276a4f98a405
5d9e55f9-a701-42dd-b811-0becaa4f200a	37aa3fb0-2c08-42c8-9cef-e9536c2c4ba9
5d9e55f9-a701-42dd-b811-0becaa4f200a	87b2af4c-6fad-4042-be55-7c17c7278c55
5d9e55f9-a701-42dd-b811-0becaa4f200a	08dd11df-d349-48d1-8d90-471bd2f5e1ba
5d9e55f9-a701-42dd-b811-0becaa4f200a	6ae9bcea-1d57-4205-aa27-9f96ddf9fdb8
5d9e55f9-a701-42dd-b811-0becaa4f200a	ea21fe1d-aa3d-4898-b917-632da25ffdb7
5d9e55f9-a701-42dd-b811-0becaa4f200a	2130cb1b-b249-48a3-851d-b3240dd246ef
5d9e55f9-a701-42dd-b811-0becaa4f200a	601d33e6-3786-4785-b4db-c08ba149f74b
5d9e55f9-a701-42dd-b811-0becaa4f200a	3b85eec0-266a-4b75-960a-a098f24808b1
5d9e55f9-a701-42dd-b811-0becaa4f200a	bed20f92-bced-4cef-9846-b7e3568751ca
d4abeb26-12a0-4482-a300-fc867d4718b3	bed20f92-bced-4cef-9846-b7e3568751ca
d4abeb26-12a0-4482-a300-fc867d4718b3	2130cb1b-b249-48a3-851d-b3240dd246ef
e90c883c-f91b-41fb-8f12-97f1c9c0cf76	601d33e6-3786-4785-b4db-c08ba149f74b
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	7628fffc-bf3b-4983-8a93-f247d6437796
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	d44ee703-3a2b-4517-963a-3d99517bc634
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	58bd0d0e-91d2-475f-8fe8-93aff6d389b5
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	79051427-b1d6-4449-a293-f6a3fba474f2
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	a7aff16c-6e47-47ae-b62d-dcfc48001d2f
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	b6d5e834-e66a-43e2-afd1-a5bd4e55898c
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	5898f5b3-3dea-4cd3-93d5-d575fbb0d440
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	8aa93c48-5303-4ddd-890f-39b85b1b3d5f
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	5220c770-5045-4555-ada3-472d1812536f
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	85dd76b7-2e2e-4578-a73f-982544915a7c
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	d999f8b3-3006-4584-be7b-52d447588d56
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	675337c4-252a-48bc-b301-20e74cc0567e
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	01a4ecbc-c48e-4b16-a7eb-189469a97d3d
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	40645707-f71e-42ed-a3b6-b39fdc6b63d6
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	d3269833-f8d8-4b20-b348-244fdfa46ff2
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	8eead9ed-c74c-4822-ac8f-bcde5d95f588
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	ff4eb52c-14ae-4ef5-a93b-58e29f2fc284
58bd0d0e-91d2-475f-8fe8-93aff6d389b5	40645707-f71e-42ed-a3b6-b39fdc6b63d6
58bd0d0e-91d2-475f-8fe8-93aff6d389b5	ff4eb52c-14ae-4ef5-a93b-58e29f2fc284
79051427-b1d6-4449-a293-f6a3fba474f2	d3269833-f8d8-4b20-b348-244fdfa46ff2
9379f18e-adcb-491c-8814-65c69dd45091	979bbe85-37cf-4efc-b5bc-54ac130ed833
9379f18e-adcb-491c-8814-65c69dd45091	456ab443-1ca1-4bf6-a5cf-fdbcffe7dcdd
456ab443-1ca1-4bf6-a5cf-fdbcffe7dcdd	545a5d6f-a2d7-4a21-ae4f-8a82ad2f7718
2ac80b00-8b52-4de5-8533-fbd8d8eb0cdf	22c22483-acad-4494-9c67-d579f4b84855
5d9e55f9-a701-42dd-b811-0becaa4f200a	131a42b1-d5a5-4e10-977e-261ea0af615f
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	93ca4e30-3297-4b4b-b297-83cb2512213a
9379f18e-adcb-491c-8814-65c69dd45091	c48730f2-f365-4d19-bb82-a587b0e9f9e4
9379f18e-adcb-491c-8814-65c69dd45091	c229178b-28b5-4fba-82c7-0ea3186b0c22
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
c0b7df9f-6d62-4ab3-99cf-c5caf62628db	\N	password	f651f055-58c0-41c5-b2dc-6b6e2fbb6c26	1775152160126	\N	{"value":"tmk09ClUCAyhc1CdaLP8xPm3gEpWkB3NraMz+WjatJY=","salt":"iu6Pvm2OClYa1+qAljDwmQ==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2026-04-02 17:48:47.176209	1	EXECUTED	9:6f1016664e21e16d26517a4418f5e3df	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.29.1	\N	\N	5152125607
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2026-04-02 17:48:47.308733	2	MARK_RAN	9:828775b1596a07d1200ba1d49e5e3941	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.29.1	\N	\N	5152125607
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2026-04-02 17:48:47.522065	3	EXECUTED	9:5f090e44a7d595883c1fb61f4b41fd38	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.29.1	\N	\N	5152125607
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2026-04-02 17:48:47.637152	4	EXECUTED	9:c07e577387a3d2c04d1adc9aaad8730e	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.29.1	\N	\N	5152125607
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2026-04-02 17:48:47.877298	5	EXECUTED	9:b68ce996c655922dbcd2fe6b6ae72686	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.29.1	\N	\N	5152125607
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2026-04-02 17:48:47.919218	6	MARK_RAN	9:543b5c9989f024fe35c6f6c5a97de88e	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.29.1	\N	\N	5152125607
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2026-04-02 17:48:48.178617	7	EXECUTED	9:765afebbe21cf5bbca048e632df38336	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.29.1	\N	\N	5152125607
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2026-04-02 17:48:48.284739	8	MARK_RAN	9:db4a145ba11a6fdaefb397f6dbf829a1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.29.1	\N	\N	5152125607
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2026-04-02 17:48:48.326049	9	EXECUTED	9:9d05c7be10cdb873f8bcb41bc3a8ab23	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.29.1	\N	\N	5152125607
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2026-04-02 17:48:48.675849	10	EXECUTED	9:18593702353128d53111f9b1ff0b82b8	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.29.1	\N	\N	5152125607
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2026-04-02 17:48:48.905676	11	EXECUTED	9:6122efe5f090e41a85c0f1c9e52cbb62	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.29.1	\N	\N	5152125607
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2026-04-02 17:48:48.981277	12	MARK_RAN	9:e1ff28bf7568451453f844c5d54bb0b5	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.29.1	\N	\N	5152125607
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2026-04-02 17:48:49.191516	13	EXECUTED	9:7af32cd8957fbc069f796b61217483fd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.29.1	\N	\N	5152125607
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-04-02 17:48:49.310512	14	EXECUTED	9:6005e15e84714cd83226bf7879f54190	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.29.1	\N	\N	5152125607
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-04-02 17:48:49.357686	15	MARK_RAN	9:bf656f5a2b055d07f314431cae76f06c	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-04-02 17:48:49.406214	16	MARK_RAN	9:f8dadc9284440469dcf71e25ca6ab99b	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.29.1	\N	\N	5152125607
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-04-02 17:48:49.476242	17	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.29.1	\N	\N	5152125607
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2026-04-02 17:48:49.78787	18	EXECUTED	9:3368ff0be4c2855ee2dd9ca813b38d8e	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.29.1	\N	\N	5152125607
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2026-04-02 17:48:49.954131	19	EXECUTED	9:8ac2fb5dd030b24c0570a763ed75ed20	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.29.1	\N	\N	5152125607
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2026-04-02 17:48:50.049336	20	EXECUTED	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.29.1	\N	\N	5152125607
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2026-04-02 17:48:50.112681	21	MARK_RAN	9:831e82914316dc8a57dc09d755f23c51	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.29.1	\N	\N	5152125607
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2026-04-02 17:48:50.16891	22	MARK_RAN	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.29.1	\N	\N	5152125607
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2026-04-02 17:48:50.480753	23	EXECUTED	9:bc3d0f9e823a69dc21e23e94c7a94bb1	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.29.1	\N	\N	5152125607
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2026-04-02 17:48:50.621662	24	EXECUTED	9:c9999da42f543575ab790e76439a2679	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.29.1	\N	\N	5152125607
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2026-04-02 17:48:50.681409	25	MARK_RAN	9:0d6c65c6f58732d81569e77b10ba301d	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.29.1	\N	\N	5152125607
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2026-04-02 17:48:51.825648	26	EXECUTED	9:fc576660fc016ae53d2d4778d84d86d0	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.29.1	\N	\N	5152125607
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2026-04-02 17:48:52.040734	27	EXECUTED	9:43ed6b0da89ff77206289e87eaa9c024	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.29.1	\N	\N	5152125607
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2026-04-02 17:48:52.101586	28	EXECUTED	9:44bae577f551b3738740281eceb4ea70	update tableName=RESOURCE_SERVER_POLICY		\N	4.29.1	\N	\N	5152125607
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2026-04-02 17:48:52.290857	29	EXECUTED	9:bd88e1f833df0420b01e114533aee5e8	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.29.1	\N	\N	5152125607
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2026-04-02 17:48:52.433682	30	EXECUTED	9:a7022af5267f019d020edfe316ef4371	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.29.1	\N	\N	5152125607
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2026-04-02 17:48:52.696302	31	EXECUTED	9:fc155c394040654d6a79227e56f5e25a	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.29.1	\N	\N	5152125607
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2026-04-02 17:48:52.778318	32	EXECUTED	9:eac4ffb2a14795e5dc7b426063e54d88	customChange		\N	4.29.1	\N	\N	5152125607
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-04-02 17:48:52.862637	33	EXECUTED	9:54937c05672568c4c64fc9524c1e9462	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-04-02 17:48:52.970984	34	MARK_RAN	9:3a32bace77c84d7678d035a7f5a8084e	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.29.1	\N	\N	5152125607
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-04-02 17:48:53.180606	35	EXECUTED	9:33d72168746f81f98ae3a1e8e0ca3554	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.29.1	\N	\N	5152125607
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2026-04-02 17:48:53.328097	36	EXECUTED	9:61b6d3d7a4c0e0024b0c839da283da0c	addColumn tableName=REALM		\N	4.29.1	\N	\N	5152125607
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-04-02 17:48:53.447202	37	EXECUTED	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	5152125607
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2026-04-02 17:48:53.5544	38	EXECUTED	9:a2b870802540cb3faa72098db5388af3	addColumn tableName=FED_USER_CONSENT		\N	4.29.1	\N	\N	5152125607
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2026-04-02 17:48:53.673668	39	EXECUTED	9:132a67499ba24bcc54fb5cbdcfe7e4c0	addColumn tableName=IDENTITY_PROVIDER		\N	4.29.1	\N	\N	5152125607
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-04-02 17:48:53.721299	40	MARK_RAN	9:938f894c032f5430f2b0fafb1a243462	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.29.1	\N	\N	5152125607
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-04-02 17:48:53.781564	41	MARK_RAN	9:845c332ff1874dc5d35974b0babf3006	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.29.1	\N	\N	5152125607
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2026-04-02 17:48:53.847185	42	EXECUTED	9:fc86359c079781adc577c5a217e4d04c	customChange		\N	4.29.1	\N	\N	5152125607
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-04-02 17:48:55.222412	43	EXECUTED	9:59a64800e3c0d09b825f8a3b444fa8f4	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.29.1	\N	\N	5152125607
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2026-04-02 17:48:55.37804	44	EXECUTED	9:d48d6da5c6ccf667807f633fe489ce88	addColumn tableName=USER_ENTITY		\N	4.29.1	\N	\N	5152125607
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-02 17:48:55.470246	45	EXECUTED	9:dde36f7973e80d71fceee683bc5d2951	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.29.1	\N	\N	5152125607
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-02 17:48:55.532777	46	EXECUTED	9:b855e9b0a406b34fa323235a0cf4f640	customChange		\N	4.29.1	\N	\N	5152125607
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-02 17:48:55.588909	47	MARK_RAN	9:51abbacd7b416c50c4421a8cabf7927e	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.29.1	\N	\N	5152125607
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-02 17:48:55.978342	48	EXECUTED	9:bdc99e567b3398bac83263d375aad143	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.29.1	\N	\N	5152125607
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-04-02 17:48:56.123115	49	EXECUTED	9:d198654156881c46bfba39abd7769e69	addColumn tableName=REALM		\N	4.29.1	\N	\N	5152125607
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2026-04-02 17:48:56.280099	50	EXECUTED	9:cfdd8736332ccdd72c5256ccb42335db	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.29.1	\N	\N	5152125607
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2026-04-02 17:48:57.083808	51	EXECUTED	9:7c84de3d9bd84d7f077607c1a4dcb714	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.29.1	\N	\N	5152125607
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2026-04-02 17:48:57.226285	52	EXECUTED	9:5a6bb36cbefb6a9d6928452c0852af2d	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2026-04-02 17:48:57.279087	53	EXECUTED	9:8f23e334dbc59f82e0a328373ca6ced0	update tableName=REALM		\N	4.29.1	\N	\N	5152125607
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2026-04-02 17:48:57.322628	54	EXECUTED	9:9156214268f09d970cdf0e1564d866af	update tableName=CLIENT		\N	4.29.1	\N	\N	5152125607
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-04-02 17:48:57.5821	55	EXECUTED	9:db806613b1ed154826c02610b7dbdf74	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.29.1	\N	\N	5152125607
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-04-02 17:48:57.689051	56	EXECUTED	9:229a041fb72d5beac76bb94a5fa709de	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.29.1	\N	\N	5152125607
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-04-02 17:48:57.843571	57	EXECUTED	9:079899dade9c1e683f26b2aa9ca6ff04	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.29.1	\N	\N	5152125607
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-04-02 17:48:58.532533	58	EXECUTED	9:139b79bcbbfe903bb1c2d2a4dbf001d9	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.29.1	\N	\N	5152125607
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2026-04-02 17:48:58.626314	59	EXECUTED	9:b55738ad889860c625ba2bf483495a04	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.29.1	\N	\N	5152125607
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2026-04-02 17:48:58.72113	60	EXECUTED	9:e0057eac39aa8fc8e09ac6cfa4ae15fe	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.29.1	\N	\N	5152125607
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2026-04-02 17:48:58.828228	61	EXECUTED	9:42a33806f3a0443fe0e7feeec821326c	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.29.1	\N	\N	5152125607
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2026-04-02 17:48:58.922765	62	EXECUTED	9:9968206fca46eecc1f51db9c024bfe56	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.29.1	\N	\N	5152125607
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2026-04-02 17:48:59.02983	63	EXECUTED	9:92143a6daea0a3f3b8f598c97ce55c3d	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.29.1	\N	\N	5152125607
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2026-04-02 17:48:59.138168	64	EXECUTED	9:82bab26a27195d889fb0429003b18f40	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.29.1	\N	\N	5152125607
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2026-04-02 17:48:59.200576	65	EXECUTED	9:e590c88ddc0b38b0ae4249bbfcb5abc3	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.29.1	\N	\N	5152125607
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2026-04-02 17:48:59.314589	66	EXECUTED	9:5c1f475536118dbdc38d5d7977950cc0	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.29.1	\N	\N	5152125607
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2026-04-02 17:48:59.422934	67	EXECUTED	9:e7c9f5f9c4d67ccbbcc215440c718a17	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.29.1	\N	\N	5152125607
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2026-04-02 17:48:59.527737	68	EXECUTED	9:88e0bfdda924690d6f4e430c53447dd5	addColumn tableName=REALM		\N	4.29.1	\N	\N	5152125607
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2026-04-02 17:48:59.648142	69	EXECUTED	9:f53177f137e1c46b6a88c59ec1cb5218	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.29.1	\N	\N	5152125607
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2026-04-02 17:48:59.754476	70	EXECUTED	9:a74d33da4dc42a37ec27121580d1459f	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.29.1	\N	\N	5152125607
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2026-04-02 17:48:59.860025	71	EXECUTED	9:fd4ade7b90c3b67fae0bfcfcb42dfb5f	addColumn tableName=RESOURCE_SERVER		\N	4.29.1	\N	\N	5152125607
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-02 17:48:59.954858	72	EXECUTED	9:aa072ad090bbba210d8f18781b8cebf4	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.29.1	\N	\N	5152125607
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-02 17:49:00.016619	73	EXECUTED	9:1ae6be29bab7c2aa376f6983b932be37	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.29.1	\N	\N	5152125607
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-02 17:49:00.068166	74	MARK_RAN	9:14706f286953fc9a25286dbd8fb30d97	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.29.1	\N	\N	5152125607
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-02 17:49:00.16971	75	EXECUTED	9:2b9cc12779be32c5b40e2e67711a218b	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.29.1	\N	\N	5152125607
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-04-02 17:49:00.299216	76	EXECUTED	9:91fa186ce7a5af127a2d7a91ee083cc5	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.29.1	\N	\N	5152125607
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-04-02 17:49:00.406277	77	EXECUTED	9:6335e5c94e83a2639ccd68dd24e2e5ad	addColumn tableName=CLIENT		\N	4.29.1	\N	\N	5152125607
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-04-02 17:49:00.478082	78	MARK_RAN	9:6bdb5658951e028bfe16fa0a8228b530	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.29.1	\N	\N	5152125607
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-04-02 17:49:00.598333	79	EXECUTED	9:d5bc15a64117ccad481ce8792d4c608f	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.29.1	\N	\N	5152125607
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-04-02 17:49:00.643588	80	MARK_RAN	9:077cba51999515f4d3e7ad5619ab592c	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.29.1	\N	\N	5152125607
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-02 17:49:00.785758	81	EXECUTED	9:be969f08a163bf47c6b9e9ead8ac2afb	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.29.1	\N	\N	5152125607
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-02 17:49:00.878254	82	MARK_RAN	9:6d3bb4408ba5a72f39bd8a0b301ec6e3	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	5152125607
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-02 17:49:00.96334	83	EXECUTED	9:966bda61e46bebf3cc39518fbed52fa7	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	5152125607
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-02 17:49:01.012075	84	MARK_RAN	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	5152125607
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-04-02 17:49:01.141652	85	EXECUTED	9:7d93d602352a30c0c317e6a609b56599	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.29.1	\N	\N	5152125607
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2026-04-02 17:49:01.237334	86	EXECUTED	9:71c5969e6cdd8d7b6f47cebc86d37627	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.29.1	\N	\N	5152125607
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2026-04-02 17:49:01.332372	87	EXECUTED	9:a9ba7d47f065f041b7da856a81762021	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.29.1	\N	\N	5152125607
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2026-04-02 17:49:01.450292	88	EXECUTED	9:fffabce2bc01e1a8f5110d5278500065	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.29.1	\N	\N	5152125607
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-02 17:49:01.545448	89	EXECUTED	9:fa8a5b5445e3857f4b010bafb5009957	addColumn tableName=REALM; customChange		\N	4.29.1	\N	\N	5152125607
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-02 17:49:01.640963	90	EXECUTED	9:67ac3241df9a8582d591c5ed87125f39	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.29.1	\N	\N	5152125607
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-02 17:49:01.770586	91	EXECUTED	9:ad1194d66c937e3ffc82386c050ba089	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-02 17:49:01.92465	92	EXECUTED	9:d9be619d94af5a2f5d07b9f003543b91	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.29.1	\N	\N	5152125607
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-02 17:49:01.984415	93	MARK_RAN	9:544d201116a0fcc5a5da0925fbbc3bde	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.29.1	\N	\N	5152125607
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-02 17:49:02.087399	94	EXECUTED	9:43c0c1055b6761b4b3e89de76d612ccf	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.29.1	\N	\N	5152125607
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-02 17:49:02.126771	95	MARK_RAN	9:8bd711fd0330f4fe980494ca43ab1139	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.29.1	\N	\N	5152125607
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-04-02 17:49:02.221415	96	EXECUTED	9:e07d2bc0970c348bb06fb63b1f82ddbf	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.29.1	\N	\N	5152125607
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-02 17:49:02.477969	97	EXECUTED	9:24fb8611e97f29989bea412aa38d12b7	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-02 17:49:02.518393	98	MARK_RAN	9:259f89014ce2506ee84740cbf7163aa7	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-02 17:49:02.598383	99	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-02 17:49:02.778405	100	EXECUTED	9:60ca84a0f8c94ec8c3504a5a3bc88ee8	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-02 17:49:02.877776	101	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-02 17:49:03.078285	102	EXECUTED	9:0b305d8d1277f3a89a0a53a659ad274c	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.29.1	\N	\N	5152125607
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-04-02 17:49:03.120341	103	EXECUTED	9:2c374ad2cdfe20e2905a84c8fac48460	customChange		\N	4.29.1	\N	\N	5152125607
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2026-04-02 17:49:03.222026	104	EXECUTED	9:47a760639ac597360a8219f5b768b4de	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.29.1	\N	\N	5152125607
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2026-04-02 17:49:03.378213	105	EXECUTED	9:a6272f0576727dd8cad2522335f5d99e	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.29.1	\N	\N	5152125607
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2026-04-02 17:49:03.520053	106	EXECUTED	9:015479dbd691d9cc8669282f4828c41d	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.29.1	\N	\N	5152125607
18.0.15-30992-index-consent	keycloak	META-INF/jpa-changelog-18.0.15.xml	2026-04-02 17:49:03.711184	107	EXECUTED	9:80071ede7a05604b1f4906f3bf3b00f0	createIndex indexName=IDX_USCONSENT_SCOPE_ID, tableName=USER_CONSENT_CLIENT_SCOPE		\N	4.29.1	\N	\N	5152125607
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2026-04-02 17:49:03.780467	108	EXECUTED	9:9518e495fdd22f78ad6425cc30630221	customChange		\N	4.29.1	\N	\N	5152125607
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-04-02 17:49:03.937476	109	EXECUTED	9:e5f243877199fd96bcc842f27a1656ac	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.29.1	\N	\N	5152125607
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-04-02 17:49:03.987684	110	MARK_RAN	9:1a6fcaa85e20bdeae0a9ce49b41946a5	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.29.1	\N	\N	5152125607
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-04-02 17:49:04.105336	111	EXECUTED	9:3f332e13e90739ed0c35b0b25b7822ca	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2026-04-02 17:49:04.154721	112	EXECUTED	9:7ee1f7a3fb8f5588f171fb9a6ab623c0	customChange		\N	4.29.1	\N	\N	5152125607
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2026-04-02 17:49:04.248759	113	EXECUTED	9:3d7e830b52f33676b9d64f7f2b2ea634	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.29.1	\N	\N	5152125607
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2026-04-02 17:49:04.305608	114	MARK_RAN	9:627d032e3ef2c06c0e1f73d2ae25c26c	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.29.1	\N	\N	5152125607
22.0.0-17484-updated	keycloak	META-INF/jpa-changelog-22.0.0.xml	2026-04-02 17:49:04.358006	115	EXECUTED	9:90af0bfd30cafc17b9f4d6eccd92b8b3	customChange		\N	4.29.1	\N	\N	5152125607
22.0.5-24031	keycloak	META-INF/jpa-changelog-22.0.0.xml	2026-04-02 17:49:04.415895	116	MARK_RAN	9:a60d2d7b315ec2d3eba9e2f145f9df28	customChange		\N	4.29.1	\N	\N	5152125607
23.0.0-12062	keycloak	META-INF/jpa-changelog-23.0.0.xml	2026-04-02 17:49:04.51082	117	EXECUTED	9:2168fbe728fec46ae9baf15bf80927b8	addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG		\N	4.29.1	\N	\N	5152125607
23.0.0-17258	keycloak	META-INF/jpa-changelog-23.0.0.xml	2026-04-02 17:49:04.618592	118	EXECUTED	9:36506d679a83bbfda85a27ea1864dca8	addColumn tableName=EVENT_ENTITY		\N	4.29.1	\N	\N	5152125607
24.0.0-9758	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-04-02 17:49:04.952735	119	EXECUTED	9:502c557a5189f600f0f445a9b49ebbce	addColumn tableName=USER_ATTRIBUTE; addColumn tableName=FED_USER_ATTRIBUTE; createIndex indexName=USER_ATTR_LONG_VALUES, tableName=USER_ATTRIBUTE; createIndex indexName=FED_USER_ATTR_LONG_VALUES, tableName=FED_USER_ATTRIBUTE; createIndex indexName...		\N	4.29.1	\N	\N	5152125607
24.0.0-9758-2	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-04-02 17:49:05.003937	120	EXECUTED	9:bf0fdee10afdf597a987adbf291db7b2	customChange		\N	4.29.1	\N	\N	5152125607
24.0.0-26618-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-04-02 17:49:05.053438	121	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
24.0.0-26618-reindex	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-04-02 17:49:05.203857	122	EXECUTED	9:08707c0f0db1cef6b352db03a60edc7f	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
24.0.2-27228	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-04-02 17:49:05.266038	123	EXECUTED	9:eaee11f6b8aa25d2cc6a84fb86fc6238	customChange		\N	4.29.1	\N	\N	5152125607
24.0.2-27967-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-04-02 17:49:05.310968	124	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
24.0.2-27967-reindex	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-04-02 17:49:05.37818	125	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	5152125607
25.0.0-28265-tables	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:05.477783	126	EXECUTED	9:deda2df035df23388af95bbd36c17cef	addColumn tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_CLIENT_SESSION		\N	4.29.1	\N	\N	5152125607
25.0.0-28265-index-creation	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:05.656995	127	EXECUTED	9:3e96709818458ae49f3c679ae58d263a	createIndex indexName=IDX_OFFLINE_USS_BY_LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
25.0.0-28265-index-cleanup-uss-createdon	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:05.83727	128	EXECUTED	9:78ab4fc129ed5e8265dbcc3485fba92f	dropIndex indexName=IDX_OFFLINE_USS_CREATEDON, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
25.0.0-28265-index-cleanup-uss-preload	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:05.955537	129	EXECUTED	9:de5f7c1f7e10994ed8b62e621d20eaab	dropIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
25.0.0-28265-index-cleanup-uss-by-usersess	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:06.122677	130	EXECUTED	9:6eee220d024e38e89c799417ec33667f	dropIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
25.0.0-28265-index-cleanup-css-preload	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:06.277888	131	EXECUTED	9:5411d2fb2891d3e8d63ddb55dfa3c0c9	dropIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION		\N	4.29.1	\N	\N	5152125607
25.0.0-28265-index-2-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:06.314237	132	MARK_RAN	9:b7ef76036d3126bb83c2423bf4d449d6	createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
25.0.0-28265-index-2-not-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:06.481066	133	EXECUTED	9:23396cf51ab8bc1ae6f0cac7f9f6fcf7	createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	5152125607
25.0.0-org	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:06.636368	134	EXECUTED	9:5c859965c2c9b9c72136c360649af157	createTable tableName=ORG; addUniqueConstraint constraintName=UK_ORG_NAME, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_GROUP, tableName=ORG; createTable tableName=ORG_DOMAIN		\N	4.29.1	\N	\N	5152125607
unique-consentuser	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:06.779867	135	EXECUTED	9:5857626a2ea8767e9a6c66bf3a2cb32f	customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...		\N	4.29.1	\N	\N	5152125607
unique-consentuser-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:06.877796	136	MARK_RAN	9:b79478aad5adaa1bc428e31563f55e8e	customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...		\N	4.29.1	\N	\N	5152125607
25.0.0-28861-index-creation	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-04-02 17:49:07.178197	137	EXECUTED	9:b9acb58ac958d9ada0fe12a5d4794ab1	createIndex indexName=IDX_PERM_TICKET_REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; createIndex indexName=IDX_PERM_TICKET_OWNER, tableName=RESOURCE_SERVER_PERM_TICKET		\N	4.29.1	\N	\N	5152125607
26.0.0-org-alias	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:07.281429	138	EXECUTED	9:6ef7d63e4412b3c2d66ed179159886a4	addColumn tableName=ORG; update tableName=ORG; addNotNullConstraint columnName=ALIAS, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_ALIAS, tableName=ORG		\N	4.29.1	\N	\N	5152125607
26.0.0-org-group	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:07.424452	139	EXECUTED	9:da8e8087d80ef2ace4f89d8c5b9ca223	addColumn tableName=KEYCLOAK_GROUP; update tableName=KEYCLOAK_GROUP; addNotNullConstraint columnName=TYPE, tableName=KEYCLOAK_GROUP; customChange		\N	4.29.1	\N	\N	5152125607
26.0.0-org-indexes	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:07.57839	140	EXECUTED	9:79b05dcd610a8c7f25ec05135eec0857	createIndex indexName=IDX_ORG_DOMAIN_ORG_ID, tableName=ORG_DOMAIN		\N	4.29.1	\N	\N	5152125607
26.0.0-org-group-membership	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:07.678214	141	EXECUTED	9:a6ace2ce583a421d89b01ba2a28dc2d4	addColumn tableName=USER_GROUP_MEMBERSHIP; update tableName=USER_GROUP_MEMBERSHIP; addNotNullConstraint columnName=MEMBERSHIP_TYPE, tableName=USER_GROUP_MEMBERSHIP		\N	4.29.1	\N	\N	5152125607
31296-persist-revoked-access-tokens	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:07.770588	142	EXECUTED	9:64ef94489d42a358e8304b0e245f0ed4	createTable tableName=REVOKED_TOKEN; addPrimaryKey constraintName=CONSTRAINT_RT, tableName=REVOKED_TOKEN		\N	4.29.1	\N	\N	5152125607
31725-index-persist-revoked-access-tokens	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:07.913973	143	EXECUTED	9:b994246ec2bf7c94da881e1d28782c7b	createIndex indexName=IDX_REV_TOKEN_ON_EXPIRE, tableName=REVOKED_TOKEN		\N	4.29.1	\N	\N	5152125607
26.0.0-idps-for-login	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:08.117026	144	EXECUTED	9:51f5fffadf986983d4bd59582c6c1604	addColumn tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_REALM_ORG, tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_FOR_LOGIN, tableName=IDENTITY_PROVIDER; customChange		\N	4.29.1	\N	\N	5152125607
26.0.0-32583-drop-redundant-index-on-client-session	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:08.224605	145	EXECUTED	9:24972d83bf27317a055d234187bb4af9	dropIndex indexName=IDX_US_SESS_ID_ON_CL_SESS, tableName=OFFLINE_CLIENT_SESSION		\N	4.29.1	\N	\N	5152125607
26.0.0.32582-remove-tables-user-session-user-session-note-and-client-session	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:08.345113	146	EXECUTED	9:febdc0f47f2ed241c59e60f58c3ceea5	dropTable tableName=CLIENT_SESSION_ROLE; dropTable tableName=CLIENT_SESSION_NOTE; dropTable tableName=CLIENT_SESSION_PROT_MAPPER; dropTable tableName=CLIENT_SESSION_AUTH_STATUS; dropTable tableName=CLIENT_USER_SESSION_NOTE; dropTable tableName=CLI...		\N	4.29.1	\N	\N	5152125607
26.0.0-33201-org-redirect-url	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-04-02 17:49:08.439561	147	EXECUTED	9:4d0e22b0ac68ebe9794fa9cb752ea660	addColumn tableName=ORG		\N	4.29.1	\N	\N	5152125607
29399-jdbc-ping-default	keycloak	META-INF/jpa-changelog-26.1.0.xml	2026-04-02 17:49:08.534983	148	EXECUTED	9:007dbe99d7203fca403b89d4edfdf21e	createTable tableName=JGROUPS_PING; addPrimaryKey constraintName=CONSTRAINT_JGROUPS_PING, tableName=JGROUPS_PING		\N	4.29.1	\N	\N	5152125607
26.1.0-34013	keycloak	META-INF/jpa-changelog-26.1.0.xml	2026-04-02 17:49:08.65502	149	EXECUTED	9:e6b686a15759aef99a6d758a5c4c6a26	addColumn tableName=ADMIN_EVENT_ENTITY		\N	4.29.1	\N	\N	5152125607
26.1.0-34380	keycloak	META-INF/jpa-changelog-26.1.0.xml	2026-04-02 17:49:08.750679	150	EXECUTED	9:ac8b9edb7c2b6c17a1c7a11fcf5ccf01	dropTable tableName=USERNAME_LOGIN_FAILURE		\N	4.29.1	\N	\N	5152125607
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	79e6c3d9-7e8e-4322-9ed0-6eebec5dbf9a	f
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	56f54f1c-8537-4574-b880-1a96cfd95b7c	t
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	25289ed7-2a9d-4bb5-be28-574e102d35f8	t
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	fd8be0d3-37bf-416c-9491-8eed1f661408	t
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	c174415c-a203-4e6e-9047-631ceec5e059	t
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	a6bbe01b-cbcb-4357-bfd3-2f036cdf423b	f
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	d17d9492-a4a0-46dc-ab0a-d43f33e10b12	f
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ebedc40b-df6e-4e55-bb01-d683b157d4b9	t
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	1a8174ab-5f62-462e-9380-e926c127aa90	t
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445	f
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	3393ebc4-0689-4f55-9087-a60de3a34598	t
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	74332565-499a-419e-a69e-b9d4899ce6ac	t
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	120a0809-cd54-4509-8d2e-0090ce0b21e7	f
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	3aa94e5f-8e2b-42ba-a86c-508aba36bec1	f
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	e849e53b-783e-44c1-a45c-bdfe533f5065	t
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	8fdcd5db-455e-4b76-8328-ca669a91a3a5	t
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	75ebc073-14b5-42db-ae35-b22346ba9c76	t
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	11a57828-c689-4449-a15c-f4b29520780f	t
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	83c5de7b-279a-41b5-86bf-74516fa1138c	f
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	8de2d4d9-d12b-41fa-969d-d446df01ad51	f
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d	t
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	235f04cb-37b9-461d-a5de-d4b02a934aaa	t
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	c4912ba0-064a-46a9-a712-d73df14769e4	f
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0460b492-55b8-4cd2-8e73-2673bc6f8a8f	t
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	91246858-8e79-4627-87d9-bf924c3669d6	t
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	c0df5c54-15f4-4344-a1b4-27d390ec3342	f
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id, details_json_long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only, organization_id, hide_on_login) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: jgroups_ping; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.jgroups_ping (address, name, cluster_name, ip, coord) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.keycloak_group (id, name, parent_group, realm_id, type) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
7e5d7b82-8607-4196-99b5-e6202cc8cfac	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f	${role_default-roles}	default-roles-master	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N	\N
5d9e55f9-a701-42dd-b811-0becaa4f200a	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f	${role_admin}	admin	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N	\N
b42b7001-ac0a-4424-81f3-32f52e54b030	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f	${role_create-realm}	create-realm	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N	\N
b6b92206-d3af-4040-bc86-5070f56fdd35	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_create-client}	create-client	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
0c2f9cfd-1aee-462a-97a9-be7e386245dc	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_view-realm}	view-realm	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
bc67dbe0-c132-4576-83f3-9b1cc146be43	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_view-users}	view-users	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
1b29c4dc-1a1d-4df8-81b6-beed3974a40b	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_view-clients}	view-clients	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
a351a9f1-ff94-4fe8-b51b-29251e1e6162	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_view-events}	view-events	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
f9ae8c35-cfb0-4052-9c86-6bbfee6ebc40	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_view-identity-providers}	view-identity-providers	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
2bd36636-a23f-43d4-b3c8-2fe8538ee820	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_view-authorization}	view-authorization	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
9b6cd81b-cb3e-48b3-addb-cafd210045e8	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_manage-realm}	manage-realm	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
f9ff3d42-7995-4ec3-b7cf-8a0150dfe1a7	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_manage-users}	manage-users	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
182c4ab8-cab8-4af7-adfe-d4b390491d98	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_manage-clients}	manage-clients	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
c883a683-6aaa-4c36-9946-826c75f0aca3	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_manage-events}	manage-events	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
7d231c3a-4cc0-4f29-b615-f0e45b480643	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_manage-identity-providers}	manage-identity-providers	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
3b959772-3bfe-4729-b450-4a8a3ead3701	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_manage-authorization}	manage-authorization	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
9d73784e-f68e-4499-b2fc-a1a86a231c8a	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_query-users}	query-users	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
8e544550-8b54-46df-a01b-589f29c19984	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_query-clients}	query-clients	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
0db44a34-ea46-447f-ab61-45f839997b6f	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_query-realms}	query-realms	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
1deba277-c039-4681-9df0-fcfaef7b9903	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_query-groups}	query-groups	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
d3198b1a-39aa-4dbe-ac2f-dc9fa9a85ffb	2bdc8e7d-2806-4626-81da-da6449d58897	t	${role_view-profile}	view-profile	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bdc8e7d-2806-4626-81da-da6449d58897	\N
93f3e94d-4e24-453c-80da-d5d73760c32e	2bdc8e7d-2806-4626-81da-da6449d58897	t	${role_manage-account}	manage-account	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bdc8e7d-2806-4626-81da-da6449d58897	\N
1580fe23-ed33-4cdb-943c-da8686829f3f	2bdc8e7d-2806-4626-81da-da6449d58897	t	${role_manage-account-links}	manage-account-links	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bdc8e7d-2806-4626-81da-da6449d58897	\N
fcda5be3-4c1c-4026-b092-bea67847d5ea	2bdc8e7d-2806-4626-81da-da6449d58897	t	${role_view-applications}	view-applications	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bdc8e7d-2806-4626-81da-da6449d58897	\N
0256590f-92d8-4710-9c9c-1201c18f9fc0	2bdc8e7d-2806-4626-81da-da6449d58897	t	${role_view-consent}	view-consent	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bdc8e7d-2806-4626-81da-da6449d58897	\N
6da983d4-5229-4f52-9984-0a67250ffed6	2bdc8e7d-2806-4626-81da-da6449d58897	t	${role_manage-consent}	manage-consent	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bdc8e7d-2806-4626-81da-da6449d58897	\N
46710c75-5812-41e9-a391-5cf96b0d96ea	2bdc8e7d-2806-4626-81da-da6449d58897	t	${role_view-groups}	view-groups	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bdc8e7d-2806-4626-81da-da6449d58897	\N
b99bf3cf-e433-4326-a49e-c8b39adfeddc	2bdc8e7d-2806-4626-81da-da6449d58897	t	${role_delete-account}	delete-account	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	2bdc8e7d-2806-4626-81da-da6449d58897	\N
18e4e96f-e8c2-4a36-992b-63a8be390715	65755de2-f3c7-4ae3-a3d4-cc979fbcb147	t	${role_read-token}	read-token	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	65755de2-f3c7-4ae3-a3d4-cc979fbcb147	\N
565e0a19-9171-4789-ab4f-5c1f7d94ce7e	ab0b18a6-c7f9-46c6-930d-6600c036326c	t	${role_impersonation}	impersonation	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	ab0b18a6-c7f9-46c6-930d-6600c036326c	\N
b9f75f96-29f3-4e58-afdc-7f5aaa28db9c	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f	${role_offline-access}	offline_access	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N	\N
0d7569f9-9ea2-41d2-be2a-149fa8fc8dbd	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f	${role_uma_authorization}	uma_authorization	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	\N	\N
9379f18e-adcb-491c-8814-65c69dd45091	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	f	${role_default-roles}	default-roles-qm-realm	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	\N	\N
0405bff8-ad28-4235-b16b-23aec7d2cda2	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_create-client}	create-client	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
0073166b-e0fc-44c4-a9f5-5e226b40d88c	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_view-realm}	view-realm	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
d4abeb26-12a0-4482-a300-fc867d4718b3	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_view-users}	view-users	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
e90c883c-f91b-41fb-8f12-97f1c9c0cf76	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_view-clients}	view-clients	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
01be9d01-ad0b-41a9-89e9-4ee015af7a26	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_view-events}	view-events	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
02e45112-fa44-4168-9696-e9123029f60e	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_view-identity-providers}	view-identity-providers	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
f076583b-1d29-4fa7-a85d-f0ae7b19aad6	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_view-authorization}	view-authorization	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
7d211a02-4971-468d-8902-276a4f98a405	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_manage-realm}	manage-realm	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
37aa3fb0-2c08-42c8-9cef-e9536c2c4ba9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_manage-users}	manage-users	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
87b2af4c-6fad-4042-be55-7c17c7278c55	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_manage-clients}	manage-clients	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
08dd11df-d349-48d1-8d90-471bd2f5e1ba	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_manage-events}	manage-events	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
6ae9bcea-1d57-4205-aa27-9f96ddf9fdb8	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_manage-identity-providers}	manage-identity-providers	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
ea21fe1d-aa3d-4898-b917-632da25ffdb7	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_manage-authorization}	manage-authorization	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
2130cb1b-b249-48a3-851d-b3240dd246ef	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_query-users}	query-users	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
601d33e6-3786-4785-b4db-c08ba149f74b	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_query-clients}	query-clients	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
3b85eec0-266a-4b75-960a-a098f24808b1	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_query-realms}	query-realms	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
bed20f92-bced-4cef-9846-b7e3568751ca	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_query-groups}	query-groups	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
f4228e39-24a2-4d6b-a9eb-e6b164ab1cb9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_realm-admin}	realm-admin	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
7628fffc-bf3b-4983-8a93-f247d6437796	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_create-client}	create-client	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
d44ee703-3a2b-4517-963a-3d99517bc634	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_view-realm}	view-realm	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
58bd0d0e-91d2-475f-8fe8-93aff6d389b5	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_view-users}	view-users	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
79051427-b1d6-4449-a293-f6a3fba474f2	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_view-clients}	view-clients	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
a7aff16c-6e47-47ae-b62d-dcfc48001d2f	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_view-events}	view-events	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
b6d5e834-e66a-43e2-afd1-a5bd4e55898c	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_view-identity-providers}	view-identity-providers	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
5898f5b3-3dea-4cd3-93d5-d575fbb0d440	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_view-authorization}	view-authorization	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
8aa93c48-5303-4ddd-890f-39b85b1b3d5f	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_manage-realm}	manage-realm	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
5220c770-5045-4555-ada3-472d1812536f	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_manage-users}	manage-users	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
85dd76b7-2e2e-4578-a73f-982544915a7c	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_manage-clients}	manage-clients	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
d999f8b3-3006-4584-be7b-52d447588d56	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_manage-events}	manage-events	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
675337c4-252a-48bc-b301-20e74cc0567e	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_manage-identity-providers}	manage-identity-providers	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
01a4ecbc-c48e-4b16-a7eb-189469a97d3d	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_manage-authorization}	manage-authorization	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
40645707-f71e-42ed-a3b6-b39fdc6b63d6	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_query-users}	query-users	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
d3269833-f8d8-4b20-b348-244fdfa46ff2	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_query-clients}	query-clients	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
8eead9ed-c74c-4822-ac8f-bcde5d95f588	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_query-realms}	query-realms	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
ff4eb52c-14ae-4ef5-a93b-58e29f2fc284	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_query-groups}	query-groups	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
979bbe85-37cf-4efc-b5bc-54ac130ed833	55bfc23e-79c7-4a5f-96a4-503b7025f85a	t	${role_view-profile}	view-profile	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	55bfc23e-79c7-4a5f-96a4-503b7025f85a	\N
456ab443-1ca1-4bf6-a5cf-fdbcffe7dcdd	55bfc23e-79c7-4a5f-96a4-503b7025f85a	t	${role_manage-account}	manage-account	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	55bfc23e-79c7-4a5f-96a4-503b7025f85a	\N
545a5d6f-a2d7-4a21-ae4f-8a82ad2f7718	55bfc23e-79c7-4a5f-96a4-503b7025f85a	t	${role_manage-account-links}	manage-account-links	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	55bfc23e-79c7-4a5f-96a4-503b7025f85a	\N
0e4f5812-e067-45ba-9d62-d2b899d50c54	55bfc23e-79c7-4a5f-96a4-503b7025f85a	t	${role_view-applications}	view-applications	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	55bfc23e-79c7-4a5f-96a4-503b7025f85a	\N
22c22483-acad-4494-9c67-d579f4b84855	55bfc23e-79c7-4a5f-96a4-503b7025f85a	t	${role_view-consent}	view-consent	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	55bfc23e-79c7-4a5f-96a4-503b7025f85a	\N
2ac80b00-8b52-4de5-8533-fbd8d8eb0cdf	55bfc23e-79c7-4a5f-96a4-503b7025f85a	t	${role_manage-consent}	manage-consent	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	55bfc23e-79c7-4a5f-96a4-503b7025f85a	\N
41d03541-0860-407f-912a-4d53ed776587	55bfc23e-79c7-4a5f-96a4-503b7025f85a	t	${role_view-groups}	view-groups	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	55bfc23e-79c7-4a5f-96a4-503b7025f85a	\N
c3653e0c-503a-4dc8-b616-06c2a32f9d5c	55bfc23e-79c7-4a5f-96a4-503b7025f85a	t	${role_delete-account}	delete-account	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	55bfc23e-79c7-4a5f-96a4-503b7025f85a	\N
131a42b1-d5a5-4e10-977e-261ea0af615f	52a0c24b-597a-49f9-b7b7-62e0db05f1af	t	${role_impersonation}	impersonation	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	52a0c24b-597a-49f9-b7b7-62e0db05f1af	\N
93ca4e30-3297-4b4b-b297-83cb2512213a	0f18f0e2-5dd7-4eee-893d-694455cc0af4	t	${role_impersonation}	impersonation	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0f18f0e2-5dd7-4eee-893d-694455cc0af4	\N
fc7f1858-01dd-4a50-9fc2-f91272380ddd	be74d082-fd6a-4cc8-910f-a65a46e13f28	t	${role_read-token}	read-token	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	be74d082-fd6a-4cc8-910f-a65a46e13f28	\N
c48730f2-f365-4d19-bb82-a587b0e9f9e4	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	f	${role_offline-access}	offline_access	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	\N	\N
c229178b-28b5-4fba-82c7-0ea3186b0c22	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	f	${role_uma_authorization}	uma_authorization	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	\N	\N
14fa601d-546b-4a73-9696-caca85f4ddc4	14f121b4-4d55-46e7-abd5-161dd1da7bbe	t	\N	uma_protection	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	14f121b4-4d55-46e7-abd5-161dd1da7bbe	\N
7b8d1000-e030-4600-ad8c-09e08ff39c85	14f121b4-4d55-46e7-abd5-161dd1da7bbe	t		USER	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	14f121b4-4d55-46e7-abd5-161dd1da7bbe	\N
55a3d88d-ef6e-4d72-9db3-9906878e36aa	14f121b4-4d55-46e7-abd5-161dd1da7bbe	t		ADMIN	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	14f121b4-4d55-46e7-abd5-161dd1da7bbe	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.migration_model (id, version, update_time) FROM stdin;
j8yex	26.1.0	1775152150
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id, version) FROM stdin;
d3a972b3-1b2f-4a2b-a611-9ca834a46952	924011ef-3a2f-4fd4-a007-37fe61577d11	0	1775152467	{"authMethod":"openid-connect","redirectUri":"http://localhost:8186/admin/master/console/","notes":{"clientId":"924011ef-3a2f-4fd4-a007-37fe61577d11","iss":"http://localhost:8186/realms/master","startedAt":"1775152222","response_type":"code","level-of-authentication":"-1","code_challenge_method":"S256","nonce":"7d54cef5-8b45-4c33-ada2-9a03458bd735","response_mode":"query","scope":"openid","userSessionStartedAt":"1775152222","redirect_uri":"http://localhost:8186/admin/master/console/","state":"a86b90c6-23b3-46e4-80b6-f0b1f85498a9","code_challenge":"AljDUtQSvbbghl3duP2RGvpJ2nHuvJEgZO_-KPh7zRE"}}	local	local	4
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh, broker_session_id, version) FROM stdin;
d3a972b3-1b2f-4a2b-a611-9ca834a46952	f651f055-58c0-41c5-b2dc-6b6e2fbb6c26	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	1775152222	0	{"ipAddress":"172.18.0.1","authMethod":"openid-connect","rememberMe":false,"started":0,"notes":{"KC_DEVICE_NOTE":"eyJpcEFkZHJlc3MiOiIxNzIuMTguMC4xIiwib3MiOiJXaW5kb3dzIiwib3NWZXJzaW9uIjoiMTAiLCJicm93c2VyIjoiQ2hyb21lLzE0Ni4wLjAiLCJkZXZpY2UiOiJPdGhlciIsImxhc3RBY2Nlc3MiOjAsIm1vYmlsZSI6ZmFsc2V9","AUTH_TIME":"1775152222","authenticators-completed":"{\\"d82aa943-f00e-40d5-b598-3c9ca03f2738\\":1775152222}"},"state":"LOGGED_IN"}	1775152467	\N	4
\.


--
-- Data for Name: org; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.org (id, enabled, realm_id, group_id, name, description, alias, redirect_url) FROM stdin;
\.


--
-- Data for Name: org_domain; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.org_domain (id, name, verified, org_id) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
e5499399-ad89-4bd1-8992-41be9abed651	code	// by default, grants any permission associated with this policy\n$evaluation.grant();\n
979b9dbb-5be5-4347-a259-6a6fba8d715d	defaultResourceType	urn:qm-client:resources:default
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
8e0b870c-4f7b-4a68-aba6-ffebec24fde8	audience resolve	openid-connect	oidc-audience-resolve-mapper	551feff9-1317-4fed-9053-411a8810c565	\N
f6572a65-6aa7-4a3c-8d61-e50a6229eff6	locale	openid-connect	oidc-usermodel-attribute-mapper	924011ef-3a2f-4fd4-a007-37fe61577d11	\N
02b2ddfc-9059-405b-8c48-1a2d45d75c40	role list	saml	saml-role-list-mapper	\N	56f54f1c-8537-4574-b880-1a96cfd95b7c
a72f606f-2132-496a-865a-64f3ea2c80f0	organization	saml	saml-organization-membership-mapper	\N	25289ed7-2a9d-4bb5-be28-574e102d35f8
19de9169-9242-4aec-bde4-7a3066d3d56e	full name	openid-connect	oidc-full-name-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
3ff2d5e2-e90b-4b59-8e0e-8fb58ce39cd3	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
a0ad6077-562a-4ae0-ae81-6fe5e3366b27	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
ef24fa11-4674-4c70-8827-3b760ba13407	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
6f12401e-6835-49f5-ba47-bc80fdabfe15	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
4969594f-b01a-4472-bb51-6ddd2a08deed	username	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
69b471b1-e928-4b08-9ca2-a57f3a146757	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
855907e7-71c4-4dbc-ad37-828c318e06a2	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
2eccc585-1d73-4557-8d58-a7ce7de34bbd	website	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
34e3a11c-13bb-47c3-9458-032e44912621	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
4585c7f6-78d4-4b9e-a03c-cd63b128b6a0	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
95c98656-d138-4a5a-89fc-9b2a803121b2	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
0e6828c1-8cd4-4c68-9f82-b951d8b84616	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
030e3737-e127-44d1-bdbb-ee56b3deca1c	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	fd8be0d3-37bf-416c-9491-8eed1f661408
3efb2159-1bf1-41d5-954f-9c0f5b5b70f4	email	openid-connect	oidc-usermodel-attribute-mapper	\N	c174415c-a203-4e6e-9047-631ceec5e059
89aefd4b-dafa-4d7f-ade9-7e5d694831ad	email verified	openid-connect	oidc-usermodel-property-mapper	\N	c174415c-a203-4e6e-9047-631ceec5e059
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	address	openid-connect	oidc-address-mapper	\N	a6bbe01b-cbcb-4357-bfd3-2f036cdf423b
376377e3-bbc4-4691-9945-06c0f3777c29	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	d17d9492-a4a0-46dc-ab0a-d43f33e10b12
71021085-f393-475a-8175-7a8ff0c97c53	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	d17d9492-a4a0-46dc-ab0a-d43f33e10b12
28c061b2-b837-4c8e-a36a-53c43472a434	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	ebedc40b-df6e-4e55-bb01-d683b157d4b9
97fbf2b9-5729-4c47-8146-5e6268fdb35d	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	ebedc40b-df6e-4e55-bb01-d683b157d4b9
8799126d-47c6-4263-b6f6-960d90648c75	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	ebedc40b-df6e-4e55-bb01-d683b157d4b9
d1a16cbd-733b-4479-9b67-52758fed3f72	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	1a8174ab-5f62-462e-9380-e926c127aa90
4f485bc7-1ddb-416a-b281-060d7a43449b	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445
a2a31c03-2dce-4a2a-8adc-6bd529350d9a	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	a60fe8d9-1ce5-4f5a-bed8-8c22ef52a445
4277a05b-e654-4292-9c9c-0d1e3583c526	acr loa level	openid-connect	oidc-acr-mapper	\N	3393ebc4-0689-4f55-9087-a60de3a34598
22c24b5d-a7af-493e-a4ef-64ade3ed768a	auth_time	openid-connect	oidc-usersessionmodel-note-mapper	\N	74332565-499a-419e-a69e-b9d4899ce6ac
8551a397-deb7-4e3c-8fa0-6675b200f689	sub	openid-connect	oidc-sub-mapper	\N	74332565-499a-419e-a69e-b9d4899ce6ac
3c67e084-86ab-49c1-91cb-03e74b0c8b87	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	\N	a11cfa9f-9dac-4c76-8018-a00633007f78
00362887-f68f-4f88-961d-43f85a0ede1e	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	\N	a11cfa9f-9dac-4c76-8018-a00633007f78
1f729562-5b61-4079-ac7d-8d5209b4632d	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	\N	a11cfa9f-9dac-4c76-8018-a00633007f78
39c4470e-ad26-4838-988d-c6a0e90e2026	organization	openid-connect	oidc-organization-membership-mapper	\N	120a0809-cd54-4509-8d2e-0090ce0b21e7
b1bddcac-22f7-4680-92be-407b6fa318ab	audience resolve	openid-connect	oidc-audience-resolve-mapper	e39f027b-a76d-418e-80a1-190263cc2b2e	\N
ef969c2a-1362-4a01-95b2-32b199d44fa2	role list	saml	saml-role-list-mapper	\N	e849e53b-783e-44c1-a45c-bdfe533f5065
c444534d-0b4c-412b-ad2c-158d61479f69	organization	saml	saml-organization-membership-mapper	\N	8fdcd5db-455e-4b76-8328-ca669a91a3a5
35803bbe-f3e7-40eb-9072-f87d4b0e818b	full name	openid-connect	oidc-full-name-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
2a6c99af-184f-4741-9181-10a290779fe8	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
3abf32a8-427e-419c-a24c-86dc3712cdae	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
3dd66bf8-058f-4875-a85a-e23b5339d4a1	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
9841b3bc-41ae-415d-8f49-220bf75b9a7c	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
1586c52b-100c-41fc-8734-471482f8e088	username	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
124180a0-3435-453d-a7e1-cc954ff2f432	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
bdb5c3f1-c223-4e0f-b519-97a28377741f	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
1f6949dc-b3fd-4b80-82ed-c67fd89c0167	website	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
f89032f9-6eda-48ed-9d7f-ee333f265d64	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
c78cf247-03ad-4b2f-beeb-2815587f2802	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
255275eb-dee4-43e8-8f7f-9d50c7b72bb3	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
56d73064-a69d-4c3e-8b0a-c6227e86583e	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
4cc571d6-02a3-4d54-bdd7-22cc068e8114	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	75ebc073-14b5-42db-ae35-b22346ba9c76
ce47490c-aca9-40c1-ba11-ccebd8013c5f	email	openid-connect	oidc-usermodel-attribute-mapper	\N	11a57828-c689-4449-a15c-f4b29520780f
e8394f66-3a3b-4c44-8793-11064f6263fa	email verified	openid-connect	oidc-usermodel-property-mapper	\N	11a57828-c689-4449-a15c-f4b29520780f
72ea541c-ac2d-4c70-a962-dbd473467acc	address	openid-connect	oidc-address-mapper	\N	83c5de7b-279a-41b5-86bf-74516fa1138c
34538bac-0530-4b7a-b225-121dabd0e6e3	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	8de2d4d9-d12b-41fa-969d-d446df01ad51
c3993076-de64-4d83-8beb-e3704c4c9722	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	8de2d4d9-d12b-41fa-969d-d446df01ad51
515f9181-2d34-4389-b94c-c1a4707dded4	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d
f15eaa6b-d803-48f7-b6b0-8a0b4364db87	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d
216f1918-f7e3-4d2d-9376-571e533e42b1	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	e2f4bfaf-64b5-487a-ae22-132eb5b64b6d
bab8fe82-1986-4da2-8e87-ec26eee5ee15	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	235f04cb-37b9-461d-a5de-d4b02a934aaa
3325e56b-7482-4d19-b0ec-73ef73fa9f42	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	c4912ba0-064a-46a9-a712-d73df14769e4
d4c42cfd-ca55-48dd-bc61-5d4206d4d998	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	c4912ba0-064a-46a9-a712-d73df14769e4
6fcb83d3-b69a-47c4-8e98-0471bbf941d7	acr loa level	openid-connect	oidc-acr-mapper	\N	0460b492-55b8-4cd2-8e73-2673bc6f8a8f
d8a5edc0-0302-47ee-b379-03df80fc28cb	auth_time	openid-connect	oidc-usersessionmodel-note-mapper	\N	91246858-8e79-4627-87d9-bf924c3669d6
ee3007be-34b7-4191-aee3-38b530ff13f9	sub	openid-connect	oidc-sub-mapper	\N	91246858-8e79-4627-87d9-bf924c3669d6
4ddc1cdf-40b8-43ea-93b2-2af6118ff887	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	\N	d4e95fec-9fad-462f-9ae1-bd7719fbaef9
5ce45af6-28da-4dd9-a92d-8577082a5b0e	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	\N	d4e95fec-9fad-462f-9ae1-bd7719fbaef9
02d7b967-fa3d-480b-af13-4e75656d2704	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	\N	d4e95fec-9fad-462f-9ae1-bd7719fbaef9
2ca5b5c2-0d31-4b41-a4d3-a2dc438ae450	organization	openid-connect	oidc-organization-membership-mapper	\N	c0df5c54-15f4-4344-a1b4-27d390ec3342
5c7718a5-c06b-4f97-a77e-2df08a92a4ce	locale	openid-connect	oidc-usermodel-attribute-mapper	5b81c8b8-e05f-4298-a125-4bbf2215fb55	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
f6572a65-6aa7-4a3c-8d61-e50a6229eff6	true	introspection.token.claim
f6572a65-6aa7-4a3c-8d61-e50a6229eff6	true	userinfo.token.claim
f6572a65-6aa7-4a3c-8d61-e50a6229eff6	locale	user.attribute
f6572a65-6aa7-4a3c-8d61-e50a6229eff6	true	id.token.claim
f6572a65-6aa7-4a3c-8d61-e50a6229eff6	true	access.token.claim
f6572a65-6aa7-4a3c-8d61-e50a6229eff6	locale	claim.name
f6572a65-6aa7-4a3c-8d61-e50a6229eff6	String	jsonType.label
02b2ddfc-9059-405b-8c48-1a2d45d75c40	false	single
02b2ddfc-9059-405b-8c48-1a2d45d75c40	Basic	attribute.nameformat
02b2ddfc-9059-405b-8c48-1a2d45d75c40	Role	attribute.name
030e3737-e127-44d1-bdbb-ee56b3deca1c	true	introspection.token.claim
030e3737-e127-44d1-bdbb-ee56b3deca1c	true	userinfo.token.claim
030e3737-e127-44d1-bdbb-ee56b3deca1c	updatedAt	user.attribute
030e3737-e127-44d1-bdbb-ee56b3deca1c	true	id.token.claim
030e3737-e127-44d1-bdbb-ee56b3deca1c	true	access.token.claim
030e3737-e127-44d1-bdbb-ee56b3deca1c	updated_at	claim.name
030e3737-e127-44d1-bdbb-ee56b3deca1c	long	jsonType.label
0e6828c1-8cd4-4c68-9f82-b951d8b84616	true	introspection.token.claim
0e6828c1-8cd4-4c68-9f82-b951d8b84616	true	userinfo.token.claim
0e6828c1-8cd4-4c68-9f82-b951d8b84616	locale	user.attribute
0e6828c1-8cd4-4c68-9f82-b951d8b84616	true	id.token.claim
0e6828c1-8cd4-4c68-9f82-b951d8b84616	true	access.token.claim
0e6828c1-8cd4-4c68-9f82-b951d8b84616	locale	claim.name
0e6828c1-8cd4-4c68-9f82-b951d8b84616	String	jsonType.label
19de9169-9242-4aec-bde4-7a3066d3d56e	true	introspection.token.claim
19de9169-9242-4aec-bde4-7a3066d3d56e	true	userinfo.token.claim
19de9169-9242-4aec-bde4-7a3066d3d56e	true	id.token.claim
19de9169-9242-4aec-bde4-7a3066d3d56e	true	access.token.claim
2eccc585-1d73-4557-8d58-a7ce7de34bbd	true	introspection.token.claim
2eccc585-1d73-4557-8d58-a7ce7de34bbd	true	userinfo.token.claim
2eccc585-1d73-4557-8d58-a7ce7de34bbd	website	user.attribute
2eccc585-1d73-4557-8d58-a7ce7de34bbd	true	id.token.claim
2eccc585-1d73-4557-8d58-a7ce7de34bbd	true	access.token.claim
2eccc585-1d73-4557-8d58-a7ce7de34bbd	website	claim.name
2eccc585-1d73-4557-8d58-a7ce7de34bbd	String	jsonType.label
34e3a11c-13bb-47c3-9458-032e44912621	true	introspection.token.claim
34e3a11c-13bb-47c3-9458-032e44912621	true	userinfo.token.claim
34e3a11c-13bb-47c3-9458-032e44912621	gender	user.attribute
34e3a11c-13bb-47c3-9458-032e44912621	true	id.token.claim
34e3a11c-13bb-47c3-9458-032e44912621	true	access.token.claim
34e3a11c-13bb-47c3-9458-032e44912621	gender	claim.name
34e3a11c-13bb-47c3-9458-032e44912621	String	jsonType.label
3ff2d5e2-e90b-4b59-8e0e-8fb58ce39cd3	true	introspection.token.claim
3ff2d5e2-e90b-4b59-8e0e-8fb58ce39cd3	true	userinfo.token.claim
3ff2d5e2-e90b-4b59-8e0e-8fb58ce39cd3	lastName	user.attribute
3ff2d5e2-e90b-4b59-8e0e-8fb58ce39cd3	true	id.token.claim
3ff2d5e2-e90b-4b59-8e0e-8fb58ce39cd3	true	access.token.claim
3ff2d5e2-e90b-4b59-8e0e-8fb58ce39cd3	family_name	claim.name
3ff2d5e2-e90b-4b59-8e0e-8fb58ce39cd3	String	jsonType.label
4585c7f6-78d4-4b9e-a03c-cd63b128b6a0	true	introspection.token.claim
4585c7f6-78d4-4b9e-a03c-cd63b128b6a0	true	userinfo.token.claim
4585c7f6-78d4-4b9e-a03c-cd63b128b6a0	birthdate	user.attribute
4585c7f6-78d4-4b9e-a03c-cd63b128b6a0	true	id.token.claim
4585c7f6-78d4-4b9e-a03c-cd63b128b6a0	true	access.token.claim
4585c7f6-78d4-4b9e-a03c-cd63b128b6a0	birthdate	claim.name
4585c7f6-78d4-4b9e-a03c-cd63b128b6a0	String	jsonType.label
4969594f-b01a-4472-bb51-6ddd2a08deed	true	introspection.token.claim
4969594f-b01a-4472-bb51-6ddd2a08deed	true	userinfo.token.claim
4969594f-b01a-4472-bb51-6ddd2a08deed	username	user.attribute
4969594f-b01a-4472-bb51-6ddd2a08deed	true	id.token.claim
4969594f-b01a-4472-bb51-6ddd2a08deed	true	access.token.claim
4969594f-b01a-4472-bb51-6ddd2a08deed	preferred_username	claim.name
4969594f-b01a-4472-bb51-6ddd2a08deed	String	jsonType.label
69b471b1-e928-4b08-9ca2-a57f3a146757	true	introspection.token.claim
69b471b1-e928-4b08-9ca2-a57f3a146757	true	userinfo.token.claim
69b471b1-e928-4b08-9ca2-a57f3a146757	profile	user.attribute
69b471b1-e928-4b08-9ca2-a57f3a146757	true	id.token.claim
69b471b1-e928-4b08-9ca2-a57f3a146757	true	access.token.claim
69b471b1-e928-4b08-9ca2-a57f3a146757	profile	claim.name
69b471b1-e928-4b08-9ca2-a57f3a146757	String	jsonType.label
6f12401e-6835-49f5-ba47-bc80fdabfe15	true	introspection.token.claim
6f12401e-6835-49f5-ba47-bc80fdabfe15	true	userinfo.token.claim
6f12401e-6835-49f5-ba47-bc80fdabfe15	nickname	user.attribute
6f12401e-6835-49f5-ba47-bc80fdabfe15	true	id.token.claim
6f12401e-6835-49f5-ba47-bc80fdabfe15	true	access.token.claim
6f12401e-6835-49f5-ba47-bc80fdabfe15	nickname	claim.name
6f12401e-6835-49f5-ba47-bc80fdabfe15	String	jsonType.label
855907e7-71c4-4dbc-ad37-828c318e06a2	true	introspection.token.claim
855907e7-71c4-4dbc-ad37-828c318e06a2	true	userinfo.token.claim
855907e7-71c4-4dbc-ad37-828c318e06a2	picture	user.attribute
855907e7-71c4-4dbc-ad37-828c318e06a2	true	id.token.claim
855907e7-71c4-4dbc-ad37-828c318e06a2	true	access.token.claim
855907e7-71c4-4dbc-ad37-828c318e06a2	picture	claim.name
855907e7-71c4-4dbc-ad37-828c318e06a2	String	jsonType.label
95c98656-d138-4a5a-89fc-9b2a803121b2	true	introspection.token.claim
95c98656-d138-4a5a-89fc-9b2a803121b2	true	userinfo.token.claim
95c98656-d138-4a5a-89fc-9b2a803121b2	zoneinfo	user.attribute
95c98656-d138-4a5a-89fc-9b2a803121b2	true	id.token.claim
95c98656-d138-4a5a-89fc-9b2a803121b2	true	access.token.claim
95c98656-d138-4a5a-89fc-9b2a803121b2	zoneinfo	claim.name
95c98656-d138-4a5a-89fc-9b2a803121b2	String	jsonType.label
a0ad6077-562a-4ae0-ae81-6fe5e3366b27	true	introspection.token.claim
a0ad6077-562a-4ae0-ae81-6fe5e3366b27	true	userinfo.token.claim
a0ad6077-562a-4ae0-ae81-6fe5e3366b27	firstName	user.attribute
a0ad6077-562a-4ae0-ae81-6fe5e3366b27	true	id.token.claim
a0ad6077-562a-4ae0-ae81-6fe5e3366b27	true	access.token.claim
a0ad6077-562a-4ae0-ae81-6fe5e3366b27	given_name	claim.name
a0ad6077-562a-4ae0-ae81-6fe5e3366b27	String	jsonType.label
ef24fa11-4674-4c70-8827-3b760ba13407	true	introspection.token.claim
ef24fa11-4674-4c70-8827-3b760ba13407	true	userinfo.token.claim
ef24fa11-4674-4c70-8827-3b760ba13407	middleName	user.attribute
ef24fa11-4674-4c70-8827-3b760ba13407	true	id.token.claim
ef24fa11-4674-4c70-8827-3b760ba13407	true	access.token.claim
ef24fa11-4674-4c70-8827-3b760ba13407	middle_name	claim.name
ef24fa11-4674-4c70-8827-3b760ba13407	String	jsonType.label
3efb2159-1bf1-41d5-954f-9c0f5b5b70f4	true	introspection.token.claim
3efb2159-1bf1-41d5-954f-9c0f5b5b70f4	true	userinfo.token.claim
3efb2159-1bf1-41d5-954f-9c0f5b5b70f4	email	user.attribute
3efb2159-1bf1-41d5-954f-9c0f5b5b70f4	true	id.token.claim
3efb2159-1bf1-41d5-954f-9c0f5b5b70f4	true	access.token.claim
3efb2159-1bf1-41d5-954f-9c0f5b5b70f4	email	claim.name
3efb2159-1bf1-41d5-954f-9c0f5b5b70f4	String	jsonType.label
89aefd4b-dafa-4d7f-ade9-7e5d694831ad	true	introspection.token.claim
89aefd4b-dafa-4d7f-ade9-7e5d694831ad	true	userinfo.token.claim
89aefd4b-dafa-4d7f-ade9-7e5d694831ad	emailVerified	user.attribute
89aefd4b-dafa-4d7f-ade9-7e5d694831ad	true	id.token.claim
89aefd4b-dafa-4d7f-ade9-7e5d694831ad	true	access.token.claim
89aefd4b-dafa-4d7f-ade9-7e5d694831ad	email_verified	claim.name
89aefd4b-dafa-4d7f-ade9-7e5d694831ad	boolean	jsonType.label
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	formatted	user.attribute.formatted
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	country	user.attribute.country
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	true	introspection.token.claim
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	postal_code	user.attribute.postal_code
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	true	userinfo.token.claim
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	street	user.attribute.street
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	true	id.token.claim
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	region	user.attribute.region
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	true	access.token.claim
4f2e6218-f216-4e58-9f25-d7ca9f717d3f	locality	user.attribute.locality
376377e3-bbc4-4691-9945-06c0f3777c29	true	introspection.token.claim
376377e3-bbc4-4691-9945-06c0f3777c29	true	userinfo.token.claim
376377e3-bbc4-4691-9945-06c0f3777c29	phoneNumber	user.attribute
376377e3-bbc4-4691-9945-06c0f3777c29	true	id.token.claim
376377e3-bbc4-4691-9945-06c0f3777c29	true	access.token.claim
376377e3-bbc4-4691-9945-06c0f3777c29	phone_number	claim.name
376377e3-bbc4-4691-9945-06c0f3777c29	String	jsonType.label
71021085-f393-475a-8175-7a8ff0c97c53	true	introspection.token.claim
71021085-f393-475a-8175-7a8ff0c97c53	true	userinfo.token.claim
71021085-f393-475a-8175-7a8ff0c97c53	phoneNumberVerified	user.attribute
71021085-f393-475a-8175-7a8ff0c97c53	true	id.token.claim
71021085-f393-475a-8175-7a8ff0c97c53	true	access.token.claim
71021085-f393-475a-8175-7a8ff0c97c53	phone_number_verified	claim.name
71021085-f393-475a-8175-7a8ff0c97c53	boolean	jsonType.label
28c061b2-b837-4c8e-a36a-53c43472a434	true	introspection.token.claim
28c061b2-b837-4c8e-a36a-53c43472a434	true	multivalued
28c061b2-b837-4c8e-a36a-53c43472a434	foo	user.attribute
28c061b2-b837-4c8e-a36a-53c43472a434	true	access.token.claim
28c061b2-b837-4c8e-a36a-53c43472a434	realm_access.roles	claim.name
28c061b2-b837-4c8e-a36a-53c43472a434	String	jsonType.label
8799126d-47c6-4263-b6f6-960d90648c75	true	introspection.token.claim
8799126d-47c6-4263-b6f6-960d90648c75	true	access.token.claim
97fbf2b9-5729-4c47-8146-5e6268fdb35d	true	introspection.token.claim
97fbf2b9-5729-4c47-8146-5e6268fdb35d	true	multivalued
97fbf2b9-5729-4c47-8146-5e6268fdb35d	foo	user.attribute
97fbf2b9-5729-4c47-8146-5e6268fdb35d	true	access.token.claim
97fbf2b9-5729-4c47-8146-5e6268fdb35d	resource_access.${client_id}.roles	claim.name
97fbf2b9-5729-4c47-8146-5e6268fdb35d	String	jsonType.label
d1a16cbd-733b-4479-9b67-52758fed3f72	true	introspection.token.claim
d1a16cbd-733b-4479-9b67-52758fed3f72	true	access.token.claim
4f485bc7-1ddb-416a-b281-060d7a43449b	true	introspection.token.claim
4f485bc7-1ddb-416a-b281-060d7a43449b	true	userinfo.token.claim
4f485bc7-1ddb-416a-b281-060d7a43449b	username	user.attribute
4f485bc7-1ddb-416a-b281-060d7a43449b	true	id.token.claim
4f485bc7-1ddb-416a-b281-060d7a43449b	true	access.token.claim
4f485bc7-1ddb-416a-b281-060d7a43449b	upn	claim.name
4f485bc7-1ddb-416a-b281-060d7a43449b	String	jsonType.label
a2a31c03-2dce-4a2a-8adc-6bd529350d9a	true	introspection.token.claim
a2a31c03-2dce-4a2a-8adc-6bd529350d9a	true	multivalued
a2a31c03-2dce-4a2a-8adc-6bd529350d9a	foo	user.attribute
a2a31c03-2dce-4a2a-8adc-6bd529350d9a	true	id.token.claim
a2a31c03-2dce-4a2a-8adc-6bd529350d9a	true	access.token.claim
a2a31c03-2dce-4a2a-8adc-6bd529350d9a	groups	claim.name
a2a31c03-2dce-4a2a-8adc-6bd529350d9a	String	jsonType.label
4277a05b-e654-4292-9c9c-0d1e3583c526	true	introspection.token.claim
4277a05b-e654-4292-9c9c-0d1e3583c526	true	id.token.claim
4277a05b-e654-4292-9c9c-0d1e3583c526	true	access.token.claim
22c24b5d-a7af-493e-a4ef-64ade3ed768a	AUTH_TIME	user.session.note
22c24b5d-a7af-493e-a4ef-64ade3ed768a	true	introspection.token.claim
22c24b5d-a7af-493e-a4ef-64ade3ed768a	true	id.token.claim
22c24b5d-a7af-493e-a4ef-64ade3ed768a	true	access.token.claim
22c24b5d-a7af-493e-a4ef-64ade3ed768a	auth_time	claim.name
22c24b5d-a7af-493e-a4ef-64ade3ed768a	long	jsonType.label
8551a397-deb7-4e3c-8fa0-6675b200f689	true	introspection.token.claim
8551a397-deb7-4e3c-8fa0-6675b200f689	true	access.token.claim
00362887-f68f-4f88-961d-43f85a0ede1e	clientHost	user.session.note
00362887-f68f-4f88-961d-43f85a0ede1e	true	introspection.token.claim
00362887-f68f-4f88-961d-43f85a0ede1e	true	id.token.claim
00362887-f68f-4f88-961d-43f85a0ede1e	true	access.token.claim
00362887-f68f-4f88-961d-43f85a0ede1e	clientHost	claim.name
00362887-f68f-4f88-961d-43f85a0ede1e	String	jsonType.label
1f729562-5b61-4079-ac7d-8d5209b4632d	clientAddress	user.session.note
1f729562-5b61-4079-ac7d-8d5209b4632d	true	introspection.token.claim
1f729562-5b61-4079-ac7d-8d5209b4632d	true	id.token.claim
1f729562-5b61-4079-ac7d-8d5209b4632d	true	access.token.claim
1f729562-5b61-4079-ac7d-8d5209b4632d	clientAddress	claim.name
1f729562-5b61-4079-ac7d-8d5209b4632d	String	jsonType.label
3c67e084-86ab-49c1-91cb-03e74b0c8b87	client_id	user.session.note
3c67e084-86ab-49c1-91cb-03e74b0c8b87	true	introspection.token.claim
3c67e084-86ab-49c1-91cb-03e74b0c8b87	true	id.token.claim
3c67e084-86ab-49c1-91cb-03e74b0c8b87	true	access.token.claim
3c67e084-86ab-49c1-91cb-03e74b0c8b87	client_id	claim.name
3c67e084-86ab-49c1-91cb-03e74b0c8b87	String	jsonType.label
39c4470e-ad26-4838-988d-c6a0e90e2026	true	introspection.token.claim
39c4470e-ad26-4838-988d-c6a0e90e2026	true	multivalued
39c4470e-ad26-4838-988d-c6a0e90e2026	true	id.token.claim
39c4470e-ad26-4838-988d-c6a0e90e2026	true	access.token.claim
39c4470e-ad26-4838-988d-c6a0e90e2026	organization	claim.name
39c4470e-ad26-4838-988d-c6a0e90e2026	String	jsonType.label
ef969c2a-1362-4a01-95b2-32b199d44fa2	false	single
ef969c2a-1362-4a01-95b2-32b199d44fa2	Basic	attribute.nameformat
ef969c2a-1362-4a01-95b2-32b199d44fa2	Role	attribute.name
124180a0-3435-453d-a7e1-cc954ff2f432	true	introspection.token.claim
124180a0-3435-453d-a7e1-cc954ff2f432	true	userinfo.token.claim
124180a0-3435-453d-a7e1-cc954ff2f432	profile	user.attribute
124180a0-3435-453d-a7e1-cc954ff2f432	true	id.token.claim
124180a0-3435-453d-a7e1-cc954ff2f432	true	access.token.claim
124180a0-3435-453d-a7e1-cc954ff2f432	profile	claim.name
124180a0-3435-453d-a7e1-cc954ff2f432	String	jsonType.label
1586c52b-100c-41fc-8734-471482f8e088	true	introspection.token.claim
1586c52b-100c-41fc-8734-471482f8e088	true	userinfo.token.claim
1586c52b-100c-41fc-8734-471482f8e088	username	user.attribute
1586c52b-100c-41fc-8734-471482f8e088	true	id.token.claim
1586c52b-100c-41fc-8734-471482f8e088	true	access.token.claim
1586c52b-100c-41fc-8734-471482f8e088	preferred_username	claim.name
1586c52b-100c-41fc-8734-471482f8e088	String	jsonType.label
1f6949dc-b3fd-4b80-82ed-c67fd89c0167	true	introspection.token.claim
1f6949dc-b3fd-4b80-82ed-c67fd89c0167	true	userinfo.token.claim
1f6949dc-b3fd-4b80-82ed-c67fd89c0167	website	user.attribute
1f6949dc-b3fd-4b80-82ed-c67fd89c0167	true	id.token.claim
1f6949dc-b3fd-4b80-82ed-c67fd89c0167	true	access.token.claim
1f6949dc-b3fd-4b80-82ed-c67fd89c0167	website	claim.name
1f6949dc-b3fd-4b80-82ed-c67fd89c0167	String	jsonType.label
255275eb-dee4-43e8-8f7f-9d50c7b72bb3	true	introspection.token.claim
255275eb-dee4-43e8-8f7f-9d50c7b72bb3	true	userinfo.token.claim
255275eb-dee4-43e8-8f7f-9d50c7b72bb3	zoneinfo	user.attribute
255275eb-dee4-43e8-8f7f-9d50c7b72bb3	true	id.token.claim
255275eb-dee4-43e8-8f7f-9d50c7b72bb3	true	access.token.claim
255275eb-dee4-43e8-8f7f-9d50c7b72bb3	zoneinfo	claim.name
255275eb-dee4-43e8-8f7f-9d50c7b72bb3	String	jsonType.label
2a6c99af-184f-4741-9181-10a290779fe8	true	introspection.token.claim
2a6c99af-184f-4741-9181-10a290779fe8	true	userinfo.token.claim
2a6c99af-184f-4741-9181-10a290779fe8	lastName	user.attribute
2a6c99af-184f-4741-9181-10a290779fe8	true	id.token.claim
2a6c99af-184f-4741-9181-10a290779fe8	true	access.token.claim
2a6c99af-184f-4741-9181-10a290779fe8	family_name	claim.name
2a6c99af-184f-4741-9181-10a290779fe8	String	jsonType.label
35803bbe-f3e7-40eb-9072-f87d4b0e818b	true	introspection.token.claim
35803bbe-f3e7-40eb-9072-f87d4b0e818b	true	userinfo.token.claim
35803bbe-f3e7-40eb-9072-f87d4b0e818b	true	id.token.claim
35803bbe-f3e7-40eb-9072-f87d4b0e818b	true	access.token.claim
3abf32a8-427e-419c-a24c-86dc3712cdae	true	introspection.token.claim
3abf32a8-427e-419c-a24c-86dc3712cdae	true	userinfo.token.claim
3abf32a8-427e-419c-a24c-86dc3712cdae	firstName	user.attribute
3abf32a8-427e-419c-a24c-86dc3712cdae	true	id.token.claim
3abf32a8-427e-419c-a24c-86dc3712cdae	true	access.token.claim
3abf32a8-427e-419c-a24c-86dc3712cdae	given_name	claim.name
3abf32a8-427e-419c-a24c-86dc3712cdae	String	jsonType.label
3dd66bf8-058f-4875-a85a-e23b5339d4a1	true	introspection.token.claim
3dd66bf8-058f-4875-a85a-e23b5339d4a1	true	userinfo.token.claim
3dd66bf8-058f-4875-a85a-e23b5339d4a1	middleName	user.attribute
3dd66bf8-058f-4875-a85a-e23b5339d4a1	true	id.token.claim
3dd66bf8-058f-4875-a85a-e23b5339d4a1	true	access.token.claim
3dd66bf8-058f-4875-a85a-e23b5339d4a1	middle_name	claim.name
3dd66bf8-058f-4875-a85a-e23b5339d4a1	String	jsonType.label
4cc571d6-02a3-4d54-bdd7-22cc068e8114	true	introspection.token.claim
4cc571d6-02a3-4d54-bdd7-22cc068e8114	true	userinfo.token.claim
4cc571d6-02a3-4d54-bdd7-22cc068e8114	updatedAt	user.attribute
4cc571d6-02a3-4d54-bdd7-22cc068e8114	true	id.token.claim
4cc571d6-02a3-4d54-bdd7-22cc068e8114	true	access.token.claim
4cc571d6-02a3-4d54-bdd7-22cc068e8114	updated_at	claim.name
4cc571d6-02a3-4d54-bdd7-22cc068e8114	long	jsonType.label
56d73064-a69d-4c3e-8b0a-c6227e86583e	true	introspection.token.claim
56d73064-a69d-4c3e-8b0a-c6227e86583e	true	userinfo.token.claim
56d73064-a69d-4c3e-8b0a-c6227e86583e	locale	user.attribute
56d73064-a69d-4c3e-8b0a-c6227e86583e	true	id.token.claim
56d73064-a69d-4c3e-8b0a-c6227e86583e	true	access.token.claim
56d73064-a69d-4c3e-8b0a-c6227e86583e	locale	claim.name
56d73064-a69d-4c3e-8b0a-c6227e86583e	String	jsonType.label
9841b3bc-41ae-415d-8f49-220bf75b9a7c	true	introspection.token.claim
9841b3bc-41ae-415d-8f49-220bf75b9a7c	true	userinfo.token.claim
9841b3bc-41ae-415d-8f49-220bf75b9a7c	nickname	user.attribute
9841b3bc-41ae-415d-8f49-220bf75b9a7c	true	id.token.claim
9841b3bc-41ae-415d-8f49-220bf75b9a7c	true	access.token.claim
9841b3bc-41ae-415d-8f49-220bf75b9a7c	nickname	claim.name
9841b3bc-41ae-415d-8f49-220bf75b9a7c	String	jsonType.label
bdb5c3f1-c223-4e0f-b519-97a28377741f	true	introspection.token.claim
bdb5c3f1-c223-4e0f-b519-97a28377741f	true	userinfo.token.claim
bdb5c3f1-c223-4e0f-b519-97a28377741f	picture	user.attribute
bdb5c3f1-c223-4e0f-b519-97a28377741f	true	id.token.claim
bdb5c3f1-c223-4e0f-b519-97a28377741f	true	access.token.claim
bdb5c3f1-c223-4e0f-b519-97a28377741f	picture	claim.name
bdb5c3f1-c223-4e0f-b519-97a28377741f	String	jsonType.label
c78cf247-03ad-4b2f-beeb-2815587f2802	true	introspection.token.claim
c78cf247-03ad-4b2f-beeb-2815587f2802	true	userinfo.token.claim
c78cf247-03ad-4b2f-beeb-2815587f2802	birthdate	user.attribute
c78cf247-03ad-4b2f-beeb-2815587f2802	true	id.token.claim
c78cf247-03ad-4b2f-beeb-2815587f2802	true	access.token.claim
c78cf247-03ad-4b2f-beeb-2815587f2802	birthdate	claim.name
c78cf247-03ad-4b2f-beeb-2815587f2802	String	jsonType.label
f89032f9-6eda-48ed-9d7f-ee333f265d64	true	introspection.token.claim
f89032f9-6eda-48ed-9d7f-ee333f265d64	true	userinfo.token.claim
f89032f9-6eda-48ed-9d7f-ee333f265d64	gender	user.attribute
f89032f9-6eda-48ed-9d7f-ee333f265d64	true	id.token.claim
f89032f9-6eda-48ed-9d7f-ee333f265d64	true	access.token.claim
f89032f9-6eda-48ed-9d7f-ee333f265d64	gender	claim.name
f89032f9-6eda-48ed-9d7f-ee333f265d64	String	jsonType.label
ce47490c-aca9-40c1-ba11-ccebd8013c5f	true	introspection.token.claim
ce47490c-aca9-40c1-ba11-ccebd8013c5f	true	userinfo.token.claim
ce47490c-aca9-40c1-ba11-ccebd8013c5f	email	user.attribute
ce47490c-aca9-40c1-ba11-ccebd8013c5f	true	id.token.claim
ce47490c-aca9-40c1-ba11-ccebd8013c5f	true	access.token.claim
ce47490c-aca9-40c1-ba11-ccebd8013c5f	email	claim.name
ce47490c-aca9-40c1-ba11-ccebd8013c5f	String	jsonType.label
e8394f66-3a3b-4c44-8793-11064f6263fa	true	introspection.token.claim
e8394f66-3a3b-4c44-8793-11064f6263fa	true	userinfo.token.claim
e8394f66-3a3b-4c44-8793-11064f6263fa	emailVerified	user.attribute
e8394f66-3a3b-4c44-8793-11064f6263fa	true	id.token.claim
e8394f66-3a3b-4c44-8793-11064f6263fa	true	access.token.claim
e8394f66-3a3b-4c44-8793-11064f6263fa	email_verified	claim.name
e8394f66-3a3b-4c44-8793-11064f6263fa	boolean	jsonType.label
72ea541c-ac2d-4c70-a962-dbd473467acc	formatted	user.attribute.formatted
72ea541c-ac2d-4c70-a962-dbd473467acc	country	user.attribute.country
72ea541c-ac2d-4c70-a962-dbd473467acc	true	introspection.token.claim
72ea541c-ac2d-4c70-a962-dbd473467acc	postal_code	user.attribute.postal_code
72ea541c-ac2d-4c70-a962-dbd473467acc	true	userinfo.token.claim
72ea541c-ac2d-4c70-a962-dbd473467acc	street	user.attribute.street
72ea541c-ac2d-4c70-a962-dbd473467acc	true	id.token.claim
72ea541c-ac2d-4c70-a962-dbd473467acc	region	user.attribute.region
72ea541c-ac2d-4c70-a962-dbd473467acc	true	access.token.claim
72ea541c-ac2d-4c70-a962-dbd473467acc	locality	user.attribute.locality
34538bac-0530-4b7a-b225-121dabd0e6e3	true	introspection.token.claim
34538bac-0530-4b7a-b225-121dabd0e6e3	true	userinfo.token.claim
34538bac-0530-4b7a-b225-121dabd0e6e3	phoneNumber	user.attribute
34538bac-0530-4b7a-b225-121dabd0e6e3	true	id.token.claim
34538bac-0530-4b7a-b225-121dabd0e6e3	true	access.token.claim
34538bac-0530-4b7a-b225-121dabd0e6e3	phone_number	claim.name
34538bac-0530-4b7a-b225-121dabd0e6e3	String	jsonType.label
c3993076-de64-4d83-8beb-e3704c4c9722	true	introspection.token.claim
c3993076-de64-4d83-8beb-e3704c4c9722	true	userinfo.token.claim
c3993076-de64-4d83-8beb-e3704c4c9722	phoneNumberVerified	user.attribute
c3993076-de64-4d83-8beb-e3704c4c9722	true	id.token.claim
c3993076-de64-4d83-8beb-e3704c4c9722	true	access.token.claim
c3993076-de64-4d83-8beb-e3704c4c9722	phone_number_verified	claim.name
c3993076-de64-4d83-8beb-e3704c4c9722	boolean	jsonType.label
216f1918-f7e3-4d2d-9376-571e533e42b1	true	introspection.token.claim
216f1918-f7e3-4d2d-9376-571e533e42b1	true	access.token.claim
515f9181-2d34-4389-b94c-c1a4707dded4	true	introspection.token.claim
515f9181-2d34-4389-b94c-c1a4707dded4	true	multivalued
515f9181-2d34-4389-b94c-c1a4707dded4	foo	user.attribute
515f9181-2d34-4389-b94c-c1a4707dded4	true	access.token.claim
515f9181-2d34-4389-b94c-c1a4707dded4	realm_access.roles	claim.name
515f9181-2d34-4389-b94c-c1a4707dded4	String	jsonType.label
f15eaa6b-d803-48f7-b6b0-8a0b4364db87	true	introspection.token.claim
f15eaa6b-d803-48f7-b6b0-8a0b4364db87	true	multivalued
f15eaa6b-d803-48f7-b6b0-8a0b4364db87	foo	user.attribute
f15eaa6b-d803-48f7-b6b0-8a0b4364db87	true	access.token.claim
f15eaa6b-d803-48f7-b6b0-8a0b4364db87	resource_access.${client_id}.roles	claim.name
f15eaa6b-d803-48f7-b6b0-8a0b4364db87	String	jsonType.label
bab8fe82-1986-4da2-8e87-ec26eee5ee15	true	introspection.token.claim
bab8fe82-1986-4da2-8e87-ec26eee5ee15	true	access.token.claim
3325e56b-7482-4d19-b0ec-73ef73fa9f42	true	introspection.token.claim
3325e56b-7482-4d19-b0ec-73ef73fa9f42	true	userinfo.token.claim
3325e56b-7482-4d19-b0ec-73ef73fa9f42	username	user.attribute
3325e56b-7482-4d19-b0ec-73ef73fa9f42	true	id.token.claim
3325e56b-7482-4d19-b0ec-73ef73fa9f42	true	access.token.claim
3325e56b-7482-4d19-b0ec-73ef73fa9f42	upn	claim.name
3325e56b-7482-4d19-b0ec-73ef73fa9f42	String	jsonType.label
d4c42cfd-ca55-48dd-bc61-5d4206d4d998	true	introspection.token.claim
d4c42cfd-ca55-48dd-bc61-5d4206d4d998	true	multivalued
d4c42cfd-ca55-48dd-bc61-5d4206d4d998	foo	user.attribute
d4c42cfd-ca55-48dd-bc61-5d4206d4d998	true	id.token.claim
d4c42cfd-ca55-48dd-bc61-5d4206d4d998	true	access.token.claim
d4c42cfd-ca55-48dd-bc61-5d4206d4d998	groups	claim.name
d4c42cfd-ca55-48dd-bc61-5d4206d4d998	String	jsonType.label
6fcb83d3-b69a-47c4-8e98-0471bbf941d7	true	introspection.token.claim
6fcb83d3-b69a-47c4-8e98-0471bbf941d7	true	id.token.claim
6fcb83d3-b69a-47c4-8e98-0471bbf941d7	true	access.token.claim
d8a5edc0-0302-47ee-b379-03df80fc28cb	AUTH_TIME	user.session.note
d8a5edc0-0302-47ee-b379-03df80fc28cb	true	introspection.token.claim
d8a5edc0-0302-47ee-b379-03df80fc28cb	true	id.token.claim
d8a5edc0-0302-47ee-b379-03df80fc28cb	true	access.token.claim
d8a5edc0-0302-47ee-b379-03df80fc28cb	auth_time	claim.name
d8a5edc0-0302-47ee-b379-03df80fc28cb	long	jsonType.label
ee3007be-34b7-4191-aee3-38b530ff13f9	true	introspection.token.claim
ee3007be-34b7-4191-aee3-38b530ff13f9	true	access.token.claim
02d7b967-fa3d-480b-af13-4e75656d2704	clientAddress	user.session.note
02d7b967-fa3d-480b-af13-4e75656d2704	true	introspection.token.claim
02d7b967-fa3d-480b-af13-4e75656d2704	true	id.token.claim
02d7b967-fa3d-480b-af13-4e75656d2704	true	access.token.claim
02d7b967-fa3d-480b-af13-4e75656d2704	clientAddress	claim.name
02d7b967-fa3d-480b-af13-4e75656d2704	String	jsonType.label
4ddc1cdf-40b8-43ea-93b2-2af6118ff887	client_id	user.session.note
4ddc1cdf-40b8-43ea-93b2-2af6118ff887	true	introspection.token.claim
4ddc1cdf-40b8-43ea-93b2-2af6118ff887	true	id.token.claim
4ddc1cdf-40b8-43ea-93b2-2af6118ff887	true	access.token.claim
4ddc1cdf-40b8-43ea-93b2-2af6118ff887	client_id	claim.name
4ddc1cdf-40b8-43ea-93b2-2af6118ff887	String	jsonType.label
5ce45af6-28da-4dd9-a92d-8577082a5b0e	clientHost	user.session.note
5ce45af6-28da-4dd9-a92d-8577082a5b0e	true	introspection.token.claim
5ce45af6-28da-4dd9-a92d-8577082a5b0e	true	id.token.claim
5ce45af6-28da-4dd9-a92d-8577082a5b0e	true	access.token.claim
5ce45af6-28da-4dd9-a92d-8577082a5b0e	clientHost	claim.name
5ce45af6-28da-4dd9-a92d-8577082a5b0e	String	jsonType.label
2ca5b5c2-0d31-4b41-a4d3-a2dc438ae450	true	introspection.token.claim
2ca5b5c2-0d31-4b41-a4d3-a2dc438ae450	true	multivalued
2ca5b5c2-0d31-4b41-a4d3-a2dc438ae450	true	id.token.claim
2ca5b5c2-0d31-4b41-a4d3-a2dc438ae450	true	access.token.claim
2ca5b5c2-0d31-4b41-a4d3-a2dc438ae450	organization	claim.name
2ca5b5c2-0d31-4b41-a4d3-a2dc438ae450	String	jsonType.label
5c7718a5-c06b-4f97-a77e-2df08a92a4ce	true	introspection.token.claim
5c7718a5-c06b-4f97-a77e-2df08a92a4ce	true	userinfo.token.claim
5c7718a5-c06b-4f97-a77e-2df08a92a4ce	locale	user.attribute
5c7718a5-c06b-4f97-a77e-2df08a92a4ce	true	id.token.claim
5c7718a5-c06b-4f97-a77e-2df08a92a4ce	true	access.token.claim
5c7718a5-c06b-4f97-a77e-2df08a92a4ce	locale	claim.name
5c7718a5-c06b-4f97-a77e-2df08a92a4ce	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	60	300	300	\N	\N	\N	t	f	0	\N	qm-realm	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	52a0c24b-597a-49f9-b7b7-62e0db05f1af	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	5e135d55-0f81-4d4e-be1a-b300e1645c40	7ad8ad1b-695e-44a0-a1c0-831ec91fd9f5	94868d2b-b895-49af-a3a8-9f33fe157e8a	25a8fd7a-a18f-4edf-8515-c963c35d164e	427ccf66-f2df-4500-94c0-2d72995258c9	2592000	f	900	t	f	b7eda90f-b1ef-4657-89e5-8d6cedf35c8c	0	f	0	0	9379f18e-adcb-491c-8814-65c69dd45091
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	ab0b18a6-c7f9-46c6-930d-6600c036326c	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	f836c8fe-a815-4e33-90f5-1e6db53ca463	e930ae3e-a199-48bb-994e-5d0b558bdc85	2bb2269b-d3b8-423d-8d84-d351e1f945a6	40a1b042-55f3-46dc-bff8-2e6b25a7ee75	8d31abe7-9d1b-4c75-9398-e4d244e4d118	2592000	f	900	t	f	3b4e89d1-ecd3-4c6a-b415-dcb3facee119	0	f	0	0	7e5d7b82-8607-4196-99b5-e6202cc8cfac
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	
_browser_header.xContentTypeOptions	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	nosniff
_browser_header.referrerPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	no-referrer
_browser_header.xRobotsTag	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	none
_browser_header.xFrameOptions	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	SAMEORIGIN
_browser_header.contentSecurityPolicy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	1; mode=block
_browser_header.strictTransportSecurity	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	max-age=31536000; includeSubDomains
bruteForceProtected	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	false
permanentLockout	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	false
maxTemporaryLockouts	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	0
bruteForceStrategy	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	MULTIPLE
maxFailureWaitSeconds	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	900
minimumQuickLoginWaitSeconds	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	60
waitIncrementSeconds	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	60
quickLoginCheckMilliSeconds	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	1000
maxDeltaTimeSeconds	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	43200
failureFactor	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	30
realmReusableOtpCode	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	false
firstBrokerLoginFlowId	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	e3c7c9e2-d4cb-4042-a70a-36027a868b71
displayName	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	Keycloak
displayNameHtml	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	RS256
offlineSessionMaxLifespanEnabled	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	false
offlineSessionMaxLifespan	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	5184000
_browser_header.contentSecurityPolicyReportOnly	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	
_browser_header.xContentTypeOptions	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	nosniff
_browser_header.referrerPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	no-referrer
_browser_header.xRobotsTag	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	none
_browser_header.xFrameOptions	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	SAMEORIGIN
_browser_header.contentSecurityPolicy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	1; mode=block
_browser_header.strictTransportSecurity	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	max-age=31536000; includeSubDomains
bruteForceProtected	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	false
permanentLockout	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	false
maxTemporaryLockouts	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0
bruteForceStrategy	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	MULTIPLE
maxFailureWaitSeconds	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	900
minimumQuickLoginWaitSeconds	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	60
waitIncrementSeconds	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	60
quickLoginCheckMilliSeconds	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	1000
maxDeltaTimeSeconds	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	43200
failureFactor	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	30
realmReusableOtpCode	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	false
defaultSignatureAlgorithm	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	RS256
offlineSessionMaxLifespanEnabled	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	false
offlineSessionMaxLifespan	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5184000
actionTokenGeneratedByAdminLifespan	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	43200
actionTokenGeneratedByUserLifespan	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	300
oauth2DeviceCodeLifespan	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	600
oauth2DevicePollingInterval	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5
webAuthnPolicyRpEntityName	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	keycloak
webAuthnPolicySignatureAlgorithms	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	ES256,RS256
webAuthnPolicyRpId	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	
webAuthnPolicyAttestationConveyancePreference	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	not specified
webAuthnPolicyAuthenticatorAttachment	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	not specified
webAuthnPolicyRequireResidentKey	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	not specified
webAuthnPolicyUserVerificationRequirement	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	not specified
webAuthnPolicyCreateTimeout	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0
webAuthnPolicyAvoidSameAuthenticatorRegister	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	false
webAuthnPolicyRpEntityNamePasswordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	ES256,RS256
webAuthnPolicyRpIdPasswordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	
webAuthnPolicyAttestationConveyancePreferencePasswordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	not specified
webAuthnPolicyRequireResidentKeyPasswordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	not specified
webAuthnPolicyCreateTimeoutPasswordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	false
cibaBackchannelTokenDeliveryMode	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	poll
cibaExpiresIn	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	120
cibaInterval	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	5
cibaAuthRequestedUserHint	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	login_hint
parRequestUriLifespan	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	60
firstBrokerLoginFlowId	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	d40e0717-f4db-40dd-98b6-3c5b8819aca7
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
13a45ff9-67c6-4c28-8c7e-a7268a0217e9	jboss-logging
2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	13a45ff9-67c6-4c28-8c7e-a7268a0217e9
password	password	t	t	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.redirect_uris (client_id, value) FROM stdin;
2bdc8e7d-2806-4626-81da-da6449d58897	/realms/master/account/*
551feff9-1317-4fed-9053-411a8810c565	/realms/master/account/*
924011ef-3a2f-4fd4-a007-37fe61577d11	/admin/master/console/*
55bfc23e-79c7-4a5f-96a4-503b7025f85a	/realms/qm-realm/account/*
e39f027b-a76d-418e-80a1-190263cc2b2e	/realms/qm-realm/account/*
5b81c8b8-e05f-4298-a125-4bbf2215fb55	/admin/qm-realm/console/*
14f121b4-4d55-46e7-abd5-161dd1da7bbe	http://localhost:3000/*
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
4a026176-d111-4550-97ed-19573564d6b6	VERIFY_EMAIL	Verify Email	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	t	f	VERIFY_EMAIL	50
c06ecb62-acb3-480f-bc81-ecdc5255748d	UPDATE_PROFILE	Update Profile	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	t	f	UPDATE_PROFILE	40
a4bd082c-d76b-4929-8dd1-d43f86303d65	CONFIGURE_TOTP	Configure OTP	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	t	f	CONFIGURE_TOTP	10
59c4a18f-19aa-49f2-ab2f-9dc1edbfd41b	UPDATE_PASSWORD	Update Password	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	t	f	UPDATE_PASSWORD	30
db7e8a1e-1bc4-4328-b582-dd571cd66ac1	TERMS_AND_CONDITIONS	Terms and Conditions	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f	f	TERMS_AND_CONDITIONS	20
5d0f261d-3d0c-4a09-8b9f-3374e526cef2	delete_account	Delete Account	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	f	f	delete_account	60
d7ff4aa9-954d-47c6-af06-c43dd17f3a51	delete_credential	Delete Credential	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	t	f	delete_credential	100
f794a12f-ee98-4ea7-ac1d-213ea9432ff9	update_user_locale	Update User Locale	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	t	f	update_user_locale	1000
c4fe71df-a893-447e-b294-3ea136a277ca	webauthn-register	Webauthn Register	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	t	f	webauthn-register	70
3d6733ce-615b-4220-9cc1-92a88a8c699c	webauthn-register-passwordless	Webauthn Register Passwordless	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	t	f	webauthn-register-passwordless	80
dafba6f7-7a2c-4763-ab47-a9d44dcbeca5	VERIFY_PROFILE	Verify Profile	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	t	f	VERIFY_PROFILE	90
eafc63c5-98e8-4dfa-ac98-efc08d1bc3d6	VERIFY_EMAIL	Verify Email	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	t	f	VERIFY_EMAIL	50
77a0f10b-321e-4bfa-93e6-19a42c76957b	UPDATE_PROFILE	Update Profile	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	t	f	UPDATE_PROFILE	40
0e0eb0a7-e51c-4ffc-aac8-4fc592550809	CONFIGURE_TOTP	Configure OTP	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	t	f	CONFIGURE_TOTP	10
d1ee862b-3d7c-4248-88ac-6a929c7a8d96	UPDATE_PASSWORD	Update Password	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	t	f	UPDATE_PASSWORD	30
a5d27aaa-609e-4c82-b706-859adeda5075	TERMS_AND_CONDITIONS	Terms and Conditions	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	f	f	TERMS_AND_CONDITIONS	20
7d288841-378c-4666-bf6b-433df0bf0cbb	delete_account	Delete Account	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	f	f	delete_account	60
711f9787-4d7a-4a8e-841e-b006ebba2412	delete_credential	Delete Credential	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	t	f	delete_credential	100
854f2ca4-8bc3-4350-903b-206953f737a5	update_user_locale	Update User Locale	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	t	f	update_user_locale	1000
c430edaf-ddb6-4ed8-8fb3-7e897501eb95	webauthn-register	Webauthn Register	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	t	f	webauthn-register	70
5deaa02e-9635-47a4-a5f3-f2b7aabe71f4	webauthn-register-passwordless	Webauthn Register Passwordless	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	t	f	webauthn-register-passwordless	80
0af9b1f4-b4a3-4e44-89f1-b08bc0de0686	VERIFY_PROFILE	Verify Profile	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	t	f	VERIFY_PROFILE	90
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
14f121b4-4d55-46e7-abd5-161dd1da7bbe	t	0	1
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
e5499399-ad89-4bd1-8992-41be9abed651	Default Policy	A policy that grants access only for users within this realm	js	0	0	14f121b4-4d55-46e7-abd5-161dd1da7bbe	\N
979b9dbb-5be5-4347-a259-6a6fba8d715d	Default Permission	A permission that applies to the default resource type	resource	1	0	14f121b4-4d55-46e7-abd5-161dd1da7bbe	\N
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
512a43c9-a70b-4d66-928e-c829e5fbfdba	Default Resource	urn:qm-client:resources:default	\N	14f121b4-4d55-46e7-abd5-161dd1da7bbe	14f121b4-4d55-46e7-abd5-161dd1da7bbe	f	\N
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.resource_uris (resource_id, value) FROM stdin;
512a43c9-a70b-4d66-928e-c829e5fbfdba	/*
\.


--
-- Data for Name: revoked_token; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.revoked_token (id, expire) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
551feff9-1317-4fed-9053-411a8810c565	46710c75-5812-41e9-a391-5cf96b0d96ea
551feff9-1317-4fed-9053-411a8810c565	93f3e94d-4e24-453c-80da-d5d73760c32e
e39f027b-a76d-418e-80a1-190263cc2b2e	456ab443-1ca1-4bf6-a5cf-fdbcffe7dcdd
e39f027b-a76d-418e-80a1-190263cc2b2e	41d03541-0860-407f-912a-4d53ed776587
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_attribute (name, value, user_id, id, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
is_temporary_admin	true	f651f055-58c0-41c5-b2dc-6b6e2fbb6c26	ee11a93a-4491-469e-9c18-e5c46cfde579	\N	\N	\N
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
f651f055-58c0-41c5-b2dc-6b6e2fbb6c26	\N	20142315-d86d-41c6-bf6e-da9293a8df6d	f	t	\N	\N	\N	13a45ff9-67c6-4c28-8c7e-a7268a0217e9	admin	1775152159386	\N	0
8bda53bb-85e8-4a26-9d3a-6ee4958e0ab6	\N	a57aba4e-426d-4c84-a1d5-fe46cf74b589	f	t	\N	\N	\N	2ff2dbbc-3bcd-4ab4-b017-1be3266a0cf9	service-account-qm-client	1775152394348	14f121b4-4d55-46e7-abd5-161dd1da7bbe	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_group_membership (group_id, user_id, membership_type) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
7e5d7b82-8607-4196-99b5-e6202cc8cfac	f651f055-58c0-41c5-b2dc-6b6e2fbb6c26
5d9e55f9-a701-42dd-b811-0becaa4f200a	f651f055-58c0-41c5-b2dc-6b6e2fbb6c26
9379f18e-adcb-491c-8814-65c69dd45091	8bda53bb-85e8-4a26-9d3a-6ee4958e0ab6
14fa601d-546b-4a73-9696-caca85f4ddc4	8bda53bb-85e8-4a26-9d3a-6ee4958e0ab6
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: user
--

COPY public.web_origins (client_id, value) FROM stdin;
924011ef-3a2f-4fd4-a007-37fe61577d11	+
5b81c8b8-e05f-4298-a125-4bbf2215fb55	+
14f121b4-4d55-46e7-abd5-161dd1da7bbe	http://localhost:3000
\.


--
-- Name: org_domain ORG_DOMAIN_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.org_domain
    ADD CONSTRAINT "ORG_DOMAIN_pkey" PRIMARY KEY (id, name);


--
-- Name: org ORG_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT "ORG_pkey" PRIMARY KEY (id);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: jgroups_ping constraint_jgroups_ping; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.jgroups_ping
    ADD CONSTRAINT constraint_jgroups_ping PRIMARY KEY (address);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: revoked_token constraint_rt; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.revoked_token
    ADD CONSTRAINT constraint_rt PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: user_consent uk_external_consent; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_external_consent UNIQUE (client_storage_provider, external_client_id, user_id);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_local_consent; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_local_consent UNIQUE (client_id, user_id);


--
-- Name: org uk_org_alias; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_alias UNIQUE (realm_id, alias);


--
-- Name: org uk_org_group; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_group UNIQUE (group_id);


--
-- Name: org uk_org_name; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_name UNIQUE (realm_id, name);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: fed_user_attr_long_values; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX fed_user_attr_long_values ON public.fed_user_attribute USING btree (long_value_hash, name);


--
-- Name: fed_user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX fed_user_attr_long_values_lower_case ON public.fed_user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_att_by_name_value; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_client_att_by_name_value ON public.client_attributes USING btree (name, substr(value, 1, 255));


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_idp_for_login; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_idp_for_login ON public.identity_provider USING btree (realm_id, enabled, link_only, hide_on_login, organization_id);


--
-- Name: idx_idp_realm_org; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_idp_realm_org ON public.identity_provider USING btree (realm_id, organization_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_uss_by_broker_session_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_offline_uss_by_broker_session_id ON public.offline_user_session USING btree (broker_session_id, realm_id);


--
-- Name: idx_offline_uss_by_last_session_refresh; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_offline_uss_by_last_session_refresh ON public.offline_user_session USING btree (realm_id, offline_flag, last_session_refresh);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_org_domain_org_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_org_domain_org_id ON public.org_domain USING btree (org_id);


--
-- Name: idx_perm_ticket_owner; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_perm_ticket_owner ON public.resource_server_perm_ticket USING btree (owner);


--
-- Name: idx_perm_ticket_requester; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_perm_ticket_requester ON public.resource_server_perm_ticket USING btree (requester);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_rev_token_on_expire; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_rev_token_on_expire ON public.revoked_token USING btree (expire);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_usconsent_scope_id; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_usconsent_scope_id ON public.user_consent_client_scope USING btree (scope_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: user_attr_long_values; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX user_attr_long_values ON public.user_attribute USING btree (long_value_hash, name);


--
-- Name: user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: user
--

CREATE INDEX user_attr_long_values_lower_case ON public.user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: user
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- PostgreSQL database dump complete
--

\unrestrict oHUgQcW0faYeHPJPnvn6UbyxMt295c9WQnXuauNJRyhJ7ZjEU7BiBMx6PNXlc4y

